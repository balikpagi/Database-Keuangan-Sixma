/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, Item, Sale, Expense, Customer, AuditLog, Settings } from './types';

export function formatIDR(amount: number): string {
  return "Rp " + parseFloat(amount.toString()).toLocaleString('id-ID', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

export function dapatkanTerbilangRupiah(nominal: number): string {
  if (nominal === 0) return "Nol Rupiah";
  const words = ["", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas"];
  
  function konversi(n: number): string {
    if (n < 12) return words[n];
    if (n < 20) return words[n - 10] + " Belas";
    if (n < 100) return words[Math.floor(n / 10)] + " Puluh " + words[n % 10];
    if (n < 200) return "Seratus " + konversi(n - 100);
    if (n < 1000) return words[Math.floor(n / 100)] + " Ratus " + konversi(n % 100);
    if (n < 2000) return "Seribu " + konversi(n - 1000);
    if (n < 1000000) return konversi(Math.floor(n / 1000)) + " Ribu " + konversi(n % 1000);
    if (n < 1000000000) return konversi(Math.floor(n / 1000000)) + " Juta " + konversi(n % 1000000);
    if (n < 1000000000000) return konversi(Math.floor(n / 1000000000)) + " Milyar " + konversi(n % 1000000000);
    return "";
  }
  
  let hasil = konversi(Math.floor(nominal)).trim();
  hasil = hasil.replace(/\s+/g, ' ');
  // Ensure "Satu Ratus" -> "Seratus", "Satu Ribu" is standard, but "Seribu" is handled by the rules.
  // Replace triple/double spaces just in case
  return hasil ? hasil + " Rupiah" : "Nol Rupiah";
}

export const defaultUsers: User[] = [
  { id: "U-001", username: "admin", password: "admin123", role: "Admin", name: "Administrator" },
  { id: "U-002", username: "operator", password: "operator123", role: "Operator", name: "Kasir Operator" }
];

export const defaultItems: Item[] = [
  { id: "FT-01", name: "Fotocopy A4", category: "Fotocopy", buyPrice: 50, sellPrice: 250, stock: 99999, minStock: 100 },
  { id: "FT-02", name: "Fotocopy F4", category: "Fotocopy", buyPrice: 60, sellPrice: 300, stock: 99999, minStock: 100 },
  { id: "JL-01", name: "Jilid Mika Lakban", category: "Jilid", buyPrice: 1000, sellPrice: 3500, stock: 999, minStock: 20 },
  { id: "JL-02", name: "Jilid Spiral Kawat", category: "Jilid", buyPrice: 2500, sellPrice: 7500, stock: 999, minStock: 10 },
  { id: "ATK-01", name: "Kertas HVS SIDU A4 80gr", category: "ATK", buyPrice: 42000, sellPrice: 52000, stock: 12, minStock: 15 },
  { id: "ATK-02", name: "Buku Tulis Sinar Dunia 38L", category: "ATK", buyPrice: 2800, sellPrice: 4000, stock: 60, minStock: 20 },
  { id: "ATK-03", name: "Pulpen Standard AE7 Hitam", category: "ATK", buyPrice: 1500, sellPrice: 2500, stock: 4, minStock: 12 }
];

export const defaultSales: Sale[] = [
  {
    invoiceNo: "F-00100526-01",
    kwitansiNo: "K100526-01",
    trxId: "TRX-00100526-01",
    tanggal: "2026-05-10 09:12",
    pelanggan: "Umum",
    metodeBayar: "Tunai",
    subtotal: 104000,
    diskon: 0,
    tax: 11440,
    total: 115440,
    status: "Lunas (Paid)",
    keteranganBelanja: "Belanja ATK TW 1",
    itemDetail: [
      { id: "ATK-01", name: "Kertas HVS SIDU A4 80gr", price: 52000, qty: 2, volume: 1, unit: "Rim", taxRate: 11 }
    ]
  },
  {
    invoiceNo: "F-00150526-01",
    kwitansiNo: "K150526-01",
    trxId: "TRX-00150526-01",
    tanggal: "2026-05-15 14:32",
    pelanggan: "SD Negeri 01 Grogol",
    metodeBayar: "Transfer",
    subtotal: 307500,
    diskon: 0,
    tax: 0,
    total: 307500,
    status: "Lunas (Paid)",
    keteranganBelanja: "Fotocopy Bahan UTS & Jilid",
    itemDetail: [
      { id: "FT-01", name: "Fotocopy A4", price: 250, qty: 500, volume: 1, unit: "Lembar", taxRate: 0 },
      { id: "JL-01", name: "Jilid Mika Lakban", price: 3500, qty: 10, volume: 1, unit: "Buku", taxRate: 0 }
    ]
  }
];

export const defaultExpenses: Expense[] = [
  { expenseNo: "EXP-00020526", tanggal: "2026-05-02", kategori: "Operasional", keterangan: "Tagihan listrik Toko Mei 2026", jumlah: 150000 },
  { expenseNo: "EXP-00120526", tanggal: "2026-05-12", kategori: "Bahan Baku", keterangan: "Beli Toner Fotocopy Canon IR6000", jumlah: 350000 }
];

export const defaultCustomers: Customer[] = [
  { id: "CUST-6679", name: "SD Negeri 01 Grogol", phone: "0812998877", email: "sdn01grogol@sch.id", address: "Jl. Kyai Tapa No. 10" },
  { id: "CUST-4987", name: "Kecamatan Grogol Petamburan", phone: "0821554433", email: "kec.grogol@jakarta.go.id", address: "Grogol, Jakarta Barat" }
];

export const defaultLogs: AuditLog[] = [
  { tanggal: "2026-06-04 13:00:00", aksi: "Security Audit", keterangan: "Database lokal berhasil diinisialisasi", user: "System" }
];

export const defaultSettings: Settings = {
  companyName: "Sixma Report",
  companyAddress: "Jl. Srengseng Raya No. 1, Kel. Srengseng, Kec. Kembangan, Jakarta Barat",
  logo: "",
  kopSurat: "",
  signature: "",
  stamp: "",
  gasUrl: "",
  ownerName: "FITRI MAULIDINA",
  ownerBankName: "BCA",
  ownerBankNo: "0123-4567-89",
  ownerNpwp: "12.345.678.9-012.000",
  sumberDana: ""
};

export function getLocalStorageData<T>(key: string, defaultValue: T): T {
  if (typeof window === 'undefined') return defaultValue;
  const stored = localStorage.getItem(key);
  if (!stored) {
    localStorage.setItem(key, JSON.stringify(defaultValue));
    return defaultValue;
  }
  try {
    return JSON.parse(stored) as T;
  } catch (error) {
    console.error("Error reading key " + key + " from localStorage", error);
    return defaultValue;
  }
}

export function saveLocalStorageData<T>(key: string, value: T): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(key, JSON.stringify(value));
  }
}
