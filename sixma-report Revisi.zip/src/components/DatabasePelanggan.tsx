/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Customer } from '../types';

interface DatabasePelangganProps {
  customers: Customer[];
  onCustomersChange: (customers: Customer[]) => void;
  addLog: (action: string, detail: string) => void;
}

export function DatabasePelanggan({ customers, onCustomersChange, addLog }: DatabasePelangganProps) {
  const [showAddEditModal, setShowAddEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);

  // Form states
  const [editId, setEditId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");

  // Detailed view state
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const handleOpenAddModal = () => {
    setEditId(null);
    setName("");
    setPhone("");
    setEmail("");
    setAddress("");
    setShowAddEditModal(true);
  };

  const handleOpenEditModal = (c: Customer) => {
    setEditId(c.id);
    setName(c.name);
    setPhone(c.phone === "-" ? "" : c.phone);
    setEmail(c.email === "-" ? "" : c.email);
    setAddress(c.address === "-" ? "" : c.address);
    setShowAddEditModal(true);
  };

  const handleSaveCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    const custName = name.trim();

    if (!custName) {
      alert("Nama instansi/pelanggan tetap wajib diisi!");
      return;
    }

    if (editId) {
      const updated = customers.map(c => {
        if (c.id === editId) {
          return {
            ...c,
            name: custName,
            phone: phone.trim() || "-",
            email: email.trim() || "-",
            address: address.trim() || "-"
          };
        }
        return c;
      });
      onCustomersChange(updated);
      addLog("Koreksi Pelanggan", `Memperbarui profil pelanggan ${custName} (${editId})`);
      alert("Profil pelanggan berhasil diperbarui!");
    } else {
      const id = "CUST-" + Math.floor(1000 + Math.random() * 9000);
      const newCust: Customer = {
        id,
        name: custName,
        phone: phone.trim() || "-",
        email: email.trim() || "-",
        address: address.trim() || "-"
      };
      onCustomersChange([...customers, newCust]);
      addLog("Tambah Pelanggan", `Mendaftarkan pelanggan baru ${custName} (${id})`);
      alert("Pelanggan baru berhasil ditambahkan!");
    }

    setShowAddEditModal(false);
  };

  const handleDeleteCustomer = (id: string, custName: string) => {
    if (confirm(`Yakin ingin menghapus data pelanggan terpilih: ${custName}?`)) {
      onCustomersChange(customers.filter(c => c.id !== id));
      addLog("Hapus Pelanggan", `Menghapus mitra pelanggan ${custName} (${id})`);
      alert("Pencatatan data pelanggan berhasil dihapus.");
    }
  };

  const handleViewDetail = (c: Customer) => {
    setSelectedCustomer(c);
    setShowDetailModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Database Pelanggan Tetap</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Mengelola data pelanggan tetap dan instansi mitra terpercaya toko Anda.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="w-full sm:w-auto bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm flex items-center justify-center space-x-2 cursor-pointer transition"
        >
          <i className="fa-solid fa-plus"></i>
          <span>Tambah Pelanggan</span>
        </button>
      </div>

      {/* Corporate Database Table */}
      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-850 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4">ID</th>
                <th className="p-4">Nama Pelanggan</th>
                <th className="p-4">Nomor HP</th>
                <th className="p-4">Email</th>
                <th className="p-4">Alamat Domisili</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-350">
              {[...customers]
                .sort((a, b) => a.name.localeCompare(b.name, 'id'))
                .map((cust, index) => (
                  <tr key={cust.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition border-b dark:border-slate-850">
                    <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                    <td className="p-4 font-mono font-bold text-slate-500">{cust.id}</td>
                    <td className="p-4 font-extrabold text-slate-900 dark:text-white">{cust.name}</td>
                    <td className="p-4 font-semibold">{cust.phone}</td>
                    <td className="p-4 font-medium">{cust.email}</td>
                    <td className="p-4 text-slate-400 max-w-[200px] truncate">{cust.address}</td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center space-x-2.5">
                        <button 
                          onClick={() => handleViewDetail(cust)} 
                          className="text-sky-500 hover:text-sky-600 transition p-1 cursor-pointer" 
                          title="Lihat Profil"
                        >
                          <i className="fa-solid fa-eye text-base"></i>
                        </button>
                        <button 
                          onClick={() => handleOpenEditModal(cust)} 
                          className="text-amber-500 hover:text-amber-600 transition p-1 cursor-pointer" 
                          title="Koreksi Profil"
                        >
                          <i className="fa-solid fa-pen-to-square text-base"></i>
                        </button>
                        <button 
                          onClick={() => handleDeleteCustomer(cust.id, cust.name)} 
                          className="text-rose-500 hover:text-rose-600 transition p-1 cursor-pointer" 
                          title="Hapus Profil"
                        >
                          <i className="fa-solid fa-trash-can text-base"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              {customers.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-350 italic">Belum ada pelanggan tetap terdaftar</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add/Edit Customer */}
      {showAddEditModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-850 flex flex-col overflow-hidden animate-in fade-in duration-200">
            <div className="p-5 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className={`${editId ? 'fa-solid fa-user-pen text-amber-500' : 'fa-solid fa-user-plus text-sky-500'} text-base`}></i>
                <span>{editId ? 'Edit Informasi Pelanggan' : 'Daftarkan Pelanggan Baru'}</span>
              </h3>
              <button onClick={() => setShowAddEditModal(false)} className="text-slate-400 hover:text-slate-600 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-base"></i>
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-6 space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Nama Lengkap / Instansi Mitra</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: SD Negeri 01 Grogol" 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-205 dark:border-slate-755 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white font-bold"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Nomor Handphone</label>
                  <input 
                    type="text" 
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Contoh: 0812345678" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Alamat Email</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Contoh: instansi@gmail.com" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Alamat Lengkap Mandiri</label>
                <textarea 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  rows={3} 
                  placeholder="Tulis alamat penagihan / kirim berkas..." 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white resize-none"
                />
              </div>

              <div className="p-5 border-t border-slate-200 dark:border-slate-855 flex justify-end space-x-2 pt-4 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddEditModal(false)}
                  className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-600 text-white font-bold px-4 py-2 rounded-lg transition shadow-md"
                >
                  {editId ? 'Simpan Perubahan' : 'Daftarkan Pelanggan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal View Customer Info */}
      {showDetailModal && selectedCustomer && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in duration-200">
            <div className="p-5 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className="fa-solid fa-address-card text-sky-500 text-base"></i>
                <span>Detail Informasi Profil Pelanggan</span>
              </h3>
              <button onClick={() => setShowDetailModal(false)} className="text-slate-400 hover:text-slate-650 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-base"></i>
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="flex items-center space-x-4 border-b dark:border-slate-850 pb-4">
                <div className="w-12 h-12 bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 font-extrabold text-base flex items-center justify-center rounded-2xl border dark:border-slate-800">
                  {selectedCustomer.name.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-slate-800 dark:text-slate-100">{selectedCustomer.name}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">{selectedCustomer.id}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Nomor HP / WhatsApp</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-1">{selectedCustomer.phone}</p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold block">Alamat Email</span>
                  <p className="font-semibold text-slate-800 dark:text-slate-200 mt-1">{selectedCustomer.email}</p>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 font-bold block">Alamat Domisili</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200 mt-1 whitespace-pre-line leading-relaxed">{selectedCustomer.address}</p>
              </div>

              <div className="p-4 border-t border-slate-150 dark:border-slate-855 flex justify-end pt-4 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowDetailModal(false)}
                  className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition"
                >
                  Tutup Detail
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
