/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Item, Customer, CartItem, Sale } from '../types';
import { formatIDR } from '../utils';
import { motion } from 'motion/react';

interface InputPenjualanProps {
  items: Item[];
  customers: Customer[];
  onSalesChange: (sales: Sale[]) => void;
  sales: Sale[];
  onItemsChange: (items: Item[]) => void;
  addLog: (action: string, detail: string) => void;
  triggerToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onViewInvoice?: (sale: Sale, type: 'faktur' | 'kwitansi') => void;
}

export function InputPenjualan({ 
  items, 
  customers, 
  onSalesChange, 
  sales, 
  onItemsChange, 
  addLog,
  triggerToast,
  onViewInvoice
}: InputPenjualanProps) {
  // POS Form States
  const [selectedCustomer, setSelectedCustomer] = useState("Umum");
  const [manualCustomerName, setManualCustomerName] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("Tunai");
  const [saleStatus, setSaleStatus] = useState("Lunas (Paid)");
  const [generalKeteranganBelanja, setGeneralKeteranganBelanja] = useState("");
  const [saleDate, setSaleDate] = useState(() => {
    const d = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  });
  
  // Success state for checkout completion
  const [lastSavedSale, setLastSavedSale] = useState<Sale | null>(null);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  
  // Line item parameters
  const [itemName, setItemName] = useState("");
  const [itemCategory, setItemCategory] = useState("Fotocopy");
  const [itemDesc, setItemDesc] = useState(""); // Keterangan Belanja
  const [volume, setVolume] = useState("1");
  const [quantity, setQuantity] = useState("1");
  const [unit, setUnit] = useState("Lembar");
  const [taxRate, setTaxRate] = useState("0");
  const [unitPrice, setUnitPrice] = useState("");

  const [activeSelectedItemId, setActiveSelectedItemId] = useState<string | null>(null);

  // Cart Status
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discountPercent, setDiscountPercent] = useState("0");

  const lineSubtotal = (parseFloat(volume) || 1) * (parseFloat(quantity) || 1) * (parseFloat(unitPrice) || 0);

  // Sync category helper updates for units
  const handleCategoryChange = (cat: string) => {
    setItemCategory(cat);
    if (cat === "Fotocopy") setUnit("Lembar");
    else if (cat === "Jilid") setUnit("Buku");
    else setUnit("Unit");
  };

  // Handler for itemName input typing and auto-selecting from master items
  const handleItemNameChange = (val: string) => {
    setItemName(val);
    const matchedItem = items.find(item => item.name.toLowerCase().trim() === val.toLowerCase().trim());
    if (matchedItem) {
      setActiveSelectedItemId(matchedItem.id);
      setItemCategory(matchedItem.category);
      setUnitPrice(matchedItem.sellPrice.toString());
      
      if (matchedItem.category === "Fotocopy") setUnit("Lembar");
      else if (matchedItem.category === "Jilid") setUnit("Buku");
      else if (matchedItem.category === "ATK") setUnit("Pcs");
      else setUnit("Unit");
    } else {
      // Keep custom input entry, but detach active selection ID
      setActiveSelectedItemId(null);
    }
  };

  // Quick select chip logic
  const handleQuickSelect = (item: Item) => {
    setActiveSelectedItemId(item.id);
    setItemName(item.name);
    setItemCategory(item.category);
    setUnitPrice(item.sellPrice.toString());
    
    if (item.category === "Fotocopy") setUnit("Lembar");
    else if (item.category === "Jilid") setUnit("Buku");
    else setUnit("Unit");
  };

  // Keydown handler for inputs to add to cart on Enter
  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddLineToCart();
    }
  };

  // Add line item to cart
  const handleAddLineToCart = () => {
    const name = itemName.trim();
    const price = parseFloat(unitPrice) || 0;
    const vol = parseFloat(volume) || 1;
    const qty = parseFloat(quantity) || 1;
    const tax = parseFloat(taxRate) || 0;

    if (!name || price <= 0) {
      if (triggerToast) {
        triggerToast("Mohon isi Nama Item/Jasa serta Harga Satuan secara valid!", "error");
      } else {
        alert("Mohon isi Nama Item/Jasa serta Harga Satuan secara valid!");
      }
      return;
    }

    if (activeSelectedItemId) {
      const orig = items.find(i => i.id === activeSelectedItemId);
      if (orig && orig.category !== "Fotocopy" && orig.category !== "Jilid") {
        const alreadyInCart = cart
          .filter(c => c.id === orig.id)
          .reduce((sum, c) => sum + c.qty, 0);

        const proposedQty = vol * qty;
        if (orig.stock < (alreadyInCart + proposedQty)) {
          if (triggerToast) {
            triggerToast(`Stok tidak mencukupi! Tersisa hanya ${orig.stock} unit.`, "error");
          } else {
            alert(`Stok tidak mencukupi! Tersisa hanya ${orig.stock} unit.`);
          }
          return;
        }
      }
    }

    const cartId = activeSelectedItemId || "CUSTOM-" + Math.floor(100 + Math.random() * 900);
    const newCartItem: CartItem = {
      id: cartId,
      name,
      volume: vol,
      qty: vol * qty,
      unit,
      price,
      taxRate: tax,
      desc: itemDesc.trim() // Specific description added
    };

    setCart([...cart, newCartItem]);

    if (triggerToast) {
      triggerToast(`Berhasil menambahkan "${name}" ke keranjang belanja!`, "success");
    }

    // reset fields
    setItemName("");
    setVolume("1");
    setQuantity("1");
    setUnitPrice("");
    setItemDesc("");
    setActiveSelectedItemId(null);
  };

  // Delete cart index
  const handleRemoveFromCart = (index: number) => {
    setCart(cart.filter((_, idx) => idx !== index));
  };

  // Totals calculations
  const cartSubtotal = cart.reduce((acc, curr) => acc + (curr.qty * curr.price), 0);
  const discountAmount = cartSubtotal * ((parseFloat(discountPercent) || 0) / 100);
  const afterDiscount = cartSubtotal - discountAmount;
  const cartPpn = cart.reduce((acc, curr) => {
    if (curr.taxRate > 0) {
      const lineCost = curr.qty * curr.price;
      // apply discount percentage proportion to line items for accurate tax calculations
      const discountPercentage = (parseFloat(discountPercent) || 0) / 100;
      const discountedLine = lineCost - (lineCost * discountPercentage);
      return acc + (discountedLine * (curr.taxRate / 100));
    }
    return acc;
  }, 0);
  const grandTotal = afterDiscount + cartPpn;

  // Checkout process
  const handleCheckout = () => {
    let currentCartArray = [...cart];

    // If there is an item in the inputs, automatically include it in the sale so they don't have to click twice
    const name = itemName.trim();
    const price = parseFloat(unitPrice) || 0;
    if (name && price > 0) {
      const vol = parseFloat(volume) || 1;
      const qty = parseFloat(quantity) || 1;
      const tax = parseFloat(taxRate) || 0;

      const cartId = activeSelectedItemId || "CUSTOM-" + Math.floor(100 + Math.random() * 900);
      const autoCartItem: CartItem = {
        id: cartId,
        name,
        volume: vol,
        qty: vol * qty,
        unit,
        price,
        taxRate: tax,
        desc: itemDesc.trim()
      };

      currentCartArray.push(autoCartItem);
      setCart([]); // Reset local state cart
    }

    if (currentCartArray.length === 0) {
      if (triggerToast) {
        triggerToast("Keranjang belanja masih kosong!", "error");
      } else {
        alert("Keranjang belanja masih kosong!");
      }
      return;
    }

    const now = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    
    // Parse the user-selected saleDate (strictly "YYYY-MM-DD")
    const dateParts = saleDate.split('-');
    const year = parseInt(dateParts[0]) || now.getFullYear();
    const month = parseInt(dateParts[1]) || (now.getMonth() + 1);
    const day = parseInt(dateParts[2]) || now.getDate();
    
    // YYSMMDD format for unique Invoice coding
    const yearShort = year.toString().substring(2);
    const dateStringShort = `${pad(day)}${pad(month)}${yearShort}`;

    const sameDaySales = sales.filter(s => s.tanggal.startsWith(`${year}-${pad(month)}-${pad(day)}`));
    const sequence = sameDaySales.length + 1;
    const seqPad = sequence < 10 ? '0' + sequence : sequence;

    const invoiceNo = `F-00${dateStringShort}-${seqPad}`;
    const trxId = `TRX-00${dateStringShort}-${seqPad}`;
    const kwitansiNo = `K${dateStringShort}-${seqPad}`;

    let customerName = selectedCustomer;
    if (selectedCustomer === "Manual") {
      customerName = manualCustomerName.trim() || "Pelanggan Manual";
    }

    // Default general description based on first item, or general shopping memo
    const targetDescNote = generalKeteranganBelanja.trim() || currentCartArray.map(c => c.desc).filter(Boolean).join(", ") || currentCartArray.map(c => c.name).join(", ");

    const checkoutSubtotal = currentCartArray.reduce((acc, curr) => acc + (curr.qty * curr.price), 0);
    const checkoutDiscountAmount = checkoutSubtotal * ((parseFloat(discountPercent) || 0) / 100);
    const checkoutAfterDiscount = checkoutSubtotal - checkoutDiscountAmount;
    const checkoutCartPpn = currentCartArray.reduce((acc, curr) => {
      if (curr.taxRate > 0) {
        const lineCost = curr.qty * curr.price;
        const discountPercentage = (parseFloat(discountPercent) || 0) / 100;
        const discountedLine = lineCost - (lineCost * discountPercentage);
        return acc + (discountedLine * (curr.taxRate / 100));
      }
      return acc;
    }, 0);
    const checkoutGrandTotal = checkoutAfterDiscount + checkoutCartPpn;

    const newSale: Sale = {
      invoiceNo,
      kwitansiNo,
      trxId,
      tanggal: `${year}-${pad(month)}-${pad(day)} ${pad(now.getHours())}:${pad(now.getMinutes())}`,
      pelanggan: customerName,
      metodeBayar: paymentMethod,
      subtotal: checkoutSubtotal,
      diskon: parseFloat(discountPercent) || 0,
      tax: Math.round(checkoutCartPpn),
      total: Math.round(checkoutGrandTotal),
      status: saleStatus,
      keteranganBelanja: targetDescNote, 
      itemDetail: currentCartArray
    };

    // Deduct stock levels for actual products
    const updatedItems = items.map(p => {
      const cartTotalQty = currentCartArray
        .filter(c => c.id === p.id)
        .reduce((sum, c) => sum + c.qty, 0);

      if (cartTotalQty > 0 && p.category !== "Fotocopy" && p.category !== "Jilid") {
        return {
          ...p,
          stock: Math.max(0, p.stock - cartTotalQty)
        };
      }
      return p;
    });

    onItemsChange(updatedItems);
    onSalesChange([...sales, newSale]);
    addLog("Penjualan Sukses", `Transaksi baru berhasil diselesaikan No: ${invoiceNo}. Pelanggan: ${customerName}`);

    // Set last saved sale to render success modal
    setLastSavedSale(newSale);
    setShowSuccessModal(true);

    if (triggerToast) {
      triggerToast(`Faktur ${invoiceNo} berhasil disimpan!`, "success");
    }

    // Reset whole POS State
    setCart([]);
    setDiscountPercent("0");
    setSelectedCustomer("Umum");
    setManualCustomerName("");
    setPaymentMethod("Tunai");
    setSaleStatus("Lunas (Paid)");
    setGeneralKeteranganBelanja("");
    const defaultD = new Date();
    const defaultPad = (n: number) => n < 10 ? '0' + n : n;
    setSaleDate(`${defaultD.getFullYear()}-${defaultPad(defaultD.getMonth() + 1)}-${defaultPad(defaultD.getDate())}`);
    
    // reset fields
    setItemName("");
    setVolume("1");
    setQuantity("1");
    setUnitPrice("");
    setItemDesc("");
    setActiveSelectedItemId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Panel */}
      <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-200/60 dark:border-slate-900 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <span className="p-1.5 bg-sky-50 dark:bg-sky-950/40 rounded-lg text-sky-500">
              <i className="fa-solid fa-cash-register text-xs animate-pulse-slow"></i>
            </span>
            <span>Kasir & Registrasi Penjualan</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-[11px] mt-1 font-normal leading-normal">
            Pencatatan rincian transaksi penjualan, volume kegiatan jasa fotocopy, jilid, rincian ATK, serta otomatis terhubung dengan cetak Kwitansi & Faktur.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 animate-in fade-in duration-300">
        
        {/* Left Input Fields Panel */}
        <div className="lg:col-span-8 space-y-5">
          
          {/* Section 1: Informasi Pelanggan & Invoice */}
          <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-200/60 dark:border-slate-900 shadow-sm space-y-4">
            <div className="flex items-center space-x-1.5 border-b border-slate-100 dark:border-slate-900 pb-2">
              <i className="fa-solid fa-user-check text-[10px] text-sky-500"></i>
              <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">1. Data Pelanggan & Status</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Tanggal Kegiatan</label>
                <input 
                  type="date"
                  value={saleDate}
                  onChange={(e) => setSaleDate(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-850 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-850 dark:text-slate-200 font-bold transition focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Pelanggan</label>
                <select 
                  value={selectedCustomer}
                  onChange={(e) => setSelectedCustomer(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-805 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-800 dark:text-slate-200 font-medium transition focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                >
                  <option value="Umum">-- Pelanggan Umum --</option>
                  <option value="Manual">Pelanggan Manual (+)</option>
                  {customers.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
                
                {selectedCustomer === "Manual" && (
                  <input 
                    type="text" 
                    value={manualCustomerName}
                    onChange={(e) => setManualCustomerName(e.target.value)}
                    placeholder="Nama pelanggan baru..." 
                    className="w-full mt-1.5 bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-805 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-900 dark:text-white font-medium focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                  />
                )}
              </div>

              <div>
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Metode Bayar</label>
                <select 
                  value={paymentMethod}
                  onChange={(e) => {
                    setPaymentMethod(e.target.value);
                    if (e.target.value === "Piutang") {
                      setSaleStatus("Belum Lunas (Unpaid)");
                    } else {
                      setSaleStatus("Lunas (Paid)");
                    }
                  }}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-850 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-800 dark:text-slate-200 font-medium transition focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                >
                  <option value="Tunai">Tunai / Cash</option>
                  <option value="Transfer">Bank Transfer</option>
                  <option value="Piutang">Piutang / Tempo</option>
                </select>
              </div>

              <div>
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Status Pembayaran</label>
                <select 
                  value={saleStatus}
                  onChange={(e) => setSaleStatus(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/60 dark:border-slate-850 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-800 dark:text-slate-200 font-bold transition focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                >
                  <option value="Lunas (Paid)">Lunas (Paid)</option>
                  <option value="Belum Lunas (Unpaid)">Belum Lunas (Unpaid)</option>
                </select>
              </div>
            </div>

            <div className="bg-slate-50/50 dark:bg-slate-900/10 p-3 rounded-lg border border-slate-200/40 dark:border-slate-900 space-y-1.5">
              <div className="flex items-center space-x-1.5">
                <i className="fa-solid fa-receipt text-[10px] text-indigo-500"></i>
                <label className="block text-[9px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Keterangan Belanja Utama (Kwitansi &quot;Sebab Pembayaran&quot;)
                </label>
              </div>
              <input 
                type="text" 
                value={generalKeteranganBelanja}
                onChange={(e) => setGeneralKeteranganBelanja(e.target.value)}
                placeholder="E.g. Pembayaran Jasa Fotocopy Bahan UTS MK Agama & Cetak Lembar Jawaban..." 
                className="w-full bg-white dark:bg-slate-950 border border-slate-205 dark:border-slate-850 text-xs rounded-lg px-2.5 py-2 outline-none text-slate-900 dark:text-white font-semibold transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 placeholder-slate-450"
              />
              <span className="block text-[8px] text-slate-400 font-normal">
                💡 Teks ini dicetak langsung di Kwitansi pada bagian <strong className="text-slate-600 dark:text-slate-450">&quot;Untuk Pembayaran Ke&quot;</strong> / kolom rincian utama.
              </span>
            </div>
          </div>

          {/* Section 2: Pembuat Detail Item/Jasa (Minimalist Rows) */}
          <div className="bg-white dark:bg-slate-950 p-5 rounded-2xl border border-slate-200/60 dark:border-slate-900 shadow-sm space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-900 pb-2">
              <div className="flex items-center space-x-1.5">
                <i className="fa-solid fa-boxes-stacked text-[10px] text-emerald-500"></i>
                <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">2. Rincian Item / Kegiatan Jasa</h3>
              </div>
              
              {/* Reset item handler link */}
              <button 
                type="button" 
                onClick={() => {
                  setItemName("");
                  setItemDesc("");
                  setVolume("1");
                  setQuantity("1");
                  setUnitPrice("");
                  setActiveSelectedItemId(null);
                }}
                className="text-[9px] text-slate-400 hover:text-rose-500 transition font-bold uppercase"
              >
                Clear Form
              </button>
            </div>

            {/* Row 1: Nama Item & Kategori */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-8">
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Nama Barang / Jasa Kegiatan</label>
                <input 
                  type="text" 
                  value={itemName}
                  onChange={(e) => handleItemNameChange(e.target.value)}
                  onKeyDown={handleInputKeyDown}
                  list="master-items-datalist"
                  placeholder="E.g. Fotocopy Bahan UTS MK Pancasila..." 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/65 dark:border-slate-805 text-xs rounded-lg px-2.5 py-1.5 outline-none text-slate-900 dark:text-white font-semibold focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                />
                <datalist id="master-items-datalist">
                  {items.map((item) => (
                    <option key={item.id} value={item.name}>
                      {item.category} • {formatIDR(item.sellPrice)} {item.stock < item.minStock ? '(Stok kritis)' : ''}
                    </option>
                  ))}
                </datalist>
              </div>
              <div className="md:col-span-4">
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wide mb-1">Kategori / Unit Kerja</label>
                <select 
                  value={itemCategory}
                  onChange={(e) => handleCategoryChange(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/65 dark:border-slate-805 text-xs rounded-lg px-2.5 py-1.5 outline-none text-slate-800 dark:text-slate-200 font-medium focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                >
                  <option value="Fotocopy">Fotocopy / Jasa Cetak</option>
                  <option value="Jilid">Jasa Jilid / Finishing</option>
                  <option value="ATK">Alat Tulis Kantor (ATK)</option>
                  <option value="Lainnya">Lainnya / Umum</option>
                </select>
              </div>
            </div>

            {/* Row 2: Deskripsi Catatan Kecil (Opsional) */}
            <div>
              <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">Keterangan Tambahan <span className="text-slate-400 font-normal">(E.g. Mika bening, cover biru)</span></label>
              <input 
                type="text" 
                value={itemDesc}
                onChange={(e) => setItemDesc(e.target.value)}
                onKeyDown={handleInputKeyDown}
                placeholder="Spesifikasi opsional khusus item ini..." 
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200/65 dark:border-slate-805 text-xs rounded-lg px-2.5 py-1.5 outline-none text-slate-900 dark:text-white focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
              />
            </div>

            {/* Row 3: Math Multipliers Grid (Super Minimalist & Elegant 12-Column Grid Row) */}
            <div className="bg-slate-50/50 dark:bg-slate-900/10 p-3 rounded-lg border border-slate-250/30 dark:border-slate-900">
              <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider mb-2">Matriks Multiplier Vol & Price</span>
              
              <div className="grid grid-cols-12 gap-2 items-end">
                {/* Vol (Kali) */}
                <div className="col-span-3 sm:col-span-2 min-w-0">
                  <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wide mb-1 truncate">Vol (Kali)</label>
                  <input 
                    type="number" 
                    min="1" 
                    value={volume}
                    onChange={(e) => setVolume(e.target.value)}
                    onKeyDown={handleInputKeyDown}
                    className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-805 text-xs rounded-lg px-2 py-1.5 outline-none text-center font-bold text-slate-900 dark:text-white focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                {/* Multiply sign */}
                <div className="col-span-1 flex items-center justify-center pb-2 text-slate-450 font-black text-xs select-none">
                  ✕
                </div>

                {/* Qty Satuan */}
                <div className="col-span-3 sm:col-span-2 min-w-0">
                  <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wide mb-1 truncate">Qty Satuan</label>
                  <input 
                    type="number" 
                    min="1" 
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    onKeyDown={handleInputKeyDown}
                    className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 text-xs rounded-lg px-2 py-1.5 outline-none text-center font-bold text-slate-900 dark:text-white focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                {/* Nama Satuan */}
                <div className="col-span-5 sm:col-span-3">
                  <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wide mb-1 truncate">Nama Satuan</label>
                  <input 
                    type="text" 
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    onKeyDown={handleInputKeyDown}
                    placeholder="Lembar/Buku"
                    className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 text-xs rounded-lg px-2.5 py-1.5 outline-none text-center text-slate-900 dark:text-white focus:ring-1 focus:ring-sky-500"
                  />
                </div>

                {/* Harga Satuan (Rp) */}
                <div className="col-span-12 sm:col-span-5 mt-2 sm:mt-0">
                  <label className="block text-[8px] font-bold text-slate-400 uppercase tracking-wide mb-1 truncate">Harga Satuan (Rp)</label>
                  <div className="relative">
                    <span className="absolute left-2.5 top-1.5 text-[8px] font-bold text-slate-400">Rp</span>
                    <input 
                      type="number" 
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      onKeyDown={handleInputKeyDown}
                      placeholder="Harga Satuan..." 
                      className="w-full pl-6 pr-2.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-850 text-xs rounded-lg px-2 py-1.5 outline-none font-bold text-slate-900 dark:text-white text-right focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Row 4: PPN & Master Items Selection UI */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center pt-1.5 border-t border-slate-100/80 dark:border-slate-900/60 mt-2">
              <div className="md:col-span-4">
                <label className="block text-[9px] font-bold text-slate-400 uppercase tracking-wider mb-1">PPN Terhutang</label>
                <select 
                  value={taxRate}
                  onChange={(e) => setTaxRate(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200/60 dark:border-slate-805 text-xs rounded-lg px-2.5 py-1.5 outline-none text-slate-800 dark:text-slate-200 font-medium"
                >
                  <option value="0">0% (Bebas PPN)</option>
                  <option value="11">11% (Dikenai PPN)</option>
                </select>
              </div>

              {/* Master Item Chip selects */}
              <div className="md:col-span-8">
                <span className="text-[9px] font-bold text-slate-400 block mb-1 uppercase tracking-wider">Pilih Cepat Item Master</span>
                <div className="flex flex-wrap gap-1 max-h-[60px] overflow-y-auto pr-1">
                  {items.map(item => {
                    const isCrit = item.stock <= item.minStock;
                    const isSelected = activeSelectedItemId === item.id;
                    let btnStyle = isSelected 
                      ? "bg-sky-500 border-sky-600 text-white" 
                      : "bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-850 border-slate-205 dark:border-slate-805 text-slate-650 dark:text-slate-350";
                    if (isCrit && item.category !== "Fotocopy" && item.category !== "Jilid") {
                      btnStyle = isSelected
                        ? "bg-rose-500 border-rose-650 text-white"
                        : "bg-rose-50/50 dark:bg-rose-950/10 text-rose-500 border-rose-200/30 hover:bg-rose-500 hover:text-white";
                    }

                    return (
                      <button 
                        key={item.id}
                        type="button"
                        onClick={() => handleQuickSelect(item)}
                        className={`px-2 py-1 rounded-md text-[9px] font-bold border transition cursor-pointer ${btnStyle}`}
                      >
                        {item.name}
                      </button>
                    );
                  })}
                  {items.length === 0 && (
                    <span className="text-[10px] text-slate-400 italic">No master items available</span>
                  )}
                </div>
              </div>
            </div>

            {/* Redesigned Subtotal & Basket Action Bar (Sleek, horizontal flex design) */}
            <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center py-3 px-4 bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-900/30 dark:to-slate-900/65 rounded-xl border border-slate-150/65 dark:border-slate-900 gap-3">
              <div className="flex flex-col">
                <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest text-[8px]">Kalkulasi baris</span>
                <div className="text-slate-950 dark:text-white font-black text-sm mt-0.5 flex items-baseline gap-1.5">
                  <span className="text-sky-500 font-bold text-base">{formatIDR(lineSubtotal)}</span>
                  <span className="text-[9px] text-slate-400 font-normal">({volume} &times; {quantity} {unit})</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <button 
                  type="button" 
                  onClick={handleAddLineToCart}
                  className="flex-1 sm:flex-none bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs px-5 py-2.5 rounded-lg shadow-sm active:scale-[0.98] transition flex items-center justify-center space-x-1.5 cursor-pointer"
                >
                  <i className="fa-solid fa-cart-plus text-xs"></i>
                  <span>Masukkan ke Keranjang</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Active Cart & Checkout Panel */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200/80 dark:border-slate-850 shadow-sm flex flex-col justify-between min-h-[460px] h-fit lg:sticky lg:top-4 space-y-6">
          <div>
            <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-850 pb-2.5 mb-3">
              <h3 className="text-[11px] font-bold text-slate-500 uppercase tracking-widest tracking-wider flex items-center space-x-1.5">
                <i className="fa-solid fa-shopping-basket text-sky-500"></i>
                <span>Ringkasan Keranjang</span>
              </h3>
              <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-500 text-[10px] font-extrabold px-2 py-0.5 rounded-full">
                {cart.length} item
              </span>
            </div>
            
            <div className="max-h-[310px] overflow-y-auto space-y-2.5 pr-1">
              {cart.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start bg-slate-50/80 dark:bg-slate-900/40 p-3 rounded-xl border border-slate-200/40 dark:border-slate-850 transition hover:border-slate-300 dark:hover:border-slate-800 text-xs">
                  <div className="space-y-1 max-w-[170px]">
                    <strong className="block truncate text-slate-900 dark:text-white font-bold">{item.name}</strong>
                    <span className="text-[10px] text-slate-500 block font-semibold">{item.qty} {item.unit} x {formatIDR(item.price)}</span>
                    {item.desc && (
                      <span className="text-[9px] text-indigo-500 dark:text-indigo-400 block italic leading-tight bg-indigo-50/40 dark:bg-indigo-950/10 px-1.5 py-0.5 rounded-md mt-1 w-fit max-w-full truncate">{item.desc}</span>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="font-extrabold text-sky-500 text-right">{formatIDR(item.qty * item.price)}</span>
                    <button 
                      type="button" 
                      onClick={() => handleRemoveFromCart(idx)}
                      className="text-slate-400 hover:text-rose-500 p-1 cursor-pointer transition"
                      title="Hapus baris ini"
                    >
                      <i className="fa-solid fa-trash-can text-xs"></i>
                    </button>
                  </div>
                </div>
              ))}
              
              {cart.length === 0 && (
                <div className="text-center py-16 text-slate-450 text-[11px] font-medium flex flex-col items-center justify-center space-y-2">
                  <i className="fa-solid fa-cart-arrow-down text-2xl text-slate-300 dark:text-slate-700"></i>
                  <span className="italic block text-slate-400">Keranjang transaksi masih kosong</span>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-3.5 border-t dark:border-slate-850 pt-4 text-xs font-bold text-slate-650 dark:text-slate-350">
            <div className="flex justify-between font-medium">
              <span className="text-slate-455">Subtotal Belanja</span>
              <span className="font-mono text-slate-900 dark:text-white">{formatIDR(cartSubtotal)}</span>
            </div>
            
            <div className="flex justify-between items-center font-medium">
              <span className="text-slate-455">Diskon Belanja (%)</span>
              <div className="relative">
                <input 
                  type="number" 
                  min="0" 
                  max="100" 
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(e.target.value)}
                  className="w-16 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-1.5 pr-4 text-right text-xs outline-none text-slate-900 dark:text-white font-bold [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                />
                <span className="absolute right-1.5 top-1.5 text-[10px] text-slate-400">%</span>
              </div>
            </div>

            <div className="flex justify-between font-medium">
              <span className="text-slate-455">PPN Pajak</span>
              <span className="font-mono text-slate-900 dark:text-white">{formatIDR(cartPpn)}</span>
            </div>

            <div className="flex justify-between text-sm text-emerald-600 dark:text-emerald-450 font-black border-t border-dashed dark:border-slate-850 pt-3 flex-wrap">
              <span>TOTAL CHECKOUT</span>
              <span className="font-mono text-base">{formatIDR(grandTotal)}</span>
            </div>

            {/* Simpan & Checkout Button */}
            <button 
              type="button"
              onClick={handleCheckout}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3.5 rounded-xl transition shadow-md shadow-emerald-600/10 hover:shadow-emerald-600/20 active:scale-[0.99] flex items-center justify-center space-x-2 text-xs cursor-pointer mt-2"
            >
              <i className="fa-solid fa-circle-check text-sm animate-pulse-slow"></i>
              <span>Simpan & Checkout Nota</span>
            </button>
          </div>
        </div>
      </div>

      {/* SUCCESS MODAL OVERLAY */}
      {showSuccessModal && lastSavedSale && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[999]">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", duration: 0.5 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 dark:border-slate-800 p-6 text-center space-y-6"
          >
            <div className="flex flex-col items-center">
              {/* Animated Success Check Circle */}
              <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-500 rounded-full flex items-center justify-center mb-4 border border-emerald-250/20 shadow-inner">
                <motion.i 
                  initial={{ scale: 0, rotate: -45 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: "spring", delay: 0.15, stiffness: 200 }}
                  className="fa-solid fa-check text-2xl"
                ></motion.i>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
                Transaksi Berhasil Disimpan!
              </h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs font-semibold leading-normal mt-1">
                Nota &amp; Rincian Belanja telah tercatat di basis data transaksi dan stok barang telah dikurangi.
              </p>
            </div>

            {/* Receipt Summary Box */}
            <div className="bg-slate-50 dark:bg-slate-900/50 p-4 rounded-xl border border-slate-200/50 dark:border-slate-850/80 text-left text-xs space-y-2.5">
              <div className="flex justify-between items-center text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <span>Invoice No</span>
                <span className="font-mono text-sky-500 font-extrabold">{lastSavedSale.invoiceNo}</span>
              </div>
              <div className="border-t border-slate-100 dark:border-slate-850 my-1 pt-1 space-y-2 font-semibold">
                <div className="flex justify-between">
                  <span className="text-slate-400">Pelanggan:</span>
                  <span className="text-slate-900 dark:text-slate-300 font-bold">{lastSavedSale.pelanggan}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Metode Bayar:</span>
                  <span className="text-slate-900 dark:text-slate-300 font-bold">{lastSavedSale.metodeBayar}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Status:</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">{lastSavedSale.status}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-dashed dark:border-slate-800 text-sm font-black text-slate-950 dark:text-white">
                  <span>Total Transaksi:</span>
                  <span className="font-mono text-emerald-500">{formatIDR(lastSavedSale.total)}</span>
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="grid grid-cols-2 gap-2 pb-1 text-xs">
              <button
                type="button"
                onClick={() => {
                  if (onViewInvoice) onViewInvoice(lastSavedSale, 'faktur');
                }}
                className="w-full bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-850 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <i className="fa-solid fa-file-invoice text-sky-500"></i>
                Cetak Faktur
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onViewInvoice) onViewInvoice(lastSavedSale, 'kwitansi');
                }}
                className="w-full bg-slate-50 hover:bg-slate-100 dark:bg-slate-900 dark:hover:bg-slate-850 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-800 font-bold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
              >
                <i className="fa-solid fa-receipt text-indigo-500"></i>
                Cetak Kwitansi
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowSuccessModal(false);
                setLastSavedSale(null);
              }}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 rounded-xl transition shadow-md cursor-pointer text-xs animate-bounce-slow"
            >
              Mulai Transaksi Baru
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
