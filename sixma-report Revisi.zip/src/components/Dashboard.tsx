/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sale, Expense, AuditLog } from '../types';
import { formatIDR } from '../utils';

interface DashboardProps {
  sales: Sale[];
  expenses: Expense[];
  logs: AuditLog[];
}

export function Dashboard({ sales, expenses, logs }: DashboardProps) {
  const [selectedYear, setSelectedYear] = useState<string>("2026");

  // Calculations
  const totalOmset = sales.reduce((acc, curr) => acc + curr.subtotal, 0);
  const totalPpn = sales.reduce((acc, curr) => acc + curr.tax, 0);
  const totalPengeluaran = expenses.reduce((acc, curr) => acc + curr.jumlah, 0);
  const labaBersih = (totalOmset + totalPpn) - totalPengeluaran;

  // Render SVG charts
  // Monthly calculations for 2026
  const monthlyIncome = Array(12).fill(0);
  const monthlyExpense = Array(12).fill(0);

  sales.forEach(s => {
    const parts = s.tanggal.split(' ')[0].split('-');
    if (parts[0] === selectedYear) {
      const monthIndex = parseInt(parts[1]) - 1;
      if (monthIndex >= 0 && monthIndex < 12) {
        monthlyIncome[monthIndex] += s.subtotal;
      }
    }
  });

  expenses.forEach(e => {
    const parts = e.tanggal.split('-');
    if (parts[0] === selectedYear) {
      const monthIndex = parseInt(parts[1]) - 1;
      if (monthIndex >= 0 && monthIndex < 12) {
        monthlyExpense[monthIndex] += e.jumlah;
      }
    }
  });

  // Calculate highest monthly value to dynamically scale the SVG chart
  const maxVal = Math.max(...monthlyIncome, ...monthlyExpense, 10000); // at least 10k to prevent division by zero

  // Category distributions
  const categorySummary: Record<string, number> = {
    "Fotocopy": 0,
    "Jilid": 0,
    "ATK": 0,
    "Lainnya": 0
  };

  sales.forEach(s => {
    s.itemDetail.forEach(item => {
      // Find category or classify
      let cat = "Lainnya";
      if (item.id.startsWith("FT")) cat = "Fotocopy";
      else if (item.id.startsWith("JL")) cat = "Jilid";
      else if (item.id.startsWith("ATK")) cat = "ATK";

      if (categorySummary[cat] !== undefined) {
        categorySummary[cat] += item.qty * item.price;
      } else {
        categorySummary["Lainnya"] += item.qty * item.price;
      }
    });
  });

  const totalCategoryVal = Object.values(categorySummary).reduce((a, b) => a + b, 0) || 1;

  // Build doughnut segments
  let accumulatedAngle = 0;
  const segments = Object.entries(categorySummary).map(([cat, val]) => {
    const percentage = val / totalCategoryVal;
    const angle = percentage * 360;
    const startAngle = accumulatedAngle;
    accumulatedAngle += angle;

    // SVG arc details
    const r = 60;
    const cx = 100;
    const cy = 100;
    
    // Radian conversion
    const radStart = ((startAngle - 90) * Math.PI) / 180;
    const radEnd = ((accumulatedAngle - 90) * Math.PI) / 180;

    const x1 = cx + r * Math.cos(radStart);
    const y1 = cy + r * Math.sin(radStart);
    const x2 = cx + r * Math.cos(radEnd);
    const y2 = cy + r * Math.sin(radEnd);

    const largeArc = angle > 180 ? 1 : 0;

    // Path command
    let d = "";
    if (percentage === 1) {
      d = `M ${cx} ${cy - r} A ${r} ${r} 0 1 1 ${cx - 0.01} ${cy - r}`;
    } else if (percentage > 0) {
      d = `M ${x1} ${y1} A ${r} ${r} 0 ${largeArc} 1 ${x2} ${y2}`;
    }

    return {
      category: cat,
      value: val,
      percentage: Math.round(percentage * 100),
      d,
      color: cat === "Fotocopy" ? "#0ea5e9" : cat === "Jilid" ? "#6366f1" : cat === "ATK" ? "#f59e0b" : "#10b981"
    };
  });

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

  return (
    <div className="space-y-6">
      {/* Tab Header Banner */}
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Ringkasan Eksekutif ERP</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Status rekapitulasi data keuangan, total volume, dan audit log secara terintegrasi.</p>
        </div>
        <select 
          value={selectedYear} 
          onChange={(e) => setSelectedYear(e.target.value)}
          className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 text-xs font-bold rounded-lg px-4 py-2 outline-none text-slate-800 dark:text-slate-200 cursor-pointer transition"
        >
          <option value="2026">Tahun Buku 2026</option>
          <option value="2025">Tahun Buku 2025</option>
        </select>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm transition hover:scale-[1.01]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">TOTAL VOLUME OMSET</span>
          <h3 className="text-2xl font-extrabold text-sky-500 mt-2">{formatIDR(totalOmset)}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Akumulasi hasil penjualan bruto</p>
        </div>
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm transition hover:scale-[1.01]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">TOTAL PPN TERKUMPUL</span>
          <h3 className="text-2xl font-extrabold text-indigo-500 mt-2">{formatIDR(totalPpn)}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Pajak Pertambahan Nilai 11% / 0%</p>
        </div>
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm transition hover:scale-[1.01]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">EXPENSE OPERASIONAL</span>
          <h3 className="text-2xl font-extrabold text-rose-500 mt-2">{formatIDR(totalPengeluaran)}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Biaya dan belanja bahan baku</p>
        </div>
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm transition hover:scale-[1.01]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">ESTIMASI LABA BERSIH</span>
          <h3 className="text-2xl font-extrabold text-emerald-500 mt-2">{formatIDR(labaBersih)}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Selisih laba kotor dikurangi biaya</p>
        </div>
      </div>

      {/* Handcrafted Visual SVG Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Income vs Expenses Bar Chart */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-6 border-b dark:border-slate-850 pb-3">GRAFIK PERBANDINGAN PENDAPATAN & BIAYA</h3>
          
          <div className="flex-1 w-full flex flex-col justify-between">
            {/* SVG Visualizer */}
            <div className="w-full h-64 select-none">
              <svg viewBox="0 0 540 240" className="w-full h-full font-sans">
                {/* Horizontal gridlines */}
                {[0, 0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                  const y = 20 + 170 * (1 - ratio);
                  return (
                    <g key={idx}>
                      <line x1="50" y1={y} x2="520" y2={y} stroke="#e2e8f0" strokeDasharray="4 4" className="dark:stroke-slate-800" strokeWidth="1" />
                      <text x="40" y={y + 4} textAnchor="end" className="fill-slate-400 text-[9px] font-mono font-medium">
                        {ratio === 0 ? "Rp 0" : (maxVal * ratio > 1000000 ? `${(maxVal * ratio / 1000000).toFixed(1)}M` : `${Math.round(maxVal * ratio / 1000)}K`)}
                      </text>
                    </g>
                  );
                })}

                {/* X axis line */}
                <line x1="50" y1="190" x2="520" y2="190" stroke="#94a3b8" strokeWidth="1.5" className="dark:stroke-slate-700" />

                {/* Bars group */}
                {monthlyIncome.map((incValue, mIdx) => {
                  const xBase = 60 + mIdx * 38;
                  const incHeight = (incValue / maxVal) * 170;
                  const expHeight = (monthlyExpense[mIdx] / maxVal) * 170;

                  return (
                    <g key={mIdx} className="group cursor-pointer">
                      {/* Tooltip triggers */}
                      <title>{`Bulan ${monthNames[mIdx]} - Pendapatan: ${formatIDR(incValue)}, Pengeluaran: ${formatIDR(monthlyExpense[mIdx])}`}</title>
                      
                      {/* Income Bar */}
                      <rect 
                        x={xBase} 
                        y={190 - incHeight} 
                        width="11" 
                        height={Math.max(incHeight, 2)} 
                        fill="#0ea5e9" 
                        rx="2" 
                        className="transition-all duration-300 hover:fill-sky-400"
                      />
                      
                      {/* Expense Bar */}
                      <rect 
                        x={xBase + 13} 
                        y={190 - expHeight} 
                        width="11" 
                        height={Math.max(expHeight, 2)} 
                        fill="#f43f5e" 
                        rx="2" 
                        className="transition-all duration-300 hover:fill-rose-400"
                      />

                      {/* Month Text */}
                      <text x={xBase + 12} y="208" textAnchor="middle" className="fill-slate-500 text-[10px] font-bold dark:fill-slate-400">
                        {monthNames[mIdx]}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Legend Indicators */}
            <div className="flex justify-center items-center space-x-6 text-[11px] font-bold pt-4 border-t border-slate-100 dark:border-slate-850 mt-2">
              <div className="flex items-center space-x-2">
                <span className="w-3.5 h-3.5 bg-sky-500 rounded-md"></span>
                <span className="text-slate-600 dark:text-slate-300">Pendapatan Jasa & ATK</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-3.5 h-3.5 bg-rose-500 rounded-md"></span>
                <span className="text-slate-600 dark:text-slate-300">Pengeluaran Operasional / Belanja</span>
              </div>
            </div>
          </div>
        </div>

        {/* Doughnut distribution chart */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 border-b dark:border-slate-850 pb-3">DISTRIBUSI KEGIATAN OMSET</h3>
            
            <div className="relative w-full h-44 flex items-center justify-center my-2">
              {totalCategoryVal > 1 ? (
                <svg viewBox="0 0 200 200" className="w-40 h-40">
                  {segments.map((seg, idx) => {
                    if (seg.percentage === 0) return null;
                    return (
                      <g key={idx} className="group">
                        <title>{`${seg.category}: ${formatIDR(seg.value)} (${seg.percentage}%)`}</title>
                        <path 
                          d={seg.d} 
                          fill="none" 
                          stroke={seg.color} 
                          strokeWidth="24"
                          className="transition-all duration-300 hover:stroke-slate-400 cursor-pointer"
                        />
                      </g>
                    );
                  })}
                  {/* Center punch text */}
                  <circle cx="100" cy="100" r="48" className="fill-white dark:fill-slate-950" />
                  <text x="100" y="98" textAnchor="middle" className="fill-slate-400 text-[9px] font-bold uppercase tracking-wider">TOTAL VALUE</text>
                  <text x="100" y="113" textAnchor="middle" className="fill-slate-900 dark:fill-white text-[11px] font-extrabold">
                    {totalCategoryVal > 1000000 ? `${(totalCategoryVal/1000000).toFixed(1)}M` : `${Math.round(totalCategoryVal/1000)}K`}
                  </text>
                </svg>
              ) : (
                <div className="text-[11px] text-slate-400 italic">No category data recorded</div>
              )}
            </div>
          </div>

          <div className="space-y-2 text-[11px] pt-4 border-t border-slate-100 dark:border-slate-850 font-bold text-slate-600 dark:text-slate-300">
            {segments.map((seg, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: seg.color }}></span>
                  <span className="capitalize">{seg.category}</span>
                </div>
                <div className="text-right">
                  <span>{formatIDR(seg.value)}</span>
                  <span className="text-slate-400 ml-1.5 text-[10px] font-medium font-mono">({seg.percentage}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Log Feed */}
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col">
        <div className="border-b dark:border-slate-850 pb-3 mb-4 flex justify-between items-center">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">LOG AKTIVITAS & AUDIT KEAMANAN SISTEM</h3>
          <span className="bg-emerald-500/10 text-emerald-500 font-mono text-[9px] font-bold px-2 py-0.5 rounded animate-pulse-slow">LIVE FEED</span>
        </div>
        
        <div className="divide-y divide-slate-100 dark:divide-slate-850 max-h-52 overflow-y-auto space-y-2 pr-1">
          {logs.slice().reverse().map((log, idx) => {
            const isSecurity = log.aksi === "Security Audit" || log.aksi.toLowerCase().includes("hapus") || log.aksi.toLowerCase().includes("keluar");
            const badgeStyle = isSecurity 
              ? "bg-rose-500/10 text-rose-500 border-rose-500/20" 
              : "bg-sky-500/10 text-sky-500 border-sky-500/20";

            return (
              <div key={idx} className="py-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className={`font-extrabold px-1.5 py-0.5 rounded text-[9px] uppercase border ${badgeStyle}`}>
                      {log.aksi}
                    </span>
                    <span className="text-slate-400 text-[10px] font-mono">{log.tanggal}</span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300 font-medium">{log.keterangan}</p>
                </div>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold bg-slate-50 dark:bg-slate-900/40 px-2 py-0.5 rounded-md self-end sm:self-auto uppercase">
                  @{log.user}
                </span>
              </div>
            );
          })}
          {logs.length === 0 && (
            <div className="text-center py-6 text-xs text-slate-400 italic">Belum ada log log aktivitas terekam</div>
          )}
        </div>
      </div>
    </div>
  );
}
