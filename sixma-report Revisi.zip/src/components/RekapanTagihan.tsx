/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sale } from '../types';
import { formatIDR } from '../utils';

interface RekapanTagihanProps {
  sales: Sale[];
}

interface CustomerDebtSummary {
  name: string;
  totalTransaction: number;
  totalPaid: number;
  totalPiutang: number;
}

export function RekapanTagihan({ sales }: RekapanTagihanProps) {
  const [search, setSearch] = useState("");

  const customerSummary: Record<string, CustomerDebtSummary> = {};

  sales.forEach(sale => {
    const name = sale.pelanggan;
    if (!customerSummary[name]) {
      customerSummary[name] = {
        name,
        totalTransaction: 0,
        totalPaid: 0,
        totalPiutang: 0
      };
    }

    customerSummary[name].totalTransaction += sale.total;
    if (sale.status === "Lunas (Paid)") {
      customerSummary[name].totalPaid += sale.total;
    } else {
      customerSummary[name].totalPiutang += sale.total;
    }
  });

  const summaryList = Object.values(customerSummary);

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Rekapan Tagihan Pelanggan</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Status neraca penagihan piutang dan pembayaran total per pelanggan instansi secara terintegrasi.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <input 
            type="text" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari pelanggan..." 
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg outline-none text-slate-800 dark:text-slate-200 focus:ring-1 focus:ring-sky-500"
          />
          <i className="fa-solid fa-search absolute left-3 top-3 text-slate-400 text-xs"></i>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-850 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4">Nama Pelanggan</th>
                <th className="p-4 text-right">Total Transaksi</th>
                <th className="p-4 text-right">Total Terbayar (Lunas)</th>
                <th className="p-4 text-right">Sisa Tagihan (Piutang)</th>
                <th className="p-4 text-center">Status Tagihan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-300">
              {[...summaryList]
                .filter(rec => rec.name.toLowerCase().includes(search.toLowerCase()))
                .sort((a, b) => a.name.localeCompare(b.name, 'id'))
                .map((rec, index) => {
                  const hasDebt = rec.totalPiutang > 0;
                  const statusLabel = hasDebt ? "Sisa Piutang" : "Lunas";
                  const badgeStyle = hasDebt
                    ? "bg-rose-500/10 text-rose-500 border border-rose-500/15 animate-pulse"
                    : "bg-emerald-500/10 text-emerald-500 border border-emerald-500/15";

                  return (
                    <tr key={rec.name} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition border-b dark:border-slate-850">
                      <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                      <td className="p-4 font-extrabold text-slate-900 dark:text-white">{rec.name}</td>
                      <td className="p-4 text-right font-semibold font-mono">{formatIDR(rec.totalTransaction)}</td>
                      <td className="p-4 text-right text-emerald-500 font-bold font-mono">{formatIDR(rec.totalPaid)}</td>
                      <td className="p-4 text-right text-rose-500 font-black font-mono">{formatIDR(rec.totalPiutang)}</td>
                      <td className="p-4 text-center">
                        <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${badgeStyle}`}>
                          {statusLabel}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              {summaryList.length === 0 && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400 italic">Belum ada rekapan tagihan diringkas</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
