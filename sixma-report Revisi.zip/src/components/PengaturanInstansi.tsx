/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, User } from '../types';

interface PengaturanInstansiProps {
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
  users: User[];
  onUsersChange: (users: User[]) => void;
  currentUser: User | null;
  addLog: (action: string, detail: string) => void;
}

export function PengaturanInstansi({ settings, onSettingsChange, users, onUsersChange, currentUser, addLog }: PengaturanInstansiProps) {
  // Institution identity parameters
  const [companyName, setCompanyName] = useState(settings.companyName || "");
  const [companyAddress, setCompanyAddress] = useState(settings.companyAddress || "");
  const [ownerName, setOwnerName] = useState(settings.ownerName || "");
  const [ownerBankName, setOwnerBankName] = useState(settings.ownerBankName || "");
  const [ownerBankNo, setOwnerBankNo] = useState(settings.ownerBankNo || "");
  const [ownerNpwp, setOwnerNpwp] = useState(settings.ownerNpwp || "");
  const [gasUrl, setGasUrl] = useState(settings.gasUrl || "");
  const [sumberDana, setSumberDana] = useState(settings.sumberDana || "");

  // Add new user states
  const [newUsername, setNewUsername] = useState("");
  const [newRole, setNewRole] = useState<'Admin' | 'Operator'>("Operator");
  const [newPassword, setNewPassword] = useState("");

  const handleIdentitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Settings = {
      ...settings,
      companyName,
      companyAddress,
      ownerName,
      ownerBankName,
      ownerBankNo,
      ownerNpwp,
      gasUrl,
      sumberDana
    };
    onSettingsChange(updated);
    addLog("Koreksi Pengaturan", "Memperbarui konfigurasi parameter data instansi");
    alert("Informasi identitas instansi / pemilik berhasil disimpan!");
  };

  // Base64 File Uploader conversions
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'logo' | 'kopSurat' | 'signature' | 'stamp') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        onSettingsChange({
          ...settings,
          [field]: base64
        });
        addLog("Unggah Berkas", `Berhasil memperbarui berkas gambar ${field}`);
        alert(`Berkas gambar ${field} berhasil diunggah dan disimpan!`);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddUser = () => {
    const username = newUsername.trim().toLowerCase();
    const pass = newPassword.trim();

    if (!username || !pass) {
      alert("Mohon lengkapi username dan password baru!");
      return;
    }

    if (users.some(u => u.username === username)) {
      alert("Username tersebut sudah digunakan oleh akun lain!");
      return;
    }

    const id = "U-" + Math.floor(100 + Math.random() * 900);
    const newUser: User = {
      id,
      username,
      password: pass,
      role: newRole,
      name: `${username.toUpperCase()} (${newRole})`
    };

    onUsersChange([...users, newUser]);
    addLog("Registrasi User", `Mendaftarkan akun multi-user baru: @${username}`);
    
    // reset
    setNewUsername("");
    setNewPassword("");
    alert(`Akun baru @${username} (${newRole}) berhasil didaftarkan!`);
  };

  const handleDeleteUser = (id: string, name: string) => {
    if (id === currentUser?.id) {
      alert("Anda dilarang menghapus akun yang sedang mengendalikan sesi aktif!");
      return;
    }
    if (confirm(`Yakin ingin menonaktifkan/menghapus akun multi-user @${name}?`)) {
      onUsersChange(users.filter(u => u.id !== id));
      addLog("Hapus User", `Menghapus akun pengguna ${name}`);
      alert("Akun berhasil dinonaktifkan.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Pengaturan Instansi & Keamanan Pengguna</h2>
        <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Mengelola identitas usaha, mengunggah kop surat, tanda tangan, stempel, dan manajemen multi-akun pengguna.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Side: Corporate parameters */}
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 border-b dark:border-slate-850 pb-2">Identitas Usaha & Cetakan Dokumen</h3>
          
          <form onSubmit={handleIdentitySubmit} className="space-y-4 text-xs font-semibold text-slate-700 dark:text-slate-300">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block mb-1.5 font-bold">Nama Perusahaan/Usaha</label>
                <input 
                  type="text" 
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block mb-1.5 font-bold">Nama Pemilik (Owner)</label>
                <input 
                  type="text" 
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block mb-1.5 font-bold">Nama Bank Konfirmasi TF</label>
                <input 
                  type="text" 
                  value={ownerBankName}
                  onChange={(e) => setOwnerBankName(e.target.value)}
                  placeholder="BCA / Mandiri / BRI"
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block mb-1.5 font-bold">Nomor Rekening</label>
                <input 
                  type="text" 
                  value={ownerBankNo}
                  onChange={(e) => setOwnerBankNo(e.target.value)}
                  placeholder="0123-xxxx-xxx"
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block mb-1.5 font-bold">NPWP Pemilik</label>
                <input 
                  type="text" 
                  value={ownerNpwp}
                  onChange={(e) => setOwnerNpwp(e.target.value)}
                  placeholder="12.345.xxx.x-xxx.xxx"
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block mb-1.5 font-bold">Sumber Dana</label>
                <input 
                  type="text" 
                  value={sumberDana}
                  onChange={(e) => setSumberDana(e.target.value)}
                  placeholder="Contoh: Dinas Pendidikan Prov. DKI Jakarta"
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block mb-1.5 font-bold">Alamat Lengkap Perusahaan</label>
              <textarea 
                value={companyAddress}
                onChange={(e) => setCompanyAddress(e.target.value)}
                rows={2}
                className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-2.5 outline-none resize-none text-slate-900 dark:text-white"
              />
            </div>

            {/* Graphics Attachments Uploader UI */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">Logo Aplikasi</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'logo')}
                  className="text-xs block w-full text-slate-550 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 cursor-pointer"
                />
                {settings.logo && <span className="text-[9px] text-emerald-500 block">✓ Logo terunggah</span>}
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">Kop Surat / Header</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'kopSurat')}
                  className="text-xs block w-full text-slate-550 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 cursor-pointer"
                />
                {settings.kopSurat && <span className="text-[9px] text-emerald-500 block">✓ Kop terunggah</span>}
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">Tanda Tangan</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'signature')}
                  className="text-xs block w-full text-slate-550 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 cursor-pointer"
                />
                {settings.signature && <span className="text-[9px] text-emerald-500 block">✓ Tanda tangan terunggah</span>}
              </div>
              <div className="space-y-1">
                <label className="block text-[10px] font-bold text-slate-400 uppercase">Stempel Resmi Kantor</label>
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={(e) => handleFileUpload(e, 'stamp')}
                  className="text-xs block w-full text-slate-550 file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100 cursor-pointer"
                />
                {settings.stamp && <span className="text-[9px] text-emerald-500 block">✓ Stempel terunggah</span>}
              </div>
            </div>

            <button 
              type="submit" 
              className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2.5 rounded-xl transition text-xs shadow-md mt-4 cursor-pointer"
            >
              Simpan Identitas Usaha
            </button>
          </form>
        </div>

        {/* Right Side: Accounts and Users Directory */}
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm space-y-5">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 border-b dark:border-slate-850 pb-2">Manajemen Akun Pengguna</h3>
          
          <div className="space-y-3 font-semibold text-xs">
            <span className="text-xs font-bold text-slate-750 dark:text-slate-350 block border-b dark:border-slate-850 pb-1.5">Daftar Pengguna Aktif</span>
            
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {users.map(u => (
                <div key={u.id} className="flex justify-between items-center bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-100 dark:border-slate-850">
                  <div className="space-y-1">
                    <strong className="text-slate-800 dark:text-white">{u.name}</strong>
                    <span className="text-slate-400 block font-normal text-[10px]">
                      @username: <span className="font-bold underline text-slate-600 dark:text-slate-355">@{u.username}</span> | Hak: {u.role}
                    </span>
                    <span className="text-[10px] text-slate-400 block">Sandi: <span className="font-mono text-indigo-500 font-bold">{u.password}</span></span>
                  </div>
                  
                  {currentUser?.role === 'Admin' && u.id !== currentUser.id && (
                    <button 
                      onClick={() => handleDeleteUser(u.id, u.username)}
                      className="text-rose-500 hover:text-rose-700 font-extrabold cursor-pointer transition text-[10px]"
                    >
                      Hapus Akun
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Quick adding multi-user operator */}
            {currentUser?.role === 'Admin' && (
              <div className="space-y-3 border-t dark:border-slate-850 pt-4 mt-2">
                <span className="text-xs font-bold text-slate-755 dark:text-slate-350 block">Tambahkan Akun Kasir Baru</span>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Username Pengguna</label>
                    <input 
                      type="text"
                      value={newUsername}
                      onChange={(e) => setNewUsername(e.target.value)}
                      placeholder="Username masukan..." 
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2.5 text-xs rounded-lg outline-none text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] text-slate-400 mb-1">Peran Sesi</label>
                    <select 
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value as any)}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2.5 text-xs rounded-lg outline-none text-slate-900 dark:text-white"
                    >
                      <option value="Operator">Operator (Kasir)</option>
                      <option value="Admin">Admin (Full)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-slate-400 mb-1">Kata Sandi (Password)</label>
                  <input 
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Minimal 6 karakter..." 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2.5 text-xs rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>

                <button 
                  onClick={handleAddUser}
                  className="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow transition cursor-pointer"
                >
                  Daftarkan Akun Baru
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
