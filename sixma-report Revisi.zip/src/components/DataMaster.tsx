/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Item, User } from '../types';
import { formatIDR } from '../utils';
import { motion } from 'motion/react';

interface DataMasterProps {
  items: Item[];
  onItemsChange: (items: Item[]) => void;
  currentUser: User | null;
  addLog: (action: string, detail: string) => void;
}

export function DataMaster({ items, onItemsChange, currentUser, addLog }: DataMasterProps) {
  const [search, setSearch] = useState("");
  const [katFilter, setKatFilter] = useState("Semua");

  // State for Add Item Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItemCode, setNewItemCode] = useState("");
  const [newItemName, setNewItemName] = useState("");
  const [newItemCategory, setNewItemCategory] = useState("ATK");
  const [newItemBuyPrice, setNewItemBuyPrice] = useState("");
  const [newItemSellPrice, setNewItemSellPrice] = useState("");
  const [newItemStock, setNewItemStock] = useState("");
  const [newItemMinStock, setNewItemMinStock] = useState("5");

  // State for Stok Opname Modal
  const [showOpnameModal, setShowOpnameModal] = useState(false);
  const [opnameItemId, setOpnameItemId] = useState("");
  const [opnameActualStok, setOpnameActualStok] = useState("");
  const [opnameReason, setOpnameReason] = useState("");

  const opnameSelectedItem = items.find(i => i.id === opnameItemId) || items[0];

  // Calculations for Discrepancy in Opname
  const sysStock = opnameSelectedItem ? opnameSelectedItem.stock : 0;
  const actStock = parseInt(opnameActualStok) || 0;
  const diff = actStock - sysStock;

  // Handles adding new master item
  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    const code = newItemCode.toUpperCase().trim();
    const name = newItemName.trim();
    const buyPrice = parseFloat(newItemBuyPrice) || 0;
    const sellPrice = parseFloat(newItemSellPrice) || 0;
    const stock = parseInt(newItemStock) || 0;
    const minStock = parseInt(newItemMinStock) || 0;

    if (!code || !name || !sellPrice) {
      alert("Mohon isi kode item, nama lengkap, dan harga jual barang!");
      return;
    }

    if (items.some(i => i.id === code)) {
      alert("Kode item sudah pernah terdaftar di database!");
      return;
    }

    const newItem: Item = {
      id: code,
      name,
      category: newItemCategory,
      buyPrice,
      sellPrice,
      stock,
      minStock
    };

    onItemsChange([...items, newItem]);
    addLog("Tambah Item", `Item baru ${name} (${code}) berhasil didaftarkan`);
    
    // reset form
    setNewItemCode("");
    setNewItemName("");
    setNewItemCategory("ATK");
    setNewItemBuyPrice("");
    setNewItemSellPrice("");
    setNewItemStock("");
    setNewItemMinStock("5");
    setShowAddModal(false);
  };

  // Handles correcting standard item price
  const handleEditPrice = (item: Item) => {
    const promptValue = prompt(`Koreksi Harga Jual untuk ${item.name}:`, item.sellPrice.toString());
    if (promptValue !== null) {
      const parsedPrice = parseFloat(promptValue);
      if (isNaN(parsedPrice) || parsedPrice < 0) {
        alert("Input harga jual tidak valid!");
        return;
      }
      const updated = items.map(i => {
        if (i.id === item.id) {
          return { ...i, sellPrice: parsedPrice };
        }
        return i;
      });
      onItemsChange(updated);
      addLog("Koreksi Harga", `Mengubah harga jual ${item.name} menjadi ${formatIDR(parsedPrice)}`);
    }
  };

  // Handles deleting item
  const handleDeleteItem = (id: string, name: string) => {
    if (confirm(`Apakah Anda yakin ingin menghapus item semenjana "${name}" (${id}) dari database?`)) {
      onItemsChange(items.filter(i => i.id !== id));
      addLog("Hapus Item", `Menghapus item master ${name} (${id})`);
    }
  };

  // Handles committing Stock opname physical adjustments
  const handleSaveStokOpname = () => {
    if (!opnameItemId) {
      alert("Pilih item terlebih dahulu!");
      return;
    }
    const act = parseFloat(opnameActualStok);
    if (isNaN(act) || act < 0) {
      alert("Input Stok Nyata harus berupa angka valid >= 0!");
      return;
    }

    const targetItem = items.find(i => i.id === opnameItemId);
    if (targetItem) {
      const oldStock = targetItem.stock;
      const updated = items.map(i => {
        if (i.id === opnameItemId) {
          return { ...i, stock: Math.floor(act) };
        }
        return i;
      });
      onItemsChange(updated);
      addLog("Stok Opname", `Penyesuaian stok fisik ${targetItem.name} (${opnameItemId}) dari ${oldStock} -> ${act}. Alasan: ${opnameReason || "Opname fisik reguler"}`);
      
      // Reset
      setOpnameActualStok("");
      setOpnameReason("");
      setShowOpnameModal(false);
      alert("Penyesuaian dokumen stok opname sukses disimpan!");
    }
  };

  // Trigger opening of Stok Opname
  const openOpname = () => {
    const stockable = items.filter(i => i.category !== "Fotocopy" && i.category !== "Jilid");
    if (stockable.length === 0) {
      alert("Belum ada data barang fisik (ATK/Lainnya) yang terdaftar untuk stok opname.");
      return;
    }
    setOpnameItemId(stockable[0].id);
    setOpnameActualStok(stockable[0].stock.toString());
    setShowOpnameModal(true);
  };

  const handleOpnameItemChange = (itemId: string) => {
    setOpnameItemId(itemId);
    const item = items.find(i => i.id === itemId);
    if (item) {
      setOpnameActualStok(item.stock.toString());
    }
  };

  // Low stock checks across database
  const lowStockItems = items.filter(item => item.stock <= item.minStock);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Data Master & Stok Opname Fisik</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Mengelola persediaan barang mitra, nilai HPP, harga jual, dan stok minimal.</p>
        </div>
        <div className="flex space-x-2 w-full sm:w-auto">
          <button 
            onClick={openOpname} 
            className="flex-1 sm:flex-none bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm flex items-center justify-center space-x-2 transition cursor-pointer"
          >
            <i className="fa-solid fa-clipboard-check"></i>
            <span>Stok Opname Fisik</span>
          </button>
          
          <button 
            onClick={() => setShowAddModal(true)} 
            className="flex-1 sm:flex-none bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm flex items-center justify-center space-x-2 transition cursor-pointer"
          >
            <i className="fa-solid fa-plus"></i>
            <span>Tambah Item</span>
          </button>
        </div>
      </div>

      {/* Critical Stock Warning Banner */}
      {lowStockItems.length > 0 && (
        <div className="bg-rose-500/10 border-l-4 border-rose-500 p-4 rounded-r-xl space-y-1.5 text-xs text-rose-700 dark:text-rose-400">
          <h4 className="font-extrabold flex items-center space-x-2">
            <i className="fa-solid fa-triangle-exclamation"></i>
            <span>AMBANG BATAS INVENTARIS MINIMAL</span>
          </h4>
          <ul className="list-disc pl-5 space-y-1 font-medium">
            {lowStockItems.map(item => (
              <li key={item.id}>
                Stok item <strong>{item.name}</strong> kritis! Tersisa {item.stock} unit (Batas minimal: {item.minStock} unit)
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Search and Filters */}
      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-850 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="relative w-full sm:w-72">
            <input 
              type="text" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari nama barang atau kode..." 
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg outline-none text-slate-800 dark:text-slate-200 focus:ring-1 focus:ring-sky-500"
            />
            <i className="fa-solid fa-search absolute left-3 top-3 text-slate-400 text-xs"></i>
          </div>
          
          <select 
            value={katFilter}
            onChange={(e) => setKatFilter(e.target.value)}
            className="w-full sm:w-48 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-800 dark:text-slate-200"
          >
            <option value="Semua">Semua Kategori</option>
            <option value="ATK">Alat Tulis Kantor (ATK)</option>
            <option value="Fotocopy">Jasa Fotocopy</option>
            <option value="Jilid">Jasa Jilid</option>
            <option value="Lainnya">Lainnya</option>
          </select>
        </div>

        {/* Master Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-850 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4 text-center">Kode</th>
                <th className="p-4">Nama Item</th>
                <th className="p-4">Kategori</th>
                <th className="p-4 text-right">Harga Beli (HPP)</th>
                <th className="p-4 text-right">Harga Jual</th>
                <th className="p-3 text-center">Stok</th>
                <th className="p-3 text-center font-mono">Min. Stok</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850">
              {[...items]
                .filter(item => {
                  const matchSearch = item.name.toLowerCase().includes(search.toLowerCase()) || item.id.toLowerCase().includes(search.toLowerCase());
                  const matchKat = katFilter === "Semua" || item.category === katFilter;
                  return matchSearch && matchKat;
                })
                .sort((a, b) => a.name.localeCompare(b.name, 'id'))
                .map((item, index) => {
                  const isLow = item.stock <= item.minStock;
                  const isService = item.category === "Fotocopy" || item.category === "Jilid";
                  
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-900/40 transition">
                      <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                      <td className="p-4 font-mono font-bold text-slate-500 text-center">{item.id}</td>
                      <td className="p-4 font-bold text-slate-900 dark:text-white">{item.name}</td>
                      <td className="p-4">
                        <span className="bg-slate-150 dark:bg-slate-800 text-slate-800 dark:text-slate-300 font-semibold px-2 py-0.5 rounded text-[10px]">
                          {item.category}
                        </span>
                      </td>
                      <td className="p-4 text-right text-slate-500 font-mono">{formatIDR(item.buyPrice)}</td>
                      <td className="p-4 text-right font-extrabold text-sky-500 font-mono">{formatIDR(item.sellPrice)}</td>
                      <td className="p-3 text-center font-bold text-slate-800 dark:text-slate-200">
                        {isService ? "∞" : item.stock}
                      </td>
                      <td className="p-3 text-center text-slate-400 font-mono">
                        {isService ? "-" : item.minStock}
                      </td>
                      <td className="p-3 text-center">
                        {isService ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-500 border border-indigo-500/15">Jasa/Cetak</span>
                        ) : isLow ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500 border border-rose-500/15">Stok Kritis</span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 border border-emerald-500/15">Aman</span>
                        )}
                      </td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button 
                            onClick={() => handleEditPrice(item)} 
                            className="text-sky-500 hover:text-sky-700 transition cursor-pointer p-1" 
                            title="Koreksi Jual"
                          >
                            <i className="fa-solid fa-pen-to-square text-sm"></i>
                          </button>
                          
                          {currentUser?.role === 'Admin' && (
                            <button 
                              onClick={() => handleDeleteItem(item.id, item.name)} 
                              className="text-rose-500 hover:text-rose-700 transition cursor-pointer p-1" 
                              title="Hapus Master"
                            >
                              <i className="fa-solid fa-trash-can text-sm"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              {items.length === 0 && (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 italic">Belum ada item dalam data master</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Tambah Master Item Baru */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
          >
            <div className="p-5 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className="fa-solid fa-plus-circle text-sky-500 text-base"></i>
                <span>Daftarkan Master Item/Jasa Baru</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-base"></i>
              </button>
            </div>

            <form onSubmit={handleAddNewItem} className="p-6 space-y-4 text-xs font-semibold">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Kode Item</label>
                  <input 
                    type="text" 
                    value={newItemCode}
                    onChange={(e) => setNewItemCode(e.target.value)}
                    placeholder="Contoh: ATK-04, FT-03" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white uppercase"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Kategori</label>
                  <select 
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  >
                    <option value="ATK">Alat Tulis Kantor (ATK)</option>
                    <option value="Fotocopy">Jasa Fotocopy</option>
                    <option value="Jilid">Jasa Jilid</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Nama Item / Nama Jasa</label>
                <input 
                  type="text" 
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="Contoh: Kertas Golden Star F4 70gr" 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Harga Beli (HPP)</label>
                  <input 
                    type="number" 
                    value={newItemBuyPrice}
                    onChange={(e) => setNewItemBuyPrice(e.target.value)}
                    placeholder="Rp" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Harga Jual</label>
                  <input 
                    type="number" 
                    value={newItemSellPrice}
                    onChange={(e) => setNewItemSellPrice(e.target.value)}
                    placeholder="Rp" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Stok Awal</label>
                  <input 
                    type="number"
                    value={newItemStock}
                    onChange={(e) => setNewItemStock(e.target.value)}
                    placeholder="Isi 0 untuk Jasa" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Batas Minimal Stok (Alerts)</label>
                  <input 
                    type="number" 
                    value={newItemMinStock}
                    onChange={(e) => setNewItemMinStock(e.target.value)}
                    placeholder="Min. stock alert" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="p-5 border-t border-slate-200 dark:border-slate-850 flex justify-end space-x-2 pt-4 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="bg-sky-500 hover:bg-sky-600 text-white font-bold px-4 py-2 rounded-lg transition shadow-md"
                >
                  Simpan Item
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {/* Modal: Stok Opname Fisik */}
      {showOpnameModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-lg shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
          >
            <div className="p-5 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className="fa-solid fa-clipboard-check text-sky-500 text-base"></i>
                <span>Stok Opname Fisik Barang</span>
              </h3>
              <button onClick={() => setShowOpnameModal(false)} className="text-slate-400 hover:text-slate-600 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-base"></i>
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Pilih Item Fisik Inventaris</label>
                <select 
                  value={opnameItemId}
                  onChange={(e) => handleOpnameItemChange(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                >
                  {items
                    .filter(i => i.category !== "Fotocopy" && i.category !== "Jilid")
                    .map(i => (
                      <option key={i.id} value={i.id}>{i.id} - {i.name}</option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Stok Sistem (Sekarang)</label>
                  <input 
                    type="text" 
                    value={sysStock} 
                    disabled 
                    className="w-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none font-bold text-center text-slate-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Stok Nyata (Fisik Toko)</label>
                  <input 
                    type="number"
                    value={opnameActualStok}
                    onChange={(e) => setOpnameActualStok(e.target.value)}
                    placeholder="Masukkan stok di rak..." 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-250 dark:border-slate-750 p-2.5 rounded-lg outline-none text-center font-bold text-slate-900 dark:text-white focus:ring-1 focus:ring-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Selisih Stok</label>
                <input 
                  type="text" 
                  value={diff === 0 ? "Sesuai (0)" : diff > 0 ? `Lebih (+${diff})` : `Selisih Hilang (${diff})`} 
                  disabled 
                  className={`w-full p-2.5 rounded-lg text-center font-extrabold border outline-none ${
                    diff === 0 
                      ? "bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/30" 
                      : diff < 0 
                      ? "bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-900/30" 
                      : "bg-sky-50 dark:bg-sky-950/20 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-900/30"
                  }`}
                />
              </div>

              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Alasan Perubahan / Catatan Audit</label>
                <textarea 
                  value={opnameReason}
                  onChange={(e) => setOpnameReason(e.target.value)}
                  rows={2} 
                  placeholder="Contoh: 2 Buku ternyata robek/rusak di kardus..." 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none resize-none text-slate-900 dark:text-white"
                />
              </div>

              <div className="p-5 border-t border-slate-200 dark:border-slate-850 flex justify-end space-x-2 pt-4 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowOpnameModal(false)}
                  className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition"
                >
                  Batal
                </button>
                <button 
                  type="button" 
                  onClick={handleSaveStokOpname}
                  className="bg-sky-500 hover:bg-sky-600 text-white font-bold px-4 py-2 rounded-lg transition shadow-md"
                >
                  Simpan Hasil Opname
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
