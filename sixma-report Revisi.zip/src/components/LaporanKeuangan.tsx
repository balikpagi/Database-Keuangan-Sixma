/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sale, Expense, Settings, Item } from '../types';
import { formatIDR } from '../utils';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

interface LaporanKeuanganProps {
  sales: Sale[];
  expenses: Expense[];
  settings: Settings;
  items: Item[];
}

export function LaporanKeuangan({ sales, expenses, settings, items }: LaporanKeuanganProps) {
  const [reportType, setReportType] = useState<"bulanan" | "triwulan" | "tahunan">("bulanan");
  const [reportMonth, setReportMonth] = useState("06");
  const [reportTriwulan, setReportTriwulan] = useState("T2");

  const [showReport, setShowReport] = useState(false);
  const [reportTitle, setReportTitle] = useState("");
  const [filteredSales, setFilteredSales] = useState<Sale[]>([]);
  const [filteredExpenses, setFilteredExpenses] = useState<Expense[]>([]);

  const months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

  const triggerGenerateReport = () => {
    let title = "";
    let sFiltered: Sale[] = [];
    let eFiltered: Expense[] = [];

    if (reportType === 'bulanan') {
      title = `Laporan Keuangan Bulanan: Periode ${months[parseInt(reportMonth) - 1]} 2026`;
      sFiltered = sales.filter(s => {
        const parts = s.tanggal.split(' ')[0].split('-');
        return parts[1] === reportMonth && parts[0] === '2026';
      });

      eFiltered = expenses.filter(e => {
        const parts = e.tanggal.split('-');
        return parts[1] === reportMonth && parts[0] === '2026';
      });
    } else if (reportType === 'triwulan') {
      let group: string[] = [];
      if (reportTriwulan === 'T1') {
        group = ['01', '02', '03'];
        title = "Laporan Keuangan Triwulan I: Periode Januari - Maret 2026";
      } else if (reportTriwulan === 'T2') {
        group = ['04', '05', '06'];
        title = "Laporan Keuangan Triwulan II: Periode April - Juni 2026";
      } else if (reportTriwulan === 'T3') {
        group = ['07', '08', '09'];
        title = "Laporan Keuangan Triwulan III: Periode Juli - September 2026";
      } else if (reportTriwulan === 'T4') {
        group = ['10', '11', '12'];
        title = "Laporan Keuangan Triwulan IV: Periode Oktober - Desember 2026";
      }

      sFiltered = sales.filter(s => {
        const parts = s.tanggal.split(' ')[0].split('-');
        return group.includes(parts[1]) && parts[0] === '2026';
      });

      eFiltered = expenses.filter(e => {
        const parts = e.tanggal.split('-');
        return group.includes(parts[1]) && parts[0] === '2026';
      });
    } else {
      title = "Laporan Keuangan Tahunan: Evaluasi Total Tahun Buku 2026";
      sFiltered = sales.filter(s => s.tanggal.startsWith("2026"));
      eFiltered = expenses.filter(e => e.tanggal.startsWith("2026"));
    }

    setReportTitle(title);
    setFilteredSales(sFiltered);
    setFilteredExpenses(eFiltered);
    setShowReport(true);
  };

  const printReport = () => {
    window.print();
  };

  // Calculations for generated lists
  const totalOmset = filteredSales.reduce((acc, curr) => acc + curr.subtotal, 0);
  const totalPpn = filteredSales.reduce((acc, curr) => acc + curr.tax, 0);
  const totalExpense = filteredExpenses.reduce((acc, curr) => acc + curr.jumlah, 0);
  const netLabaResult = (totalOmset + totalPpn) - totalExpense;

  // Revenue Category distributions
  const catIncome: Record<string, number> = { Fotocopy: 0, Jilid: 0, ATK: 0, Lainnya: 0 };
  const catVol: Record<string, number> = { Fotocopy: 0, Jilid: 0, ATK: 0, Lainnya: 0 };

  filteredSales.forEach(sale => {
    sale.itemDetail.forEach(item => {
      let cat = "Lainnya";
      if (item.id.startsWith("FT")) cat = "Fotocopy";
      else if (item.id.startsWith("JL")) cat = "Jilid";
      else if (item.id.startsWith("ATK")) cat = "ATK";

      const val = item.qty * item.price;
      if (catIncome[cat] !== undefined) {
        catIncome[cat] += val;
        catVol[cat] += item.qty;
      } else {
        catIncome["Lainnya"] += val;
        catVol["Lainnya"] += item.qty;
      }
    });
  });

  // Expense categories
  const expGroup: Record<string, number> = { "Belanja ATK": 0, "Operasional": 0, "Bahan Baku": 0, "Gaji Karyawan": 0, "Lain-lain": 0 };
  const expCount: Record<string, number> = { "Belanja ATK": 0, "Operasional": 0, "Bahan Baku": 0, "Gaji Karyawan": 0, "Lain-lain": 0 };

  filteredExpenses.forEach(exp => {
    const cat = exp.kategori;
    if (expGroup[cat] !== undefined) {
      expGroup[cat] += exp.jumlah;
      expCount[cat]++;
    } else {
      expGroup["Lain-lain"] += exp.jumlah;
      expCount["Lain-lain"]++;
    }
  });

  const now = new Date();
  const dateFormatted = `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;

  // Calculate monthly comparison data for 2026 (all 12 months)
  const monthlyData = months.map((monthName, index) => {
    const monthStr = String(index + 1).padStart(2, '0');
    
    // Filter sales for this month of 2026
    const mSales = sales.filter(s => {
      const parts = s.tanggal.split(' ')[0].split('-');
      return parts[1] === monthStr && parts[0] === '2026';
    });
    
    // Filter expenses for this month of 2026
    const mExpenses = expenses.filter(e => {
      const parts = e.tanggal.split('-');
      return parts[1] === monthStr && parts[0] === '2026';
    });
    
    const mOmset = mSales.reduce((acc, curr) => acc + curr.subtotal, 0);
    const mPpn = mSales.reduce((acc, curr) => acc + curr.tax, 0);
    const mTotalRevenue = mOmset + mPpn;
    const mExpense = mExpenses.reduce((acc, curr) => acc + curr.jumlah, 0);
    const mLaba = mTotalRevenue - mExpense; // Net Profit
    
    return {
      name: monthName.substring(0, 3), // e.g., "Jan", "Feb"
      fullName: monthName,
      'Laba Bersih': mLaba,
      'Pengeluaran': mExpense,
      'Pendapatan': mTotalRevenue,
    };
  });

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-3 rounded-xl shadow-lg leading-none font-sans text-xs">
          <p className="font-bold text-slate-900 dark:text-slate-100 mb-2">{data.fullName} 2026</p>
          <div className="space-y-1.5 leading-normal">
            <div className="flex items-center justify-between space-x-6">
              <span className="flex items-center gap-1 text-slate-505 dark:text-slate-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                Laba Bersih:
              </span>
              <span className={`font-bold ${data['Laba Bersih'] >= 0 ? 'text-emerald-600 dark:text-emerald-450' : 'text-rose-600 dark:text-rose-450'}`}>
                {formatIDR(data['Laba Bersih'])}
              </span>
            </div>
            <div className="flex items-center justify-between space-x-6">
              <span className="flex items-center gap-1 text-slate-505 dark:text-slate-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
                Pengeluaran:
              </span>
              <span className="font-bold text-rose-600 dark:text-rose-450">
                {formatIDR(data['Pengeluaran'])}
              </span>
            </div>
            <div className="flex items-center justify-between space-x-6 pt-1.5 border-t border-slate-100 dark:border-slate-800">
              <span className="flex items-center gap-1 text-slate-505 dark:text-slate-400 font-medium">
                <span className="w-2 h-2 rounded-full bg-sky-500 inline-block"></span>
                Pendapatan:
              </span>
              <span className="font-bold text-sky-600 dark:text-sky-450">
                {formatIDR(data['Pendapatan'])}
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6 no-print">
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Laporan Laba Rugi & Neraca Keuangan</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Sistem rekapitulasi data keuangan terpadu, laba kotor, PPN, pengeluaran, dan laba bersih.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          <select 
            value={reportType} 
            onChange={(e) => setReportType(e.target.value as any)}
            className="flex-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold rounded-lg px-4 py-2 outline-none text-slate-800 dark:text-slate-200 cursor-pointer"
          >
            <option value="bulanan">Laporan Bulanan</option>
            <option value="triwulan">Laporan Triwulan</option>
            <option value="tahunan">Laporan Tahunan</option>
          </select>

          {reportType === 'bulanan' && (
            <select 
              value={reportMonth}
              onChange={(e) => setReportMonth(e.target.value)}
              className="flex-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold rounded-lg px-4 py-2 outline-none text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <option value="01">Januari</option>
              <option value="02">Februari</option>
              <option value="03">Maret</option>
              <option value="04">April</option>
              <option value="05">Mei</option>
              <option value="06">Juni</option>
              <option value="07">Juli</option>
              <option value="08">Agustus</option>
              <option value="09">September</option>
              <option value="10">Oktober</option>
              <option value="11">November</option>
              <option value="12">Desember</option>
            </select>
          )}

          {reportType === 'triwulan' && (
            <select 
              value={reportTriwulan}
              onChange={(e) => setReportTriwulan(e.target.value)}
              className="flex-1 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-bold rounded-lg px-4 py-2 outline-none text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <option value="T1">Triwulan I (Jan - Mar)</option>
              <option value="T2">Triwulan II (Apr - Jun)</option>
              <option value="T3">Triwulan III (Jul - Sep)</option>
              <option value="T4">Triwulan IV (Okt - Des)</option>
            </select>
          )}

          <button 
            onClick={triggerGenerateReport}
            className="flex-1 lg:flex-none bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs px-5 py-2.5 rounded-lg transition flex items-center justify-center space-x-1.5 shadow cursor-pointer text-center"
          >
            <i className="fa-solid fa-arrows-rotate"></i>
            <span>Tampilkan</span>
          </button>
        </div>
      </div>

      {/* Visual Analytics Chart Card */}
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm no-print">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <i className="fa-solid fa-chart-column text-sky-500"></i>
              Grafik Kinerja Keuangan Bulanan (Tahun Buku 2026)
            </h3>
            <p className="text-slate-400 text-[10px] uppercase font-semibold mt-0.5">Analisis visual perbandingan laba bersih dan pengeluaran operasional secara terintegrasi</p>
          </div>
          <div className="flex items-center gap-4 text-xs font-bold shrink-0">
            <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              Laba Bersih
            </span>
            <span className="flex items-center gap-1.5 text-rose-600 dark:text-rose-455">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span>
              Pengeluaran
            </span>
          </div>
        </div>
        
        <div className="h-64 w-full select-none">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148, 163, 184, 0.15)" vertical={false} />
              <XAxis 
                dataKey="name" 
                stroke="rgba(148, 163, 184, 0.6)" 
                fontSize={10} 
                fontWeight="bold"
                tickLine={false} 
                axisLine={false} 
                dy={8}
              />
              <YAxis 
                stroke="rgba(148, 163, 184, 0.6)" 
                fontSize={9} 
                fontWeight="semibold"
                tickLine={false} 
                axisLine={false} 
                dx={-8}
                tickFormatter={(value) => {
                  if (value >= 1000000) return `${(value / 1000000).toFixed(1).replace('.', ',')} Jt`;
                  if (value >= 1000) return `${(value / 1000).toFixed(0)} Rb`;
                  if (value <= -1000000) return `${(value / 1000000).toFixed(1).replace('.', ',')} Jt`;
                  return String(value);
                }}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }} />
              <Bar dataKey="Laba Bersih" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={28} />
              <Bar dataKey="Pengeluaran" fill="#f43f5e" radius={[4, 4, 0, 0]} maxBarSize={28} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {!showReport ? (
        <div className="text-center py-20 bg-white dark:bg-slate-940 border border-slate-250 dark:border-slate-850 shadow-sm rounded-2xl text-slate-400">
          <i className="fa-solid fa-file-invoice text-5xl mb-4 text-slate-300 dark:text-slate-700"></i>
          <h4 className="font-bold text-slate-700 dark:text-slate-200">Siap Membuat Laporan Laba Rugi</h4>
          <p className="text-xs mt-1">Tentukan jenis periode laporan di bagian kanan atas kemudian klik tombol Tampilkan.</p>
        </div>
      ) : (
        /* Printable Report Area fully integrated in React rendering */
        <div className="bg-white text-slate-800 p-8 rounded-2xl border border-slate-200 shadow-sm relative transition duration-300">
          
          <button 
            onClick={printReport}
            className="absolute top-6 right-6 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-1.5 rounded flex items-center space-x-1.5 transition no-print cursor-pointer"
          >
            <i className="fa-solid fa-print"></i>
            <span>Cetak Laporan</span>
          </button>

          {/* Letterhead */}
          <div className="mb-6 border-b-2 border-slate-300 pb-6 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {settings.logo ? (
                <img src={settings.logo} className="w-16 h-16 object-contain" alt="Logo" />
              ) : (
                <div className="w-16 h-16 bg-sky-500 text-white font-extrabold rounded-2xl flex items-center justify-center text-xl">SR</div>
              )}
              <div>
                <h1 className="text-xl font-bold uppercase tracking-wider text-slate-900">{settings.companyName || "SIXMA REPORT"}</h1>
                <p className="text-xs text-slate-500">{settings.companyAddress}</p>
                {settings.ownerNpwp && <p className="text-[10px] text-slate-400 font-bold">NPWP: {settings.ownerNpwp}</p>}
              </div>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono text-slate-400">KODE DOKUMEN: FIN-REP/2026</span>
            </div>
          </div>

          <div className="text-center mb-8">
            <h2 className="text-base font-extrabold uppercase tracking-wide border-b pb-2 text-slate-900">
              {reportTitle}
            </h2>
          </div>

          <div className="space-y-6 text-xs text-slate-800 font-medium">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">TOTAL OMSET / PENDAPATAN</span>
                <span className="text-base font-extrabold text-slate-800 mt-1 block font-mono">{formatIDR(totalOmset)}</span>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">PENGELUARAN OPERASIONAL</span>
                <span className="text-base font-extrabold text-slate-800 mt-1 block font-mono">{formatIDR(totalExpense)}</span>
              </div>
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">ESTIMASI LABA BERSIH (+PPN)</span>
                <span className="text-base font-extrabold text-emerald-600 mt-1 block font-mono">{formatIDR(netLabaResult)}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
              <div>
                <h3 className="font-bold text-slate-400 uppercase tracking-wider mb-2 border-b pb-1 text-[10px]">REKAPITULASI OMSET KEGIATAN</h3>
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="text-[10px] font-bold text-slate-400 border-b bg-slate-50">
                      <th className="p-2 text-center w-10">No.</th>
                      <th className="p-2">Kategori</th>
                      <th className="p-2 text-center">Volume Satuan</th>
                      <th className="p-2 text-right">Omset Bruto</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[...Object.entries(catIncome)]
                      .sort((a, b) => a[0].localeCompare(b[0], 'id'))
                      .map(([cat, val], index) => (
                        <tr key={cat} className="hover:bg-slate-50">
                          <td className="p-2 text-center text-slate-500 font-bold">{index + 1}</td>
                          <td className="p-2 font-bold text-slate-700 capitalize">{cat}</td>
                          <td className="p-2 text-center text-slate-500 font-mono">{catVol[cat]} {cat === 'Fotocopy' ? 'Lembar' : cat === 'Jilid' ? 'Buku' : 'Unit'}</td>
                          <td className="p-2 text-right font-black text-sky-500 font-mono">{formatIDR(val)}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>

              <div>
                <h3 className="font-bold text-slate-400 uppercase tracking-wider mb-2 border-b pb-1 text-[10px]">REKAPITULASI BIAYA & PENGELUARAN</h3>
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="text-[10px] font-bold text-slate-400 border-b bg-slate-50">
                      <th className="p-2 text-center w-10">No.</th>
                      <th className="p-2">Kategori Biaya</th>
                      <th className="p-2 text-center">Frekuensi</th>
                      <th className="p-2 text-right">Keluaran Biaya</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[...Object.entries(expGroup)]
                      .sort((a, b) => a[0].localeCompare(b[0], 'id'))
                      .map(([cat, val], index) => (
                        <tr key={cat} className="hover:bg-slate-50">
                          <td className="p-2 text-center text-slate-500 font-bold">{index + 1}</td>
                          <td className="p-2 font-bold text-slate-700">{cat}</td>
                          <td className="p-2 text-center text-slate-500 font-mono">{expCount[cat]} Transaksi</td>
                          <td className="p-2 text-right font-black text-rose-500 font-mono">{formatIDR(val)}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Official Stamps / Signature Rows */}
            <div className="flex justify-between items-end pt-12 text-xs text-slate-700 leading-normal">
              <div className="space-y-4">
                <p className="text-slate-400">Mengetahui & Menyetujui,</p>
                <div className="relative w-40 h-24">
                  {settings.stamp && (
                    <img src={settings.stamp} className="stamp-image-layer pointer-events-none" alt="Stempel" style={{ left: 0 }} />
                  )}
                </div>
                <p className="font-extrabold text-slate-900 border-b border-slate-300 pb-1 inline-block w-48 text-center">{settings.ownerName || "PIMPINAN OWNER"}</p>
              </div>
              
              <div className="text-center w-52 space-y-4">
                <p className="text-slate-400 font-medium">Jakarta, {dateFormatted}</p>
                <div className="w-full h-16 flex items-center justify-center">
                  {settings.signature && (
                    <img src={settings.signature} className="max-h-16 object-contain pointer-events-none" alt="Tanda Tangan" />
                  )}
                </div>
                <p className="font-extrabold text-slate-900 border-b border-slate-300 pb-1 inline-block w-48">{settings.ownerName || "Administrator Sixma"}</p>
                <p className="text-[10px] text-slate-400 mt-0.5">Penanggung Jawab Keuangan</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
