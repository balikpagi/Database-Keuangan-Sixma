/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sale, User } from '../types';
import { formatIDR } from '../utils';

interface RiwayatPenjualanProps {
  sales: Sale[];
  currentUser: User | null;
  onSalesChange: (sales: Sale[]) => void;
  onViewInvoice: (sale: Sale, pageType: 'faktur' | 'kwitansi') => void;
  onEditSale: (saleIndex: number) => void;
  addLog: (action: string, detail: string) => void;
}

export function RiwayatPenjualan({ sales, currentUser, onSalesChange, onViewInvoice, onEditSale, addLog }: RiwayatPenjualanProps) {
  const [search, setSearch] = useState("");
  const [filterDate, setFilterDate] = useState("");
  const [filterMonth, setFilterMonth] = useState("Semua");
  const [filterYear, setFilterYear] = useState("Semua");
  const [filterStatus, setFilterStatus] = useState("Semua");

  const resetFilters = () => {
    setSearch("");
    setFilterDate("");
    setFilterMonth("Semua");
    setFilterYear("Semua");
    setFilterStatus("Semua");
  };

  // Toggle invoice status lunas vs unpaid
  const handleToggleStatus = (index: number) => {
    const sale = sales[index];
    if (sale) {
      const updatedStatus = sale.status === "Lunas (Paid)" ? "Belum Lunas (Unpaid)" : "Lunas (Paid)";
      const updated = sales.map((s, idx) => {
        if (idx === index) {
          return { ...s, status: updatedStatus };
        }
        return s;
      });
      onSalesChange(updated);
      addLog("Ubah Status", `Mengubah status transaksi ${sale.invoiceNo} menjadi ${updatedStatus}`);
      alert(`Status pembayaran penjualan ${sale.invoiceNo} telah diubah menjadi ${updatedStatus}`);
    }
  };

  // Completely delete a transaction
  const handleDeleteSale = (index: number) => {
    const sale = sales[index];
    if (sale) {
      if (confirm(`Apakah Anda benar-benar ingin menghapus transaksi kepala ${sale.invoiceNo} untuk ${sale.pelanggan}? Tindakan ini akan mengembalikan stok!`)) {
        onSalesChange(sales.filter((_, idx) => idx !== index));
        addLog("Hapus Penjualan", `Menghapus pencatatan transaksi No: ${sale.invoiceNo}`);
        alert("Pencatatan transaksi berhasil dihapus dari sistem.");
      }
    }
  };

  // 1. FILTERED TRANSACTION DATA
  const filteredSalesData = [...sales]
    .map((sale, originalIndex) => ({ sale, originalIndex }))
    .filter(({ sale }) => {
      const parts = sale.tanggal.split(' ')[0].split('-');
      const matchQuery = sale.invoiceNo.toLowerCase().includes(search.toLowerCase()) || 
                       sale.pelanggan.toLowerCase().includes(search.toLowerCase()) ||
                       sale.itemDetail.some(i => i.name.toLowerCase().includes(search.toLowerCase()));
                       
      const matchDate = !filterDate || sale.tanggal.startsWith(filterDate);
      const matchMonth = filterMonth === "Semua" || parts[1] === filterMonth;
      const matchYear = filterYear === "Semua" || parts[0] === filterYear;
      const matchStatus = filterStatus === "Semua" || sale.status === filterStatus;

      return matchQuery && matchDate && matchMonth && matchYear && matchStatus;
    })
    .sort((a, b) => a.sale.pelanggan.localeCompare(b.sale.pelanggan, 'id'));

  // 2. ACCUMULATE STATISTICS
  const totalTransactions = filteredSalesData.length;
  const totalSubtotal = filteredSalesData.reduce((acc, { sale }) => acc + sale.subtotal, 0);
  const totalTax = filteredSalesData.reduce((acc, { sale }) => acc + sale.tax, 0);
  const totalRevenue = filteredSalesData.reduce((acc, { sale }) => acc + sale.total, 0);

  // Sum of items with unit "Lembar" (including empty/falsy unit which falls back to "Lembar")
  const totalLembar = filteredSalesData.reduce((acc, { sale }) => {
    const sheetsInSale = sale.itemDetail.reduce((sum, item) => {
      const unitClean = (item.unit || "Lembar").toLowerCase().trim();
      if (unitClean === "lembar" || unitClean === "") {
        return sum + item.qty;
      }
      return sum;
    }, 0);
    return acc + sheetsInSale;
  }, 0);

  // Sum of all other items unit (e.g. Psc, Buku, Rim, dsb)
  const totalOtherUnitsQty = filteredSalesData.reduce((acc, { sale }) => {
    const otherInSale = sale.itemDetail.reduce((sum, item) => {
      const unitClean = (item.unit || "Lembar").toLowerCase().trim();
      if (unitClean !== "lembar" && unitClean !== "") {
        return sum + item.qty;
      }
      return sum;
    }, 0);
    return acc + otherInSale;
  }, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Riwayat Transaksi Penjualan</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Daftar rekapitulasi kepala faktur transaksi, filter periode, status, cetak, dan tindakan audit.</p>
        </div>
      </div>

      {/* Advanced Filter Layout Card */}
      <div className="bg-white dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-wrap gap-3 items-center">
        <div className="relative w-full sm:w-72">
          <input 
            type="text" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari No. Invoice, Pelanggan, atau Item..." 
            className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg outline-none text-slate-800 dark:text-slate-200 focus:ring-1 focus:ring-sky-500"
          />
          <i className="fa-solid fa-search absolute left-3 top-3 text-slate-400 text-xs"></i>
        </div>

        <input 
          type="date" 
          value={filterDate}
          onChange={(e) => setFilterDate(e.target.value)}
          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-855 dark:text-slate-200 cursor-pointer"
        />
        
        <select 
          value={filterMonth}
          onChange={(e) => setFilterMonth(e.target.value)}
          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-855 dark:text-slate-200 cursor-pointer"
        >
          <option value="Semua">Semua Bulan</option>
          <option value="01">Januari</option>
          <option value="02">Februari</option>
          <option value="03">Maret</option>
          <option value="04">April</option>
          <option value="05">Mei</option>
          <option value="06">Juni</option>
          <option value="07">Juli</option>
          <option value="08">Agustus</option>
          <option value="09">September</option>
          <option value="10">Oktober</option>
          <option value="11">November</option>
          <option value="12">Desember</option>
        </select>

        <select 
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-855 dark:text-slate-200 cursor-pointer"
        >
          <option value="Semua">Semua Tahun</option>
          <option value="2026">2026</option>
          <option value="2025">2025</option>
        </select>

        <select 
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
          className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-855 dark:text-slate-200 cursor-pointer"
        >
          <option value="Semua">Semua Status</option>
          <option value="Lunas (Paid)">Lunas (Paid)</option>
          <option value="Belum Lunas (Unpaid)">Belum Lunas (Unpaid)</option>
        </select>

        <button 
          onClick={resetFilters}
          className="text-xs font-bold text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 transition cursor-pointer ml-auto"
        >
          Reset Filter
        </button>
      </div>

      {/* Accumulated Total Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Lembar Terakumulasi - Highlights as the requested feature */}
        <div className="bg-sky-50 dark:bg-sky-950/25 border border-sky-100 dark:border-sky-900/40 p-4 rounded-2xl shadow-sm flex items-center space-x-3.5">
          <div className="p-3 bg-sky-500/10 text-sky-500 dark:text-sky-400 rounded-xl">
            <i className="fa-solid fa-file-invoice text-lg"></i>
          </div>
          <div>
            <p className="text-[10px] text-sky-600/80 dark:text-sky-400/80 font-bold uppercase tracking-wider">Total Lembar Terakumulasi</p>
            <p className="text-xl font-black text-slate-900 dark:text-white leading-tight mt-0.5">
              {totalLembar.toLocaleString("id-ID")}{" "}
              <span className="text-[10px] font-bold text-slate-400 uppercase">Lembar</span>
            </p>
          </div>
        </div>

        {/* Total Item Lainnya */}
        <div className="bg-white dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center space-x-3.5">
          <div className="p-3 bg-indigo-500/10 text-indigo-500 rounded-xl">
            <i className="fa-solid fa-boxes-stacked text-lg"></i>
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Item Lainnya</p>
            <p className="text-xl font-black text-slate-900 dark:text-white leading-tight mt-0.5">
              {totalOtherUnitsQty.toLocaleString("id-ID")}{" "}
              <span className="text-[10px] font-bold text-slate-400 uppercase">Item</span>
            </p>
          </div>
        </div>

        {/* Total Nominal Rupiah */}
        <div className="bg-white dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center space-x-3.5">
          <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-xl">
            <i className="fa-solid fa-coins text-lg"></i>
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Akumulasi Kassa</p>
            <p className="text-xl font-black text-slate-900 dark:text-white leading-tight mt-0.5">
              {formatIDR(totalRevenue)}
            </p>
          </div>
        </div>

        {/* Total Transaksi */}
        <div className="bg-white dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex items-center space-x-3.5">
          <div className="p-3 bg-amber-500/10 text-amber-500 rounded-xl">
            <i className="fa-solid fa-receipt text-lg"></i>
          </div>
          <div>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Nota Invoice Terbit</p>
            <p className="text-xl font-black text-slate-900 dark:text-white leading-tight mt-0.5">
              {totalTransactions}{" "}
              <span className="text-[10px] font-bold text-slate-400 uppercase">Faktur</span>
            </p>
          </div>
        </div>
      </div>

      {/* Invoices List Panel */}
      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-855 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4">No. Invoice</th>
                <th className="p-4">Tanggal</th>
                <th className="p-4">Pelanggan</th>
                <th className="p-4 text-center w-28">Volume (Lbr)</th>
                <th className="p-4">Metode Bayar</th>
                <th className="p-4 text-right">Subtotal</th>
                <th className="p-4 text-right">PPN</th>
                <th className="p-4 text-right">Total Akhir</th>
                <th className="p-4 text-center">Status</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-300">
              {filteredSalesData.map(({ sale, originalIndex }, index) => {
                const isPaid = sale.status === "Lunas (Paid)";
                const badgeStyle = isPaid 
                  ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/15" 
                  : "bg-rose-500/10 text-rose-500 border border-rose-500/15";

                const txLembarSum = sale.itemDetail.reduce((sum, item) => {
                  const unitClean = (item.unit || "Lembar").toLowerCase().trim();
                  if (unitClean === "lembar" || unitClean === "") {
                    return sum + item.qty;
                  }
                  return sum;
                }, 0);

                const txOtherSum = sale.itemDetail.reduce((sum, item) => {
                  const unitClean = (item.unit || "Lembar").toLowerCase().trim();
                  if (unitClean !== "lembar" && unitClean !== "") {
                    return sum + item.qty;
                  }
                  return sum;
                }, 0);

                return (
                  <tr key={sale.invoiceNo} className="hover:bg-slate-50/70 dark:hover:bg-slate-900/30 transition text-xs border-b dark:border-slate-850">
                    <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                    <td className="p-4 font-mono font-bold text-slate-500">{sale.invoiceNo}</td>
                    <td className="p-4 font-semibold">{sale.tanggal}</td>
                    <td className="p-4 font-bold text-slate-900 dark:text-white">{sale.pelanggan}</td>
                    <td className="p-4 text-center">
                      <div className="flex flex-col items-center justify-center">
                        {txLembarSum > 0 ? (
                          <span className="font-extrabold text-sky-600 dark:text-sky-400 font-mono text-xs">
                            {txLembarSum.toLocaleString("id-ID")}{" "}
                            <span className="text-[9px] text-slate-400 font-bold uppercase select-none">Lbr</span>
                          </span>
                        ) : (
                          <span className="text-slate-350 dark:text-slate-600 font-mono text-xs">-</span>
                        )}
                        {txOtherSum > 0 && (
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold select-none leading-none mt-0.5" title="Item non-lembar (Buku, Jilid, Rim, Pcs, etc)">
                            +{txOtherSum.toLocaleString("id-ID")} Non-Lbr
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-300 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                        {sale.metodeBayar}
                      </span>
                    </td>
                    <td className="p-4 text-right font-mono">{formatIDR(sale.subtotal)}</td>
                    <td className="p-4 text-right text-slate-400 font-mono">{formatIDR(sale.tax)}</td>
                    <td className="p-4 text-right font-extrabold text-sky-500 font-mono">{formatIDR(sale.total)}</td>
                    <td className="p-4 text-center">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${badgeStyle}`}>
                        {sale.status}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <div className="flex items-center justify-center space-x-2">
                        <button 
                          onClick={() => onViewInvoice(sale, 'faktur')} 
                          className="text-sky-500 hover:text-sky-700 transition cursor-pointer p-1" 
                          title="Nota Faktur Cetak"
                        >
                          <i className="fa-solid fa-file-invoice text-sm"></i>
                        </button>
                        
                        <button 
                          onClick={() => onViewInvoice(sale, 'kwitansi')} 
                          className="text-indigo-500 hover:text-indigo-750 transition cursor-pointer p-1" 
                          title="Kwitansi Resmi"
                        >
                          <i className="fa-solid fa-receipt text-sm"></i>
                        </button>
                        
                        <button 
                          onClick={() => onEditSale(originalIndex)} 
                          className="text-amber-500 hover:text-amber-700 transition cursor-pointer p-1" 
                          title="Koreksi Data"
                        >
                          <i className="fa-solid fa-pen-to-square text-sm"></i>
                        </button>
                        
                        <button 
                          onClick={() => handleToggleStatus(originalIndex)} 
                          className="text-teal-500 hover:text-teal-750 transition cursor-pointer p-1" 
                          title="Status Bayar"
                        >
                          <i className="fa-solid fa-toggle-on text-sm"></i>
                        </button>
                        
                        {currentUser?.role === 'Admin' && (
                          <button 
                            onClick={() => handleDeleteSale(originalIndex)} 
                            className="text-rose-500 hover:text-rose-700 transition cursor-pointer p-1" 
                            title="Hapus Transaksi"
                          >
                            <i className="fa-solid fa-trash-can text-sm"></i>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {sales.length === 0 && (
                <tr>
                  <td colSpan={11} className="p-8 text-center text-slate-400 italic">Belum ada riwayat transaksi tersimpan</td>
                </tr>
              )}
            </tbody>

            {/* Beautiful summary footer row showing filtered totals */}
            {filteredSalesData.length > 0 && (
              <tfoot>
                <tr className="bg-slate-50 dark:bg-slate-900 border-t-2 border-slate-200 dark:border-slate-800 font-bold text-slate-900 dark:text-white">
                  <td colSpan={6} className="p-4 text-left font-extrabold text-[10px] uppercase text-slate-400">
                    <div className="flex flex-col space-y-0.5">
                      <span>Total Data Terfilter ({filteredSalesData.length} Transaksi)</span>
                      <span className="text-[11px] text-sky-500 lowercase font-medium">
                        (jumlah akumulasi volume: {totalLembar.toLocaleString("id-ID")} lembar & {totalOtherUnitsQty.toLocaleString("id-ID")} item lainnya)
                      </span>
                    </div>
                  </td>
                  <td className="p-4 text-right font-mono font-bold text-slate-800 dark:text-slate-205">{formatIDR(totalSubtotal)}</td>
                  <td className="p-4 text-right font-mono font-bold text-slate-400">{formatIDR(totalTax)}</td>
                  <td className="p-4 text-right font-mono font-extrabold text-sky-500 text-sm">{formatIDR(totalRevenue)}</td>
                  <td colSpan={2} className="p-4"></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>
    </div>
  );
}
