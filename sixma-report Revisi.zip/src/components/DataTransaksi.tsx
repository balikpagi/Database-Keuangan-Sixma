/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sale } from '../types';
import { formatIDR } from '../utils';

interface DataTransaksiProps {
  sales: Sale[];
  onViewInvoice: (sale: Sale, pageType: 'faktur' | 'kwitansi') => void;
  onEditSale: (saleIndex: number) => void;
  addLog: (action: string, detail: string) => void;
}

export function DataTransaksi({ sales, onViewInvoice, onEditSale, addLog }: DataTransaksiProps) {
  const [search, setSearch] = useState("");

  const handleExportCSV = () => {
    try {
      const headers = [
        "No. Invoice",
        "Tanggal",
        "Pelanggan",
        "Nama Item / Jasa",
        "Deskripsi / Catatan",
        "Qty",
        "Satuan",
        "Harga Satuan (IDR)",
        "Subtotal Item (IDR)",
        "Metode Pembayaran",
        "Status Pembayaran",
        "Keterangan Belanja"
      ];

      const csvRows = [headers.join(";")];

      sales.forEach((sale) => {
        sale.itemDetail.forEach((item) => {
          const rowSubtotal = item.qty * item.price;
          const row = [
            sale.invoiceNo,
            sale.tanggal,
            sale.pelanggan,
            item.name,
            item.desc || "",
            item.qty,
            item.unit || "Lembar",
            item.price,
            rowSubtotal,
            sale.metodeBayar,
            sale.status,
            sale.keteranganBelanja || ""
          ];

          // Escape double quotes, and wrap in quotes
          const escapedRow = row.map(val => {
            const str = String(val).replace(/"/g, '""');
            return `"${str}"`;
          });

          csvRows.push(escapedRow.join(";"));
        });
      });

      // Byte Order Mark (BOM) and sep=; directive for Excel automatic column alignment
      const csvContent = "\uFEFF" + "sep=;\n" + csvRows.join("\n");
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", url);
      downloadAnchor.setAttribute("download", `Data_Transaksi_Penjualan_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      URL.revokeObjectURL(url);

      addLog("Ekspor CSV", "Berhasil mengekspor rincian data transaksi ke tipe file CSV");
      alert("Seluruh data transaksi rincian penjualan berhasil diekspor ke file CSV!");
    } catch (err) {
      alert("Gagal melakukan ekspor CSV: " + err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Data Transaksi (Rincian Item Penjualan)</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Daftar menyeluruh per baris barang atau jasa yang terjual kepada pelanggan secara otomatis.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
          <button
            onClick={handleExportCSV}
            className="flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-lg transition shadow-sm cursor-pointer whitespace-nowrap"
            title="Ekspor Seluruh Data Penjualan ke format Microsoft Excel CSV"
          >
            <i className="fa-solid fa-file-excel text-sm"></i>
            <span>Export ke CSV</span>
          </button>

          <div className="relative w-full sm:w-64">
            <input 
              type="text" 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari rincian item..." 
              className="w-full pl-9 pr-4 py-2.5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg outline-none text-slate-800 dark:text-slate-200 focus:ring-1 focus:ring-sky-500"
            />
            <i className="fa-solid fa-search absolute left-3 top-3.5 text-slate-400 text-xs"></i>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-850 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4">No. Invoice</th>
                <th className="p-4">Tanggal</th>
                <th className="p-4">Pelanggan</th>
                <th className="p-4">Nama Item / Jasa</th>
                <th className="p-3 text-center">Volume Unit</th>
                <th className="p-4 text-right">Harga</th>
                <th className="p-4 text-right">Subtotal</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-300">
              {(() => {
                const rows: { sale: Sale; item: any; originalSaleIdx: number; originalItemIdx: number }[] = [];
                sales.forEach((sale, saleIdx) => {
                  sale.itemDetail.forEach((item, itemIdx) => {
                    rows.push({ sale, item, originalSaleIdx: saleIdx, originalItemIdx: itemIdx });
                  });
                });

                const filteredAndSortedRows = rows
                  .filter(({ sale, item }) => {
                    return sale.invoiceNo.toLowerCase().includes(search.toLowerCase()) || 
                           sale.pelanggan.toLowerCase().includes(search.toLowerCase()) ||
                           item.name.toLowerCase().includes(search.toLowerCase());
                  })
                  .sort((a, b) => a.sale.pelanggan.localeCompare(b.sale.pelanggan, 'id'));

                if (filteredAndSortedRows.length === 0) {
                  return (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-400 italic">Belum ada item rincian transaksi terekam</td>
                    </tr>
                  );
                }

                return filteredAndSortedRows.map(({ sale, item, originalSaleIdx, originalItemIdx }, index) => {
                  const rowSubtotal = item.qty * item.price;
                  return (
                    <tr key={`${originalSaleIdx}-${originalItemIdx}-${index}`} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition border-b dark:border-slate-850">
                      <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                      <td className="p-4 font-mono font-bold text-slate-500">
                        <div>{sale.invoiceNo}</div>
                        {sale.keteranganBelanja && (
                          <div className="text-[10px] font-sans font-medium text-emerald-600 dark:text-emerald-400 mt-1.5 max-w-[140px] truncate" title={sale.keteranganBelanja}>
                            <i className="fa-solid fa-receipt text-[9px] mr-1"></i>
                            <span>{sale.keteranganBelanja}</span>
                          </div>
                        )}
                      </td>
                      <td className="p-4 font-semibold whitespace-nowrap">{sale.tanggal}</td>
                      <td className="p-4 font-bold text-slate-900 dark:text-white">{sale.pelanggan}</td>
                      <td className="p-4 font-medium">
                        <div>
                          <span>{item.name}</span>
                          {item.desc && (
                            <span className="block text-[10px] text-indigo-500 italic font-normal mt-0.5">Catatan: {item.desc}</span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 text-center font-bold text-slate-900 dark:text-white">{item.qty} {item.unit || 'Lembar'}</td>
                      <td className="p-4 text-right text-slate-550 dark:text-slate-400 font-mono">{formatIDR(item.price)}</td>
                      <td className="p-4 text-right font-extrabold text-sky-500 font-mono">{formatIDR(rowSubtotal)}</td>
                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button 
                            onClick={() => onViewInvoice(sale, 'kwitansi')}
                            className="text-indigo-500 hover:text-indigo-700 transition cursor-pointer p-1" 
                            title="Tampilkan Kwitansi"
                          >
                            <i className="fa-solid fa-receipt text-sm"></i>
                          </button>
                          <button 
                            onClick={() => onViewInvoice(sale, 'faktur')}
                            className="text-sky-500 hover:text-sky-700 transition cursor-pointer p-1" 
                            title="Tampilkan Faktur"
                          >
                            <i className="fa-solid fa-eye text-sm"></i>
                          </button>
                          <button 
                            onClick={() => onEditSale(originalSaleIdx)} 
                            className="text-amber-500 hover:text-amber-700 transition cursor-pointer p-1" 
                            title="Koreksi Transaksi"
                          >
                            <i className="fa-solid fa-pen-to-square text-sm"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                });
              })()}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
