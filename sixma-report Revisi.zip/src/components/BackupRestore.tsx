/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings } from '../types';

interface BackupRestoreProps {
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
  onFullStateImport: (stateData: any) => void;
  getFullState: () => any;
  addLog: (action: string, detail: string) => void;
}

export function BackupRestore({ settings, onSettingsChange, onFullStateImport, getFullState, addLog }: BackupRestoreProps) {
  const [gasUrl, setGasUrl] = useState(settings.gasUrl || "");
  const [copyStatus, setCopyStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [downloadStatus, setDownloadStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleCopyIndexHtml = async () => {
    setCopyStatus('loading');
    try {
      const response = await fetch('/gas-index.html');
      if (!response.ok) throw new Error("Gagal mengambil file HTML tunggal.");
      const text = await response.text();
      await navigator.clipboard.writeText(text);
      setCopyStatus('success');
      setTimeout(() => setCopyStatus('idle'), 3000);
    } catch (err) {
      console.error(err);
      setCopyStatus('error');
      alert("Gagal menyalin kode. Pastikan aplikasi telah di-build (npm run build).");
      setTimeout(() => setCopyStatus('idle'), 3000);
    }
  };

  const handleDownloadIndexHtml = async () => {
    setDownloadStatus('loading');
    try {
      const response = await fetch('/gas-index.html');
      if (!response.ok) throw new Error("Gagal mengambil file HTML tunggal.");
      const text = await response.text();
      
      const blob = new Blob([text], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'index.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      setDownloadStatus('success');
      setTimeout(() => setDownloadStatus('idle'), 3000);
    } catch (err) {
      console.error(err);
      setDownloadStatus('error');
      alert("Gagal mengunduh berkas. Pastikan aplikasi telah di-build (npm run build).");
      setTimeout(() => setDownloadStatus('idle'), 3000);
    }
  };

  const handleSaveGasUrl = () => {
    onSettingsChange({
      ...settings,
      gasUrl: gasUrl.trim()
    });
    addLog("Koreksi Pengaturan", "Menghubungkan aplikasi ke deployment Google Apps Script");
    alert("URL deployment Google Sheets berhasil dikubungkan!");
  };

  const handleExportDB = () => {
    try {
      const fullState = getFullState();
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullState, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `backup_sixma_report_${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      addLog("Ekspor Database", "Berhasil mencadangkan salinan database lokal JSON");
      alert("Database Sixma Report berhasil diekspor menjadi berkas JSON!");
    } catch (err) {
      alert("Gagal melakukan ekspor data: " + err);
    }
  };

  const handleImportDB = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && parsed.items && parsed.sales && parsed.expenses) {
            onFullStateImport(parsed);
            addLog("Impor Database", "Berhasil melakukan restore salinan database lokal JSON");
            alert("Database lokal Sixma Report berhasil dipulihkan (Restore)!");
          } else {
            alert("Format berkas database JSON yang diunggah tidak valid!");
          }
        } catch (err) {
          alert("Gagal membaca berkas basis data: " + err);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">Backup Database & Integrasi Google Sheets</h2>
        <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Gunakan tab ini untuk mengekspor data simpanan cadangan lokal atau menghubungkan platform ke Google Sheets.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Local storage backups */}
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b dark:border-slate-850 pb-2 flex items-center space-x-2">
            <i className="fa-solid fa-cloud-arrow-down text-emerald-500"></i>
            <span>Backup & Restore File Lokal</span>
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-semibold">Anda dapat menyimpan salinan seluruh database lokal Anda ke dalam bentuk berkas berkode JSON kemudian mengimpornya kembali di lain waktu.</p>
          
          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button 
              onClick={handleExportDB}
              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md transition cursor-pointer"
            >
              <i className="fa-solid fa-download"></i>
              <span>Ekspor File Database (JSON)</span>
            </button>
            
            <div className="flex-1 relative">
              <input 
                type="file" 
                accept=".json"
                onChange={handleImportDB}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
              />
              <button 
                type="button"
                className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md transition cursor-pointer"
              >
                <i className="fa-solid fa-upload"></i>
                <span>Impor File Database (JSON)</span>
              </button>
            </div>
          </div>
        </div>

        {/* Sync Google Sheets */}
        <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm space-y-3">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b dark:border-slate-850 pb-2 flex items-center space-x-2">
            <i className="fa-solid fa-table text-sky-500"></i>
            <span>Status Deployment Google Sheets (GAS)</span>
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-semibold">Apabila Anda ingin data ini disinkronisasikan ke awan secara permanen dan otomatis, silakan hubungkan URL deployment Web App di Google Sheets Anda di bawah ini:</p>
          
          <div className="space-y-4 pt-2">
            <input 
              type="text" 
              value={gasUrl}
              onChange={(e) => setGasUrl(e.target.value)}
              placeholder="Paste URL Web App Apps Script di sini..." 
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2.5 outline-none text-slate-900 dark:text-white"
            />
            <button 
              onClick={handleSaveGasUrl}
              className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-2.5 rounded-xl transition text-xs shadow-md cursor-pointer"
            >
              Simpan & Hubungkan URL Google Sheets
            </button>
          </div>
        </div>
      </div>

      {/* Dapatkan File index.html (Khusus Google Sheets) */}
      <div className="bg-white dark:bg-slate-950 p-6 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm space-y-4">
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider border-b dark:border-slate-850 pb-2 flex items-center space-x-2">
          <i className="fa-solid fa-code text-indigo-500"></i>
          <span>Unduh / Salin File Frontend (index.html)</span>
        </h3>
        <p className="text-xs text-slate-500 leading-relaxed font-semibold">
          Untuk menjalankan seluruh halaman aplikasi Sixma Report secara langsung di Google Sheets/Apps Script, 
          silakan unduh file berkode tunggal di bawah ini atau salin kodenya ke clipboard Anda, lalu paste ke 
          file <code className="bg-slate-50 dark:bg-slate-900 px-1 py-0.5 rounded text-indigo-650 dark:text-indigo-450 font-mono font-bold">index.html</code> di Google Apps Script Anda.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={handleCopyIndexHtml}
            className={`flex-1 font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md transition cursor-pointer ${
              copyStatus === 'success' 
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white' 
                : copyStatus === 'loading'
                ? 'bg-slate-400 text-white cursor-not-allowed'
                : 'bg-indigo-500 hover:bg-indigo-600 text-white'
            }`}
            disabled={copyStatus === 'loading'}
          >
            <i className={`fa-solid ${copyStatus === 'success' ? 'fa-check' : 'fa-copy'}`}></i>
            <span>
              {copyStatus === 'success' ? 'Kode Berhasil Disalin!' : copyStatus === 'loading' ? 'Mengambil Kode...' : 'Salin Kode index.html ke Clipboard'}
            </span>
          </button>

          <button
            onClick={handleDownloadIndexHtml}
            className={`flex-1 font-bold text-xs py-3 px-4 rounded-xl flex items-center justify-center space-x-2 shadow-md transition cursor-pointer ${
              downloadStatus === 'success'
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                : downloadStatus === 'loading'
                ? 'bg-slate-400 text-white cursor-not-allowed'
                : 'bg-slate-700 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-750'
            }`}
            disabled={downloadStatus === 'loading'}
          >
            <i className={`fa-solid ${downloadStatus === 'success' ? 'fa-circle-down' : 'fa-download'}`}></i>
            <span>
              {downloadStatus === 'success' ? 'Unduhan Selesai!' : downloadStatus === 'loading' ? 'Mengunduh...' : 'Unduh Berkas index.html'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
