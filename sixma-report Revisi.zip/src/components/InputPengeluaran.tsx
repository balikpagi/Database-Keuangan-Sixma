/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Expense } from '../types';
import { formatIDR } from '../utils';
import { motion } from 'motion/react';

interface InputPengeluaranProps {
  expenses: Expense[];
  onExpensesChange: (expenses: Expense[]) => void;
  addLog: (action: string, detail: string) => void;
  triggerToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export function InputPengeluaran({ expenses, onExpensesChange, addLog, triggerToast }: InputPengeluaranProps) {
  const [filterCategory, setFilterCategory] = useState("Semua");
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states
  const [expenseNo, setExpenseNo] = useState("");
  const [category, setCategory] = useState("Belanja ATK");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  const handleOpenAddModal = () => {
    const now = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    const dateStrShort = `${pad(now.getDate())}${pad(now.getMonth() + 1)}${now.getFullYear().toString().substring(2)}`;
    
    // Calculate sequence
    const todayStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
    const todayExpenses = expenses.filter(e => e.tanggal === todayStr);
    const sequence = todayExpenses.length + 1;
    const seqPad = sequence < 10 ? '0' + sequence : sequence;

    setExpenseNo(`EXP-00${dateStrShort}-${seqPad}`);
    setAmount("");
    setDescription("");
    setShowAddModal(true);
  };

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount) || 0;
    const desc = description.trim();

    if (parsedAmount <= 0 || !desc) {
      if (triggerToast) {
        triggerToast("Mohon isi jumlah biaya pengeluaran dan rincian belanja secara valid!", "error");
      } else {
        alert("Mohon isi jumlah biaya pengeluaran dan rincian belanja secara valid!");
      }
      return;
    }

    const now = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    const todayStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;

    const newExpense: Expense = {
      expenseNo,
      tanggal: todayStr,
      kategori: category,
      keterangan: desc,
      jumlah: parsedAmount
    };

    onExpensesChange([...expenses, newExpense]);
    addLog("Tambah Pengeluaran", `Mencatat pengeluaran operasional ${expenseNo} sebesar ${formatIDR(parsedAmount)}`);
    
    // reset
    setShowAddModal(false);
    if (triggerToast) {
      triggerToast(`Data pengeluaran ${expenseNo} berhasil disimpan!`, "success");
    } else {
      alert("Data slip pengeluaran berhasil disimpan!");
    }
  };

  const handleDeleteExpense = (no: string, desc: string, value: number) => {
    if (confirm(`Yakin ingin membatalkan/menghapus pengeluaran "${desc}" (${formatIDR(value)})?`)) {
      onExpensesChange(expenses.filter(e => e.expenseNo !== no));
      addLog("Hapus Pengeluaran", `Menghapus slip pengeluaran operasional ${no}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Input Pengeluaran Operasional</h2>
          <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Menginput biaya pengeluaran, pembelian bahan baku, dan operasional toko.</p>
        </div>
        <button 
          onClick={handleOpenAddModal}
          className="w-full sm:w-auto bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow-sm flex items-center justify-center space-x-2 cursor-pointer transition"
        >
          <i className="fa-solid fa-plus"></i>
          <span>Tambah Pengeluaran</span>
        </button>
      </div>

      <div className="bg-white dark:bg-slate-950 rounded-2xl border border-slate-200 dark:border-slate-850 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center gap-4">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Daftar Pengeluaran Buku</span>
          <select 
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs rounded-lg p-2 outline-none text-slate-800 dark:text-slate-200 cursor-pointer"
          >
            <option value="Semua">Semua Kategori</option>
            <option value="Belanja ATK">Belanja ATK</option>
            <option value="Operasional">Operasional</option>
            <option value="Bahan Baku">Bahan Baku</option>
            <option value="Gaji Karyawan">Gaji Karyawan</option>
            <option value="Lain-lain">Lain-lain</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-850 bg-slate-50 dark:bg-slate-900/50 text-slate-400 font-bold uppercase">
                <th className="p-4 text-center w-12">No.</th>
                <th className="p-4">Kode Slip</th>
                <th className="p-4">Tanggal</th>
                <th className="p-4">Kategori</th>
                <th className="p-4">Keterangan</th>
                <th className="p-4 text-right">Jumlah Biaya</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-850 text-slate-700 dark:text-slate-350">
              {expenses
                .filter(e => filterCategory === "Semua" || e.kategori === filterCategory)
                .map((exp, index) => (
                  <tr key={exp.expenseNo} className="hover:bg-slate-50 dark:hover:bg-slate-900/40 transition border-b dark:border-slate-850">
                    <td className="p-4 text-center text-slate-500 font-bold">{index + 1}</td>
                    <td className="p-4 font-mono font-bold text-rose-500">{exp.expenseNo}</td>
                    <td className="p-4 font-semibold">{exp.tanggal}</td>
                    <td className="p-4">
                      <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[10px] font-bold">
                        {exp.kategori}
                      </span>
                    </td>
                    <td className="p-4 text-slate-500 dark:text-slate-400 font-medium">{exp.keterangan}</td>
                    <td className="p-4 text-right font-extrabold text-rose-600 font-mono">{formatIDR(exp.jumlah)}</td>
                    <td className="p-4 text-center">
                      <button 
                        onClick={() => handleDeleteExpense(exp.expenseNo, exp.keterangan, exp.jumlah)}
                        className="text-rose-500 hover:text-rose-700 font-bold hover:underline cursor-pointer transition text-xs"
                      >
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              {expenses.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-300 italic">Belum ada pengeluaran operasional terekam</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Add Exp */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-md shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden"
          >
            <div className="p-5 border-b border-slate-205 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className="fa-solid fa-plus-circle text-rose-500 text-base"></i>
                <span>Catat Pengeluaran Baru</span>
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-base"></i>
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="p-6 space-y-4 text-xs font-semibold">
              <div>
                <label className="block text-slate-450 dark:text-slate-400 uppercase mb-1.5">Kode Slip</label>
                <input 
                  type="text" 
                  value={expenseNo} 
                  disabled 
                  className="w-full bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none font-mono font-bold text-slate-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Kategori Biaya</label>
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  >
                    <option value="Belanja ATK">Belanja ATK</option>
                    <option value="Operasional">Operasional</option>
                    <option value="Bahan Baku">Bahan Baku</option>
                    <option value="Gaji Karyawan">Gaji Karyawan</option>
                    <option value="Lain-lain">Lain-lain</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 uppercase mb-1.5">Jumlah Biaya (Rp)</label>
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Rp" 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none font-bold text-slate-900 dark:text-white focus:ring-1 focus:ring-sky-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 uppercase mb-1.5">Rincian Keterangan</label>
                <textarea 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2} 
                  placeholder="Contoh: Pembelian tinta isi ulang hitam Epson L3110 3 botol..." 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none resize-none text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="p-5 border-t border-slate-200 dark:border-slate-850 flex justify-end space-x-2 pt-4 mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-100 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="bg-rose-500 hover:bg-rose-600 text-white font-bold px-4 py-2 rounded-lg transition shadow-md"
                >
                  Simpan Biaya
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
