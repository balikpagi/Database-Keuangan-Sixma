/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: string;
  username: string;
  password?: string; // Opt out for session display but keep for DB comparison safely
  role: 'Admin' | 'Operator';
  name: string;
}

export interface Item {
  id: string;
  name: string;
  category: 'ATK' | 'Fotocopy' | 'Jilid' | 'Lainnya' | string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  minStock: number;
}

export interface CartItem {
  id: string;
  name: string;
  volume: number; // Volume multiplier eg. 2 times
  qty: number; // calculated as volume * singleQty or just qty
  unit: string;
  price: number;
  taxRate: number;
  desc?: string; // item-specific description or notes, e.g. "Cetak bab 1-3"
}

export interface Sale {
  invoiceNo: string;
  kwitansiNo: string;
  trxId: string;
  tanggal: string; // "YYYY-MM-DD HH:MM"
  pelanggan: string;
  metodeBayar: 'Tunai' | 'Transfer' | 'Piutang' | string;
  subtotal: number;
  diskon: number; // percentage, e.g., 5 for 5%
  tax: number; // absolute value
  total: number;
  status: 'Lunas (Paid)' | 'Belum Lunas (Unpaid)' | string;
  keteranganBelanja: string; // General description
  itemDetail: CartItem[];
}

export interface Expense {
  expenseNo: string;
  tanggal: string; // "YYYY-MM-DD"
  kategori: 'Belanja ATK' | 'Operasional' | 'Bahan Baku' | 'Gaji Karyawan' | 'Lain-lain' | string;
  keterangan: string;
  jumlah: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
}

export interface AuditLog {
  tanggal: string; // "YYYY-MM-DD HH:MM:SS"
  aksi: string;
  keterangan: string;
  user: string;
}

export interface Settings {
  companyName: string;
  companyAddress: string;
  logo: string; // Base64 or empty
  kopSurat: string; // Base64 or empty
  signature: string; // Base64 or empty
  stamp: string; // Base64 or empty
  gasUrl: string; // Google Sheets Apps Script URL
  ownerName: string;
  ownerBankName: string;
  ownerBankNo: string;
  ownerNpwp: string;
  sumberDana?: string;
}
