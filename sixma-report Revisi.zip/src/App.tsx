/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User, Item, Sale, Expense, Customer, AuditLog, Settings, CartItem } from './types';
import { 
  getLocalStorageData, 
  saveLocalStorageData, 
  defaultUsers, 
  defaultItems, 
  defaultSales, 
  defaultExpenses, 
  defaultCustomers, 
  defaultLogs, 
  defaultSettings,
  formatIDR,
  dapatkanTerbilangRupiah
} from './utils';
import { Dashboard } from './components/Dashboard';
import { DataMaster } from './components/DataMaster';
import { InputPenjualan } from './components/InputPenjualan';
import { DataTransaksi } from './components/DataTransaksi';
import { RiwayatPenjualan } from './components/RiwayatPenjualan';
import { RekapanTagihan } from './components/RekapanTagihan';
import { InputPengeluaran } from './components/InputPengeluaran';
import { DatabasePelanggan } from './components/DatabasePelanggan';
import { LaporanKeuangan } from './components/LaporanKeuangan';
import { PengaturanInstansi } from './components/PengaturanInstansi';
import { BackupRestore } from './components/BackupRestore';
import { motion } from 'motion/react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const formatIndonesianDate = (dateStr: string) => {
  if (!dateStr) return "";
  try {
    const cleaned = dateStr.split(" ")[0]; // Get YYYY-MM-DD
    const parts = cleaned.split("-");
    if (parts.length === 3) {
      const year = parts[0];
      const monthIndex = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const months = [
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
      ];
      if (monthIndex >= 0 && monthIndex < 12) {
        return `${day} ${months[monthIndex]} ${year}`;
      }
    }
    return dateStr;
  } catch (e) {
    return dateStr;
  }
};

export default function App() {
  // Loading & Boot Animation States
  const [loading, setLoading] = useState(true);
  
  // Auth Session
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  // DB States
  const [users, setUsers] = useState<User[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [settings, setSettings] = useState<Settings>(defaultSettings);

  // Active Screen / Navigation Sesi
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Dynamic Theme State (Dark mode)
  const [darkMode, setDarkMode] = useState(false);

  // Detailed Modal Views parameters
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [docType, setDocType] = useState<'faktur' | 'kwitansi'>('faktur');
  const [pageSize, setPageSize] = useState<'a4' | 'f4'>('a4');
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  // Edit Sale modal (Koreksi invoice) params
  const [showEditSaleModal, setShowEditSaleModal] = useState(false);
  const [editingSaleIdx, setEditingSaleIdx] = useState<number>(-1);
  const [editSaleInvoiceNo, setEditSaleInvoiceNo] = useState("");
  const [editSaleDate, setEditSaleDate] = useState("");
  const [editSaleCustomer, setEditSaleCustomer] = useState("");
  const [editSalePayment, setEditSalePayment] = useState("Tunai");
  const [editSaleStatus, setEditSaleStatus] = useState("Lunas (Paid)");
  const [editSaleKeteranganBelanja, setEditSaleKeteranganBelanja] = useState("");
  const [editSaleItems, setEditSaleItems] = useState<CartItem[]>([]);

  // States for adding items inline inside the transaction edit modal
  const [newEditItemName, setNewEditItemName] = useState("");
  const [newEditItemDesc, setNewEditItemDesc] = useState("");
  const [newEditItemQty, setNewEditItemQty] = useState("1");
  const [newEditItemUnit, setNewEditItemUnit] = useState("Lembar");
  const [newEditItemPrice, setNewEditItemPrice] = useState("");

  // Cloud Integration Setup States
  const [showCloudSetupModal, setShowCloudSetupModal] = useState(false);
  const [cloudUrlInput, setCloudUrlInput] = useState("");
  const [copyCodeStatus, setCopyCodeStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // Spark quick setup handlers
  const handleOpenCloudSetupModal = () => {
    setCloudUrlInput(settings.gasUrl || "");
    setShowCloudSetupModal(true);
  };

  const handleConnectCloud = async () => {
    const trimmedUrl = cloudUrlInput.trim();
    if (!trimmedUrl) {
      triggerToast("Masukkan URL Apps Script terlebih dahulu!", "error");
      return;
    }
    if (!trimmedUrl.startsWith("https://script.google.com/")) {
      triggerToast("URL tidak valid! Harus diawali dengan https://script.google.com/", "error");
      return;
    }
    
    const newSettings = { ...settings, gasUrl: trimmedUrl };
    setSettings(newSettings);
    setShowCloudSetupModal(false);
    saveLocalStorageData('sixma_settings', newSettings);
    addLog("Koreksi Pengaturan", "Menghubungkan aplikasi ke deployment Google Apps Script melalui Setup Cepat");
    
    // Attempt pulling from GAS
    await handleSyncPull(trimmedUrl);
  };

  const handleCopyGasCode = async () => {
    try {
      const gasCode = `/**
 * ===========================================================================
 * SIXMA REPORT SYSTEM - GOOGLE APPS SCRIPT FULL-STACK ENGINE (Code.gs)
 * ===========================================================================
 * Provides high-speed dual-layer storage connection to Google Sheets.
 */

var TAB_MASTER_JSON = "_master_db_json";
var TAB_USERS = "Users";
var TAB_ITEMS = "Items";
var TAB_SALES = "Sales";
var TAB_SALES_DETAIL = "Sales_Details";
var TAB_EXPENSES = "Expenses";
var TAB_CUSTOMERS = "Customers";
var TAB_LOGS = "Logs";
var TAB_SETTINGS = "Settings";

function doGet(e) {
  if (e && e.parameter && (e.parameter.api === "true" || e.parameter.action)) {
    try {
      var dbState = readMasterData();
      return createJsonResponse({ status: "success", data: dbState });
    } catch (err) {
      return createJsonResponse({ status: "error", message: err.toString() });
    }
  }
  return ContentService.createTextOutput("Backend Google Sheets BERHASIL Dibuat! Silakan hubungkan URL Web App berkas Apps Script ini ke sistem aplikasi.");
}

function doPost(e) {
  try {
    var postContent = e.postData.contents;
    var payload = JSON.parse(postContent);
    if (payload.action === "sync_write") {
      writeMasterData(payload.data);
      updateSpreadsheetTabs(payload.data);
      return createJsonResponse({ status: "success", message: "Data berhasil disimpan dari client!" });
    }
    return createJsonResponse({ status: "error", message: "Aksi tidak dikenali." });
  } catch (err) {
    return createJsonResponse({ status: "error", message: err.toString() });
  }
}

function readMasterData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB_MASTER_JSON);
  if (!sheet) return { users: [], items: [], sales: [], expenses: [], customers: [], logs: [], settings: {} };
  var rawJson = sheet.getRange(1, 1).getValue();
  if (!rawJson) return { users: [], items: [], sales: [], expenses: [], customers: [], logs: [], settings: {} };
  return JSON.parse(rawJson);
}

function writeMasterData(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB_MASTER_JSON);
  if (!sheet) {
    sheet = ss.insertSheet(TAB_MASTER_JSON);
    sheet.hideSheet();
  }
  sheet.getRange(1, 1).setValue(JSON.stringify(data));
}

function updateSpreadsheetTabs(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  updateTabGeneric(ss, TAB_USERS, ["ID Pengguna", "Username", "Role/Akses", "Nama Lengkap"], data.users || [], function(user) {
    return [user.id, user.username, user.role, user.name];
  });
  updateTabGeneric(ss, TAB_ITEMS, ["ID Barang", "Nama Barang", "Kategori", "Harga Modal (Rp)", "Harga Jual (Rp)", "Stok Terkini", "Minimum Stok"], data.items || [], function(item) {
    return [item.id, item.name, item.category, item.buyPrice, item.sellPrice, item.stock, item.minStock];
  });
  updateTabGeneric(ss, TAB_EXPENSES, ["No Pengeluaran", "Tanggal", "Kategori", "Keterangan", "Jumlah (Rp)"], data.expenses || [], function(exp) {
    return [exp.expenseNo, exp.tanggal, exp.kategori, exp.keterangan, exp.jumlah];
  });
  updateTabGeneric(ss, TAB_CUSTOMERS, ["ID Pelanggan", "Nama Instansi / Pembeli", "Nomor Telepon", "Email", "Alamat Lengkap"], data.customers || [], function(cust) {
    return [cust.id, cust.name, cust.phone, cust.email, cust.address];
  });
  updateTabGeneric(ss, TAB_LOGS, ["Waktu / Tanggal", "Kategori Aksi", "Rincian Kejadian", "User Pelaksana"], data.logs || [], function(log) {
    return [log.tanggal, log.aksi, log.keterangan, log.user];
  });
  var settingsList = [];
  if (data.settings) {
    var s = data.settings;
    settingsList = [
      ["Nama Instansi", s.companyName || ""],
      ["Alamat Instansi", s.companyAddress || ""],
      ["Nama Pemilik/Owner", s.ownerName || ""],
      ["Bank Tujuan", s.ownerBankName || ""],
      ["Nomor Rekening", s.ownerBankNo || ""],
      ["NPWP Perusahaan", s.ownerNpwp || ""]
    ];
  }
  updateTabSettingsGeneric(ss, TAB_SETTINGS, ["Parameter", "Nilai"], settingsList);
  updateTabSalesAndDetails(ss, data.sales || []);
}

function updateTabGeneric(ss, tabName, headers, listData, mapRowFn) {
  var sheet = ss.getSheetByName(tabName) || ss.insertSheet(tabName);
  sheet.clear();
  var rows = [headers];
  for (var i = 0; i < listData.length; i++) rows.push(mapRowFn(listData[i]));
  sheet.getRange(1, 1, rows.length, headers.length).setValues(rows);
  formatSheetHeader(sheet, headers.length);
}

function updateTabSettingsGeneric(ss, tabName, headers, settingsList) {
  var sheet = ss.getSheetByName(tabName) || ss.insertSheet(tabName);
  sheet.clear();
  var rows = [headers];
  for (var i = 0; i < settingsList.length; i++) rows.push(settingsList[i]);
  sheet.getRange(1, 1, rows.length, 2).setValues(rows);
  formatSheetHeader(sheet, 2);
}

function updateTabSalesAndDetails(ss, salesList) {
  var salesSheet = ss.getSheetByName(TAB_SALES) || ss.insertSheet(TAB_SALES);
  salesSheet.clear();
  var salesRows = [["No. Invoice", "No. Kwitansi", "Trx ID", "Tanggal Transaksi", "Nama Pelanggan", "Metode Pembayaran", "Subtotal (Rp)", "Diskon (%)", "Pajak (Rp)", "Total (Rp)", "Status", "Keterangan"]];
  
  var detailSheet = ss.getSheetByName(TAB_SALES_DETAIL) || ss.insertSheet(TAB_SALES_DETAIL);
  detailSheet.clear();
  var detailRows = [["No. Invoice", "Nama Barang", "Volume", "Qty", "Satuan", "Harga (Rp)", "Pajak (%)", "Catatan", "Total Item (Rp)"]];
  
  for (var i = 0; i < salesList.length; i++) {
    var sale = salesList[i];
    salesRows.push([sale.invoiceNo, sale.kwitansiNo, sale.trxId, sale.tanggal, sale.pelanggan, sale.metodeBayar, sale.subtotal, sale.diskon, sale.tax, sale.total, sale.status, sale.keteranganBelanja]);
    if (sale.itemDetail) {
      for (var j = 0; j < sale.itemDetail.length; j++) {
        var item = sale.itemDetail[j];
        detailRows.push([sale.invoiceNo, item.name, item.volume, item.qty, item.unit, item.price, item.taxRate, item.desc || "", (item.price * item.qty) * (1 + item.taxRate/100)]);
      }
    }
  }
  salesSheet.getRange(1, 1, salesRows.length, salesRows[0].length).setValues(salesRows);
  if (detailRows.length > 1) detailSheet.getRange(1, 1, detailRows.length, detailRows[0].length).setValues(detailRows);
  formatSheetHeader(salesSheet, salesRows[0].length);
  formatSheetHeader(detailSheet, detailRows[0].length);
}

function formatSheetHeader(sheet, numColumns) {
  var headerRange = sheet.getRange(1, 1, 1, numColumns);
  headerRange.setBackground("#0284c7").setFontColor("#ffffff").setFontWeight("bold").setHorizontalAlignment("center");
  sheet.autoResizeColumns(1, numColumns);
}

function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}`;

      await navigator.clipboard.writeText(gasCode);
      setCopyCodeStatus('success');
      triggerToast("Kode Apps Script berhasil disalin!", "success");
      setTimeout(() => setCopyCodeStatus('idle'), 3000);
    } catch (err) {
      setCopyCodeStatus('error');
      triggerToast("Gagal menyalin kode", "error");
      setTimeout(() => setCopyCodeStatus('idle'), 3000);
    }
  };

  // Toast System notifications
  const [toastMessage, setToastMessage] = useState("");
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('success');
  const [showToast, setShowToast] = useState(false);

  // Sync System parameters
  const [syncStatus, setSyncStatus] = useState<'idle' | 'pulling' | 'pushing' | 'success' | 'error'>('idle');

  // Trigger temporary notification
  const triggerToast = (msg: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setShowToast(true);
  };

  useEffect(() => {
    if (showToast) {
      const timer = setTimeout(() => {
        setShowToast(false);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [showToast]);

  // Helper to apply downloaded database data to our React state
  const applySyncedData = (d: any, url: string) => {
    if (d.users && d.users.length > 0) {
      setUsers(d.users);
      saveLocalStorageData('sixma_users', d.users);
    }
    if (d.items && d.items.length > 0) {
      setItems(d.items);
      saveLocalStorageData('sixma_items', d.items);
    }
    if (d.sales && d.sales.length > 0) {
      setSales(d.sales);
      saveLocalStorageData('sixma_sales', d.sales);
    }
    if (d.expenses && d.expenses.length > 0) {
      setExpenses(d.expenses);
      saveLocalStorageData('sixma_expenses', d.expenses);
    }
    if (d.customers && d.customers.length > 0) {
      setCustomers(d.customers);
      saveLocalStorageData('sixma_customers', d.customers);
    }
    if (d.logs && d.logs.length > 0) {
      setLogs(d.logs);
      saveLocalStorageData('sixma_logs', d.logs);
    }
    if (d.settings) {
      const mergedSettings = { ...defaultSettings, ...d.settings, gasUrl: url || d.settings.gasUrl || settings.gasUrl };
      setSettings(mergedSettings);
      saveLocalStorageData('sixma_settings', mergedSettings);
    }
  };

  // Handle Fetching state from GAS (Continuous online sync)
  const handleSyncPull = async (url: string) => {
    // If running natively inside Google Apps Script (GAS) Web App / safe container
    if (typeof (window as any).google !== 'undefined' && typeof (window as any).google.script !== 'undefined') {
      setSyncStatus('pulling');
      try {
        (window as any).google.script.run
          .withSuccessHandler((dbData: any) => {
            if (dbData) {
              applySyncedData(dbData, url);
              setSyncStatus('success');
              triggerToast("Sinkronisasi internal Google Sheets sukses!", "success");
            } else {
              setSyncStatus('error');
            }
          })
          .withFailureHandler((err: any) => {
            console.error("Internal GAS Pull failed", err);
            setSyncStatus('error');
            triggerToast("Gagal mengambil data internal GAS: " + err, "error");
          })
          .readMasterData();
      } catch (err) {
        console.error("Failed to trigger internal GAS read", err);
        setSyncStatus('error');
      }
      return;
    }

    if (!url) return;
    setSyncStatus('pulling');
    try {
      const syncUrl = url.includes('?') ? `${url}&api=true` : `${url}?api=true`;
      const response = await fetch(syncUrl);
      const json = await response.json();
      if (json && json.status === 'success' && json.data) {
        applySyncedData(json.data, url);
        setSyncStatus('success');
        triggerToast("Sinkronisasi cloud otomatis sukses!", "success");
      } else {
        setSyncStatus('error');
      }
    } catch (err) {
      console.error("GAS Pull failed", err);
      setSyncStatus('error');
    }
  };

  // Handle Writing local state to GAS Web App (Triggered on save/delete/edit actions)
  const pushStateToGAS = async (url: string, changedPayload: {
    users?: User[];
    items?: Item[];
    sales?: Sale[];
    expenses?: Expense[];
    customers?: Customer[];
    logs?: AuditLog[];
    settings?: Settings;
  }) => {
    // Construct the fully compiled payload from references to ensure absolute data integration
    const fullData = {
      users: changedPayload.users || users,
      items: changedPayload.items || items,
      sales: changedPayload.sales || sales,
      expenses: changedPayload.expenses || expenses,
      customers: changedPayload.customers || customers,
      logs: changedPayload.logs || logs,
      settings: changedPayload.settings || settings
    };

    // If running natively inside Google Apps Script (GAS) Web App
    if (typeof (window as any).google !== 'undefined' && typeof (window as any).google.script !== 'undefined') {
      setSyncStatus('pushing');
      try {
        (window as any).google.script.run
          .withSuccessHandler((res: any) => {
            setSyncStatus('success');
            triggerToast("Data tersimpan di Google Sheets!", "success");
          })
          .withFailureHandler((err: any) => {
            console.error("Internal GAS Push failed", err);
            setSyncStatus('error');
            triggerToast("Gagal menyimpan data internal GAS: " + err, "error");
          })
          .saveMasterFromClient(fullData);
      } catch (err) {
        console.error("Failed to trigger internal GAS write", err);
        setSyncStatus('error');
      }
      return;
    }

    if (!url) return;
    setSyncStatus('pushing');

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "text/plain;charset=utf-8"
        },
        body: JSON.stringify({
          action: "sync_write",
          data: fullData
        })
      });
      const json = await response.json();
      if (json && json.status === "success") {
        setSyncStatus('success');
        triggerToast("Data otomatis terintegrasi ke Google Sheets!", "success");
      } else {
        setSyncStatus('error');
      }
    } catch (err) {
      console.error("GAS Push failed", err);
      setSyncStatus('error');
    }
  };

  // Load Database from LocalStorage standard
  useEffect(() => {
    const loadedUsers = getLocalStorageData<User[]>('sixma_users', defaultUsers);
    const loadedItems = getLocalStorageData<Item[]>('sixma_items', defaultItems);
    const loadedSales = getLocalStorageData<Sale[]>('sixma_sales', defaultSales);
    const loadedExpenses = getLocalStorageData<Expense[]>('sixma_expenses', defaultExpenses);
    const loadedCustomers = getLocalStorageData<Customer[]>('sixma_customers', defaultCustomers);
    const loadedLogs = getLocalStorageData<AuditLog[]>('sixma_logs', defaultLogs);
    const loadedSettings = getLocalStorageData<Settings>('sixma_settings', defaultSettings);

    setUsers(loadedUsers);
    setItems(loadedItems);
    setSales(loadedSales);
    setExpenses(loadedExpenses);
    setCustomers(loadedCustomers);
    setLogs(loadedLogs);
    setSettings(loadedSettings);

    // Initial startup pulling sync if GAS URL setup is available, or running natively inside Google Apps Script
    if (loadedSettings.gasUrl || (typeof (window as any).google !== 'undefined' && typeof (window as any).google.script !== 'undefined')) {
      handleSyncPull(loadedSettings.gasUrl);
    }

    // Load theme setting
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    // Check active Session store
    const active = sessionStorage.getItem('sixma_session');
    if (active) {
      try {
        setCurrentUser(JSON.parse(active));
      } catch (err) {
        console.error("Session parse failed", err);
      }
    }

    // Dismount loader screen with fade-out
    const bootTimer = setTimeout(() => {
      setLoading(false);
    }, 600);

    return () => clearTimeout(bootTimer);
  }, []);

  // System Auditing logging function
  const addLog = (action: string, detail: string) => {
    const now = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    
    const newLog: AuditLog = {
      tanggal: dateStr,
      aksi: action,
      keterangan: detail,
      user: currentUser ? currentUser.name : "System"
    };

    const updatedLogs = [...logs, newLog];
    setLogs(updatedLogs);
    saveLocalStorageData('sixma_logs', updatedLogs);
    
    // Auto push transaction logs to cloud
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { logs: updatedLogs });
    }
  };

  // State Updates Sync Pipelines
  const handleUsersChange = (newUsers: User[]) => {
    setUsers(newUsers);
    saveLocalStorageData('sixma_users', newUsers);
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { users: newUsers });
    }
  };

  const handleItemsChange = (newItems: Item[]) => {
    setItems(newItems);
    saveLocalStorageData('sixma_items', newItems);
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { items: newItems });
    }
  };

  const handleSalesChange = (newSales: Sale[]) => {
    setSales(newSales);
    saveLocalStorageData('sixma_sales', newSales);
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { sales: newSales });
    }
  };

  const handleExpensesChange = (newExpenses: Expense[]) => {
    setExpenses(newExpenses);
    saveLocalStorageData('sixma_expenses', newExpenses);
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { expenses: newExpenses });
    }
  };

  const handleCustomersChange = (newCustomers: Customer[]) => {
    setCustomers(newCustomers);
    saveLocalStorageData('sixma_customers', newCustomers);
    if (settings.gasUrl) {
      pushStateToGAS(settings.gasUrl, { customers: newCustomers });
    }
  };

  const handleSettingsChange = (newSettings: Settings) => {
    setSettings(newSettings);
    saveLocalStorageData('sixma_settings', newSettings);
    if (newSettings.gasUrl) {
      pushStateToGAS(newSettings.gasUrl, { settings: newSettings });
    }
  };

  const handleFullStateImport = (fullState: any) => {
    let finalUsers = users;
    let finalItems = items;
    let finalSales = sales;
    let finalExpenses = expenses;
    let finalCustomers = customers;
    let finalSettings = settings;
    let finalLogs = logs;

    if (fullState.users) {
      finalUsers = fullState.users;
      setUsers(finalUsers);
      saveLocalStorageData('sixma_users', finalUsers);
    }
    if (fullState.items) {
      finalItems = fullState.items;
      setItems(finalItems);
      saveLocalStorageData('sixma_items', finalItems);
    }
    if (fullState.sales) {
      finalSales = fullState.sales;
      setSales(finalSales);
      saveLocalStorageData('sixma_sales', finalSales);
    }
    if (fullState.expenses) {
      finalExpenses = fullState.expenses;
      setExpenses(finalExpenses);
      saveLocalStorageData('sixma_expenses', finalExpenses);
    }
    if (fullState.customers) {
      finalCustomers = fullState.customers;
      setCustomers(finalCustomers);
      saveLocalStorageData('sixma_customers', finalCustomers);
    }
    if (fullState.settings) {
      finalSettings = fullState.settings;
      setSettings(finalSettings);
      saveLocalStorageData('sixma_settings', finalSettings);
    }
    if (fullState.logs) {
      finalLogs = fullState.logs;
      setLogs(finalLogs);
      saveLocalStorageData('sixma_logs', finalLogs);
    }

    if (finalSettings.gasUrl) {
      pushStateToGAS(finalSettings.gasUrl, {
        users: finalUsers,
        items: finalItems,
        sales: finalSales,
        expenses: finalExpenses,
        customers: finalCustomers,
        settings: finalSettings,
        logs: finalLogs,
      });
    }
  };

  const getFullState = () => {
    return {
      users,
      items,
      sales,
      expenses,
      customers,
      logs,
      settings
    };
  };

  // Authentication Sesi Locks
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const matched = users.find(u => u.username === loginUsername.trim() && u.password === loginPassword.trim());
    if (matched) {
      setCurrentUser(matched);
      sessionStorage.setItem('sixma_session', JSON.stringify(matched));
      
      // Clear inputs
      setLoginUsername("");
      setLoginPassword("");
      
      triggerToast(`Sesi login sukses! Selamat datang, ${matched.name}.`, "success");
      activeLogWithUser("Masuk Sesi", `Berhasil masuk dengan username: ${matched.username}`, matched.name);
    } else {
      triggerToast("Nama pengguna (username) atau sandi salah!", "error");
    }
  };

  // Dedicated Logger with custom username parameter
  const activeLogWithUser = (action: string, detail: string, userName: string) => {
    const now = new Date();
    const pad = (n: number) => n < 10 ? '0' + n : n;
    const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    
    const newLog: AuditLog = {
      tanggal: dateStr,
      aksi: action,
      keterangan: detail,
      user: userName
    };

    const updatedLogs = [...logs, newLog];
    setLogs(updatedLogs);
    saveLocalStorageData('sixma_logs', updatedLogs);
  };

  const handleLogout = () => {
    if (currentUser) {
      activeLogWithUser("Keluar Sesi", "Keluar dari sistem", currentUser.name);
    }
    setCurrentUser(null);
    sessionStorage.removeItem('sixma_session');
    triggerToast("Anda telah keluar dari aplikasi secara aman.", "success");
  };

  // Toggle Theme color mode
  const toggleDarkMode = () => {
    if (darkMode) {
      document.documentElement.classList.remove('dark');
      setDarkMode(false);
      localStorage.setItem('theme', 'light');
    } else {
      document.documentElement.classList.add('dark');
      setDarkMode(true);
      localStorage.setItem('theme', 'dark');
    }
  };

  // View Invoice detail
  const handleViewInvoice = (sale: Sale, type: 'faktur' | 'kwitansi') => {
    setSelectedSale(sale);
    setDocType(type);
    setShowInvoiceModal(true);
  };

  const handlePrintDocument = () => {
    // Add temporary body class for absolute printing overrides
    document.body.classList.add('print-mode-active');
    setTimeout(() => {
      window.print();
      setTimeout(() => {
        document.body.classList.remove('print-mode-active');
      }, 500);
    }, 100);
  };

  // Edit Sale modal triggers
  const handleOpenEditSaleModal = (saleIndex: number) => {
    const sale = sales[saleIndex];
    if (sale) {
      setEditingSaleIdx(saleIndex);
      setEditSaleInvoiceNo(sale.invoiceNo);
      setEditSaleDate(sale.tanggal);
      setEditSaleCustomer(sale.pelanggan);
      setEditSalePayment(sale.metodeBayar);
      setEditSaleStatus(sale.status);
      setEditSaleKeteranganBelanja(sale.keteranganBelanja || "");
      setEditSaleItems(sale.itemDetail);
      setShowEditSaleModal(true);
    }
  };

  const handleUpdateEditSaleItemQty = (itemIndex: number, newQtyStr: string) => {
    const q = parseFloat(newQtyStr) || 1;
    const updated = editSaleItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, qty: q };
      }
      return item;
    });
    setEditSaleItems(updated);
  };

  const handleUpdateEditSaleItemPrice = (itemIndex: number, newPriceStr: string) => {
    const p = parseFloat(newPriceStr) || 0;
    const updated = editSaleItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, price: p };
      }
      return item;
    });
    setEditSaleItems(updated);
  };

  const handleUpdateEditSaleItemName = (itemIndex: number, newName: string) => {
    const updated = editSaleItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, name: newName };
      }
      return item;
    });
    setEditSaleItems(updated);
  };

  const handleUpdateEditSaleItemDesc = (itemIndex: number, newDesc: string) => {
    const updated = editSaleItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, desc: newDesc };
      }
      return item;
    });
    setEditSaleItems(updated);
  };

  const handleUpdateEditSaleItemUnit = (itemIndex: number, newUnit: string) => {
    const updated = editSaleItems.map((item, idx) => {
      if (idx === itemIndex) {
        return { ...item, unit: newUnit };
      }
      return item;
    });
    setEditSaleItems(updated);
  };

  const handleDeleteEditSaleItem = (itemIndex: number) => {
    if (editSaleItems.length <= 1) {
      triggerToast("Transaksi minimal harus memiliki 1 item barang/jasa!", "error");
      return;
    }
    const updated = editSaleItems.filter((_, idx) => idx !== itemIndex);
    setEditSaleItems(updated);
    triggerToast("Item berhasil dihapus dari daftar koreksi.", "info");
  };

  const handleAddCustomItemToEditSale = () => {
    if (!newEditItemName.trim()) {
      triggerToast("Nama item tidak boleh kosong!", "error");
      return;
    }
    const n = newEditItemName.trim();
    const d = newEditItemDesc.trim();
    const q = parseFloat(newEditItemQty) || 1;
    const u = newEditItemUnit.trim() || "Lembar";
    const p = parseFloat(newEditItemPrice) || 0;

    const newItem: CartItem = {
      id: "CUSTOM-" + Math.floor(100 + Math.random() * 900),
      name: n,
      volume: 1,
      qty: q,
      unit: u,
      price: p,
      taxRate: 0,
      desc: d
    };

    setEditSaleItems([...editSaleItems, newItem]);
    
    // reset add form fields
    setNewEditItemName("");
    setNewEditItemDesc("");
    setNewEditItemQty("1");
    setNewEditItemUnit("Lembar");
    setNewEditItemPrice("");
    
    triggerToast(`Berhasil menambahkan "${n}" ke daftar koreksi!`, "success");
  };

  const handleSaveEditedSale = () => {
    const baseSale = sales[editingSaleIdx];
    if (baseSale) {
      let subtotal = 0;
      editSaleItems.forEach(i => {
        subtotal += (i.qty * i.price);
      });

      const discAmt = subtotal * (baseSale.diskon / 100);
      const afterDisc = subtotal - discAmt;
      let tax = 0;
      if (baseSale.tax > 0) {
        tax = Math.round(afterDisc * 0.11);
      }

      const updatedSale: Sale = {
        ...baseSale,
        tanggal: editSaleDate,
        pelanggan: editSaleCustomer,
        metodeBayar: editSalePayment,
        status: editSaleStatus,
        keteranganBelanja: editSaleKeteranganBelanja,
        subtotal,
        tax,
        total: Math.round(afterDisc + tax),
        itemDetail: editSaleItems
      };

      const updatedSalesList = sales.map((s, idx) => {
        if (idx === editingSaleIdx) return updatedSale;
        return s;
      });

      handleSalesChange(updatedSalesList);
      addLog("Koreksi Penjualan", `Koreksi data rincian penjualan No: ${baseSale.invoiceNo}`);
      setShowEditSaleModal(false);
      triggerToast("Koreksi rincian data transaksi berhasil disimpan!", "success");
    }
  };

  // Helper to mathematically convert OKLCH format strings to standard safe RGB / RGBA strings.
  // This bypasses html2canvas limitations parsing OKLCH color space.
  const convertOklchToRgb = (oklchStr: string): string => {
    const regex = /oklch\(\s*([0-9.]+%?)\s+([0-9.]+)\s+([0-9.]+(?:deg|rad|turn)?)\s*(?:\/\s*([0-9.]+%?))?\s*\)/gi;
    
    return oklchStr.replace(regex, (match, p1, p2, p3, p4) => {
      try {
        let l = p1.endsWith('%') ? parseFloat(p1) / 100 : parseFloat(p1);
        let c = parseFloat(p2);
        let hVal = parseFloat(p3);
        if (p3.endsWith('rad')) {
          hVal = hVal * (180 / Math.PI);
        } else if (p3.endsWith('turn')) {
          hVal = hVal * 360;
        } else if (p3.endsWith('deg')) {
          hVal = parseFloat(p3);
        }
        
        let a = 1;
        if (p4) {
          a = p4.endsWith('%') ? parseFloat(p4) / 100 : parseFloat(p4);
        }
        
        const hRad = (hVal * Math.PI) / 180;
        const oklab_a = c * Math.cos(hRad);
        const oklab_b = c * Math.sin(hRad);
        
        const l_lms = l + 0.3963377774 * oklab_a + 0.2158037573 * oklab_b;
        const m_lms = l - 0.1055613458 * oklab_a - 0.0638541728 * oklab_b;
        const s_lms = l - 0.0894841775 * oklab_a - 1.2914855480 * oklab_b;
        
        const l_cube = l_lms * l_lms * l_lms;
        const m_cube = m_lms * m_lms * m_lms;
        const s_cube = s_lms * s_lms * s_lms;
        
        const r_lin = +4.0767416621 * l_cube - 3.3077115913 * m_cube + 0.2309699292 * s_cube;
        const g_lin = -1.2684380046 * l_cube + 2.6097574011 * m_cube - 0.3413193965 * s_cube;
        const b_lin = -0.0041960863 * l_cube - 0.7034186147 * m_cube + 1.7076172310 * s_cube;
        
        const gammaCorrect = (v: number) => {
          return v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1.0 / 2.4) - 0.055;
        };
        
        let r = Math.round(Math.max(0, Math.min(1, gammaCorrect(r_lin))) * 255);
        let g = Math.round(Math.max(0, Math.min(1, gammaCorrect(g_lin))) * 255);
        let b = Math.round(Math.max(0, Math.min(1, gammaCorrect(b_lin))) * 255);
        
        if (a === 1) {
          return `rgb(${r}, ${g}, ${b})`;
        } else {
          return `rgba(${r}, ${g}, ${b}, ${a})`;
        }
      } catch (e) {
        return 'rgb(0, 0, 0)';
      }
    });
  };

  // High-fidelity PDF document generation using html2canvas & jspdf
  const handleDownloadDocPDF = async (size: 'A4' | 'F4') => {
    if (!selectedSale) return;
    
    const element = document.getElementById('printable-document-area');
    if (!element) {
      triggerToast("Elemen pratinjau dokumen tidak ditemukan", "error");
      return;
    }
    
    setSyncStatus('pulling');
    triggerToast("Sedang memproses dokumen PDF beresolusi tinggi...", "info");
    
    try {
      // Execute html2canvas with specific quality configurations and styled clones
      const canvas = await html2canvas(element, {
        scale: 2.2, // Generates clean, crisp vector-like text layouts
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        logging: false,
        onclone: (clonedDoc) => {
          // 1. Remove standard link & style tags inside clone to decouple fragile oklch stylesheets
          clonedDoc.querySelectorAll('link[rel="stylesheet"]').forEach(el => el.remove());
          clonedDoc.querySelectorAll('style').forEach(el => el.remove());
          
          // 2. Read calculated CSS rules directly from original document to preserve active layouts
          let combinedCSS = "";
          try {
            Array.from(document.styleSheets).forEach((sheet) => {
              try {
                const rules = sheet.cssRules || sheet.rules;
                if (rules) {
                  Array.from(rules).forEach((rule) => {
                    combinedCSS += rule.cssText + "\n";
                  });
                }
              } catch (sheetErr) {
                // Ignore cross-origin access limitations
              }
            });
          } catch (e) {
            console.error("Gagal mengekstrak stylesheets untuk clone:", e);
          }
          
          // 3. Process the rule strings to translate OKLCH-based definitions to canvas-friendly rgb/rgba fallback
          const safeCSS = convertOklchToRgb(combinedCSS);
          
          const styleNode = clonedDoc.createElement('style');
          styleNode.textContent = safeCSS;
          clonedDoc.head.appendChild(styleNode);
          
          // 4. Also dynamically clean any inline oklch statements defined inside the cloned tags
          clonedDoc.querySelectorAll('*').forEach((el: any) => {
            const styleAttr = el.getAttribute('style');
            if (styleAttr && styleAttr.includes('oklch')) {
              el.setAttribute('style', convertOklchToRgb(styleAttr));
            }
          });
        }
      });
      
      const imgData = canvas.toDataURL('image/png');
      
      // Page size mapping in mm
      // A4: 210mm x 297mm
      // F4 (Folio): 215mm x 330mm
      const widthMm = size === 'A4' ? 210 : 215;
      const heightMm = size === 'A4' ? 297 : 330;
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [widthMm, heightMm]
      });
      
      const imgWidth = widthMm;
      const pageHeight = heightMm;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      const docLabel = docType === 'faktur' ? 'Faktur' : 'Kwitansi';
      const docNo = docType === 'faktur' ? selectedSale.invoiceNo : selectedSale.kwitansiNo;
      pdf.save(`${docLabel}_${size}_${docNo}.pdf`);
      
      setSyncStatus('success');
      triggerToast(`Dokumen PDF ${size} berhasil diunduh!`, "success");
    } catch (err: any) {
      console.error("Gagal membuat PDF:", err);
      setSyncStatus('error');
      triggerToast("Gagal mengunduh dokumen PDF: " + err, "error");
    }
  };

  return (
    <div className="bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 antialiased h-screen max-h-screen overflow-hidden flex flex-col transition-colors duration-300">
      
      {/* 1. Dissolving Boot Loading Layer */}
      {loading && (
        <div className="fixed inset-0 bg-slate-900 text-white z-[9999] flex flex-col items-center justify-center space-y-4">
          <div className="relative w-20 h-20">
            <div className="absolute inset-0 border-4 border-sky-500/20 rounded-full"></div>
            <div className="absolute inset-0 border-4 border-sky-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
          <div className="text-center">
            <h2 className="text-xl font-extrabold tracking-wider text-white">SIXMA REPORT</h2>
            <p className="text-xs text-slate-400 mt-1">Menyiapkan Database Terintegrasi...</p>
          </div>
        </div>
      )}

      {/* 2. Login Overlay Screen */}
      {!currentUser && (
        <div className="fixed inset-0 bg-slate-100 dark:bg-slate-950 z-[9000] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-md space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-sky-500 text-white font-extrabold mx-auto rounded-2xl flex items-center justify-center text-2xl shadow-lg shadow-sky-500/20">
                {settings.logo ? <img src={settings.logo} className="w-11 h-11 object-contain" alt="Logo" /> : "SR"}
              </div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white">Masuk Aplikasi</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">Sistem Laporan Terpadu & Kasir {settings.companyName}</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4 font-semibold text-xs text-slate-700 dark:text-slate-300">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Nama Pengguna (Username)</label>
                <div className="relative">
                  <input 
                    type="text" 
                    value={loginUsername}
                    onChange={(e) => setLoginUsername(e.target.value)}
                    placeholder="Masukkan username..." 
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:ring-2 focus:ring-sky-500/20 outline-none text-slate-900 dark:text-white"
                    required
                  />
                  <i className="fa-solid fa-user absolute left-3.5 top-3.5 text-slate-400"></i>
                </div>
              </div>
              
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Kata Sandi (Password)</label>
                <div className="relative">
                  <input 
                    type="password" 
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Masukkan kata sandi..." 
                    className="w-full pl-10 pr-10 py-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs focus:ring-2 focus:ring-sky-500/20 outline-none text-slate-900 dark:text-white"
                    required
                  />
                  <i className="fa-solid fa-lock absolute left-3.5 top-3.5 text-slate-400"></i>
                </div>
              </div>

              <button 
                type="submit" 
                className="w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-3.5 rounded-xl transition shadow-lg shadow-sky-500/20 text-xs cursor-pointer"
              >
                Masuk Sesi Sekarang
              </button>
            </form>

            <div className="text-center text-[11px] text-slate-400">
              Default: Admin (<span className="font-bold text-sky-500 font-mono">admin / admin123</span>) | Operator (<span className="font-bold text-sky-500 font-mono">operator / operator123</span>)
            </div>
          </div>
        </div>
      )}

      {/* 3. Main Client Container */}
      {currentUser && (
        <div className="flex flex-1 overflow-hidden">
          
          {/* Main Sidebar (Left panel - hides during printable layouts) */}
          <aside className="w-72 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0 no-print border-r border-slate-800 max-h-screen overflow-y-auto">
            <div className="p-6 border-b border-slate-800 flex items-center space-x-3">
              <div className="bg-sky-500 text-white font-extrabold px-3 py-2 rounded-lg text-lg tracking-wider shadow-md shadow-sky-500/20">
                {settings.logo ? <img src={settings.logo} className="w-8 h-8 object-contain" alt="Logo" /> : "SR"}
              </div>
              <div>
                <h1 className="font-bold text-white tracking-wide text-md leading-tight">{settings.companyName || "Sixma Report"}</h1>
                <p className="text-[9px] text-slate-400 font-semibold tracking-wider">SISTEM LAPORAN TERPADU</p>
              </div>
            </div>

            <div className="p-5 border-b border-slate-800 bg-slate-950/40 flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-sky-600 text-white font-bold flex items-center justify-center border border-sky-400">
                {currentUser.name.substring(0, 2).toUpperCase()}
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">{currentUser.name}</h4>
                <span className="inline-block bg-sky-500/10 text-sky-400 text-[9px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider mt-1">{currentUser.role}</span>
              </div>
            </div>

            <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
              <span className="text-[9px] font-bold text-slate-500 tracking-wider uppercase px-3 block mb-2">MENU UTAMA</span>
              
              <button 
                onClick={() => setActiveTab("dashboard")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "dashboard" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-chart-line w-5 text-center text-base mr-2"></i>
                <span>Dashboard ERP</span>
              </button>

              <button 
                onClick={() => setActiveTab("stok")}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "stok" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <div className="flex items-center">
                  <i className="fa-solid fa-boxes-stacked w-5 text-center text-base mr-2"></i>
                  <span>Data Master</span>
                </div>
                {items.filter(i => i.stock <= i.minStock && i.category !== "Fotocopy" && i.category !== "Jilid").length > 0 && (
                  <span className="bg-rose-500 text-white text-[9px] font-extrabold px-1.5 py-0.5 rounded-full">
                    {items.filter(i => i.stock <= i.minStock && i.category !== "Fotocopy" && i.category !== "Jilid").length}
                  </span>
                )}
              </button>

              <button 
                onClick={() => setActiveTab("penjualan")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "penjualan" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-cart-shopping w-5 text-center text-base mr-2"></i>
                <span>Input Penjualan</span>
              </button>

              <button 
                onClick={() => setActiveTab("data-transaksi")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "data-transaksi" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-file-invoice w-5 text-center text-base mr-2"></i>
                <span>Data Transaksi</span>
              </button>

              <button 
                onClick={() => setActiveTab("riwayat-transaksi")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "riwayat-transaksi" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-clock-rotate-left w-5 text-center text-base mr-2"></i>
                <span>Riwayat Transaksi</span>
              </button>

              <button 
                onClick={() => setActiveTab("rekapan-tagihan")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "rekapan-tagihan" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-file-invoice-dollar w-5 text-center text-base mr-2"></i>
                <span>Rekapan Tagihan</span>
              </button>

              <button 
                onClick={() => setActiveTab("pengeluaran")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "pengeluaran" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-wallet w-5 text-center text-base mr-2"></i>
                <span>Input Pengeluaran</span>
              </button>

              <button 
                onClick={() => setActiveTab("pelanggan")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "pelanggan" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-users w-5 text-center text-base mr-2"></i>
                <span>Database Pelanggan</span>
              </button>

              <span className="text-[9px] font-bold text-slate-500 tracking-wider uppercase px-3 block pt-4 mb-2">MODUL KEUANGAN</span>

              <button 
                onClick={() => setActiveTab("laporan-keuangan")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "laporan-keuangan" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-chart-pie w-5 text-center text-base mr-2"></i>
                <span>Laporan Keuangan</span>
              </button>

              <span className="text-[9px] font-bold text-slate-500 tracking-wider uppercase px-3 block pt-4 mb-2">PENGATURAN</span>

              <button 
                onClick={() => setActiveTab("pengaturan-instansi")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "pengaturan-instansi" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-gears w-5 text-center text-base mr-2"></i>
                <span>Pengaturan Instansi</span>
              </button>

              <button 
                onClick={() => setActiveTab("backup-restore")}
                className={`w-full flex items-center px-4 py-3 rounded-xl text-xs font-bold transition cursor-pointer ${
                  activeTab === "backup-restore" ? "bg-slate-800 text-sky-400 border-l-4 border-sky-500" : "text-slate-350 hover:bg-slate-800/40"
                }`}
              >
                <i className="fa-solid fa-database w-5 text-center text-base mr-2"></i>
                <span>Backup & Deploy GAS</span>
              </button>
            </nav>

            <div className="p-4 border-t border-slate-800 space-y-2 mt-auto">
              <button 
                onClick={handleLogout} 
                className="w-full bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white transition rounded-xl py-2.5 text-xs font-bold flex items-center justify-center space-x-2 cursor-pointer border border-rose-500/10"
              >
                <i className="fa-solid fa-right-from-bracket"></i>
                <span>Keluar Sesi</span>
              </button>
              <div className="text-[10px] text-slate-500 text-center font-medium">&copy; 2026 SIXMA REPORT</div>
            </div>
          </aside>

          {/* Core Content View Board */}
          <main className="flex-1 flex flex-col overflow-y-auto bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
            {/* Header top row (hides in print) */}
            <header className="h-16 bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-850 flex items-center justify-between px-8 flex-shrink-0 no-print transition-colors duration-300">
              <div className="flex items-center space-x-2">
                <span className="text-slate-400 text-xs font-semibold">Beranda</span>
                <span className="text-slate-300 dark:text-slate-700 text-xs">/</span>
                <span className="text-slate-700 dark:text-slate-200 font-extrabold text-xs capitalize">
                  {activeTab.replace("-", " ")}
                </span>
              </div>
              
              <div className="flex items-center space-x-3">
                {/* Google Sheets Sync Badge */}
                {(settings.gasUrl || (typeof (window as any).google !== 'undefined' && typeof (window as any).google.script !== 'undefined')) ? (
                  <div 
                    onClick={() => handleSyncPull(settings.gasUrl)}
                    title="Klik untuk sinkronisasi paksa (tarik data ulang)"
                    className={`px-3 py-1.5 rounded-full text-[10px] border flex items-center space-x-1.5 select-none shadow-sm cursor-pointer transition active:scale-95 ${
                      syncStatus === 'pulling' ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-400 border-sky-100 dark:border-sky-900/40' :
                      syncStatus === 'pushing' ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900/40' :
                      syncStatus === 'error' ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border-rose-100 dark:border-rose-900/40' :
                      'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/40'
                    }`}
                  >
                    <span className={`w-2 h-2 rounded-full ${
                      syncStatus === 'pulling' || syncStatus === 'pushing' ? 'bg-sky-400 animate-spin border border-dashed border-sky-600' :
                      syncStatus === 'error' ? 'bg-rose-500 animate-bounce' : 'bg-emerald-500 animate-pulse'
                    }`}></span>
                    <span className="font-bold uppercase tracking-wider">
                      {syncStatus === 'pulling' ? 'Sync: Menarik...' :
                       syncStatus === 'pushing' ? 'Sync: Mengirim...' :
                       syncStatus === 'error' ? 'Sync: Gagal Cloud' : 'Cloud: Terhubung'}
                    </span>
                  </div>
                ) : (
                  <button 
                    onClick={handleOpenCloudSetupModal}
                    title="Klik di sini untuk panduan cepat menghubungkan aplikasi ke Cloud Google Sheets"
                    className="bg-rose-50/70 hover:bg-rose-100/80 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 text-rose-600 dark:text-rose-450 font-extrabold px-3 py-1.5 rounded-full text-[10px] border border-rose-200 dark:border-rose-900/30 flex items-center space-x-1.5 select-none shadow-sm cursor-pointer transition active:scale-95"
                  >
                    <span className="w-2 h-2 bg-rose-500 rounded-full animate-pulse"></span>
                    <span>CLOUD: OFFLINE</span>
                  </button>
                )}

                <div className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-400 font-bold px-3 py-1.5 rounded-full text-[10px] border border-sky-100 dark:border-sky-900/40 flex items-center space-x-1.5 select-none shadow-sm">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span>TAHUN BUKU: 2026</span>
                </div>
                
                <button 
                  onClick={toggleDarkMode} 
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-2.5 rounded-xl bg-slate-100 dark:bg-slate-900 hover:bg-slate-250 transition cursor-pointer"
                >
                  <i className={`fa-solid ${darkMode ? 'fa-sun text-amber-500' : 'fa-moon'} text-sm`}></i>
                </button>
              </div>
            </header>

            {/* Render Tab Screens */}
            <div className="p-8 flex-1">
              {activeTab === "dashboard" && (
                <Dashboard sales={sales} expenses={expenses} logs={logs} />
              )}
               {activeTab === "stok" && (
                <DataMaster items={items} onItemsChange={handleItemsChange} currentUser={currentUser} addLog={addLog} />
              )}
              {activeTab === "penjualan" && (
                <InputPenjualan 
                  items={items} 
                  customers={customers} 
                  onSalesChange={handleSalesChange} 
                  sales={sales} 
                  onItemsChange={handleItemsChange} 
                  addLog={addLog} 
                  triggerToast={triggerToast}
                  onViewInvoice={handleViewInvoice}
                />
              )}
              {activeTab === "data-transaksi" && (
                <DataTransaksi sales={sales} onViewInvoice={handleViewInvoice} onEditSale={handleOpenEditSaleModal} addLog={addLog} />
              )}
              {activeTab === "riwayat-transaksi" && (
                <RiwayatPenjualan sales={sales} currentUser={currentUser} onSalesChange={handleSalesChange} onViewInvoice={handleViewInvoice} onEditSale={handleOpenEditSaleModal} addLog={addLog} />
              )}
              {activeTab === "rekapan-tagihan" && (
                <RekapanTagihan sales={sales} />
              )}
              {activeTab === "pengeluaran" && (
                <InputPengeluaran 
                  expenses={expenses} 
                  onExpensesChange={handleExpensesChange} 
                  addLog={addLog} 
                  triggerToast={triggerToast}
                />
              )}
              {activeTab === "pelanggan" && (
                <DatabasePelanggan customers={customers} onCustomersChange={handleCustomersChange} addLog={addLog} />
              )}
              {activeTab === "laporan-keuangan" && (
                <LaporanKeuangan sales={sales} expenses={expenses} settings={settings} items={items} />
              )}
              {activeTab === "pengaturan-instansi" && (
                <PengaturanInstansi settings={settings} onSettingsChange={handleSettingsChange} users={users} onUsersChange={handleUsersChange} currentUser={currentUser} addLog={addLog} />
              )}
              {activeTab === "backup-restore" && (
                <BackupRestore settings={settings} onSettingsChange={handleSettingsChange} onFullStateImport={handleFullStateImport} getFullState={getFullState} addLog={addLog} />
              )}
            </div>
          </main>
        </div>
      )}

      {/* 4. MODAL DETIL FAKTUR ATAU KWITANSI (Handles Cetak A4 / F4) */}
      {showInvoiceModal && selectedSale && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 overflow-y-auto print-modal-backdrop">
          <div className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-[890px] shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden max-h-[95vh] print-modal-content">
            {/* Modal Controls panel (Hides when printing is active) */}
            <div className="p-4 border-b border-slate-200 flex flex-wrap justify-between items-center bg-slate-50 gap-2 no-print">
              <h3 className="font-bold text-xs flex items-center space-x-1.5 text-slate-800">
                <i className="fa-solid fa-print text-sky-500"></i>
                <span>Cetak & Pratinjau Dokumen Resmi</span>
              </h3>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex bg-slate-250 p-0.5 rounded-lg border border-slate-200 text-[10px] b-1 font-bold">
                  <button 
                    onClick={() => setPageSize('a4')}
                    className={`px-2 py-1 rounded-md transition ${pageSize === 'a4' ? 'bg-sky-500 text-white' : 'text-slate-600'}`}
                  >
                    A4
                  </button>
                  <button 
                    onClick={() => setPageSize('f4')}
                    className={`px-2 py-1 rounded-md transition ${pageSize === 'f4' ? 'bg-sky-500 text-white' : 'text-slate-600'}`}
                  >
                    F4 (Folio)
                  </button>
                </div>

                <button 
                  onClick={() => handleDownloadDocPDF(pageSize === 'a4' ? 'A4' : 'F4')}
                  className="bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-bold px-2 py-1.5 rounded flex items-center space-x-1 cursor-pointer"
                  title="Unduh Salinan Teks"
                >
                  <i className="fa-solid fa-file-arrow-down"></i>
                  <span>Unduh</span>
                </button>

                <button 
                  onClick={handlePrintDocument}
                  className="bg-sky-500 hover:bg-sky-600 text-white text-[10px] font-bold px-3 py-1.5 rounded flex items-center space-x-1 cursor-pointer transition shadow"
                >
                  <i className="fa-solid fa-print"></i>
                  <span>Cetak</span>
                </button>

                <button onClick={() => setShowInvoiceModal(false)} className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer">
                  <i className="fa-solid fa-xmark text-lg"></i>
                </button>
              </div>
            </div>

            {/* Scrollable Container wrapper to view sheet on screen, which behaves as a simple transparent layer during printing */}
            <div className="print-scroll-wrapper select-none">
              
              {/* Printable container grows naturally in height, resolving html2canvas truncation */}
              <div 
                id="printable-document-area" 
                className={`p-8 bg-white text-slate-850 leading-relaxed text-xs ${pageSize === 'a4' ? 'size-a4' : 'size-f4'}`}
                style={{ height: 'auto' }}
              >
              
              {/* layout A: NOTA / FAKTUR PENJUALAN */}
              {docType === 'faktur' && (
                <div className="block">
                  {/* Grid Header matching user's reference image */}
                  <div className="grid grid-cols-12 gap-4 items-start pb-4 border-b-2 border-slate-950 mb-4 select-none">
                    
                    {/* Left block: Logo/Brand & Address */}
                    <div className="col-span-5 flex flex-col justify-between">
                      <div className="flex items-center mb-2">
                        {settings.logo ? (
                          <img src={settings.logo} className="h-16 w-auto max-w-full object-contain object-left" alt="Logo" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="flex flex-col">
                            <h1 className="text-3xl font-black tracking-tight text-slate-950 leading-none font-sans">
                              {settings.companyName ? settings.companyName.split(" ")[0].toUpperCase() : "SIXMA"}
                            </h1>
                            <div className="text-[9px] font-bold tracking-widest text-slate-700 uppercase border-t border-slate-950 mt-1 pt-0.5 max-w-[130px]">
                              {settings.companyName && settings.companyName.split(" ").slice(1).join(" ").toUpperCase() || "FOTOCOPY"}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      {/* Address Lines */}
                      <div className="text-[9px] text-slate-800 leading-tight font-medium">
                        {(() => {
                          const addressParts = settings.companyAddress
                            ? settings.companyAddress.split("\n").map(line => line.trim()).filter(Boolean)
                            : ["Jl. Srengseng Raya No. 1", "Kel. Srengseng, Kec. Kembangan", "Jakarta Barat"];
                          return addressParts.map((part, idx) => (
                            <p key={idx}>{part}</p>
                          ));
                        })()}
                      </div>
                    </div>
                    
                    {/* Middle block: Melayani list with vertical borders */}
                    <div className="col-span-3 border-l border-slate-950 pl-3 flex flex-col justify-start text-[9px] leading-relaxed text-slate-900 font-bold min-h-[90px]">
                      <p className="font-extrabold mb-1">Melayani :</p>
                      <p>- Fotocopy</p>
                      <p>- Cetak Foto</p>
                      <p>- Jilid Standar</p>
                      <p>- Jilid Softcover</p>
                      <p>- Jilid Hardcover</p>
                    </div>
                    
                    {/* Right block: Nota/Faktur Title banner & Recipient Info (Kepada Yth.) */}
                    <div className="col-span-4 flex flex-col">
                      <div className="bg-black text-white text-center py-2 px-3 font-extrabold tracking-widest text-[15.75px] leading-normal rounded uppercase mb-2 shadow-sm font-sans select-none">
                        NOTA/FAKTUR
                      </div>
                      
                      {/* Kepada Yth. dotted box representation */}
                      <div className="text-[9px] text-slate-900 leading-tight space-y-1.5">
                        <p className="font-bold italic text-slate-950 text-[10px]">Kepada Yth. :</p>
                        
                        {/* Name Line */}
                        <div className="border-b border-dotted border-slate-950 pb-0.5 font-bold text-slate-950 min-h-[16px] truncate">
                          {selectedSale.pelanggan}
                        </div>
                        
                        {/* Dotted address lines */}
                        {(() => {
                          const parsedCustomer = customers.find(c => c.name === selectedSale.pelanggan);
                          const customerAddress = parsedCustomer ? parsedCustomer.address : "";
                          let addressLines = customerAddress 
                            ? customerAddress.split(/\n|,/).map(s => s.trim()).filter(Boolean)
                            : [];
                          
                          // Pad with empty lines up to 3
                          const blanks = Array(3).fill("");
                          const finalLines = addressLines.concat(blanks).slice(0, 3);
                          
                          return finalLines.map((line, idx) => (
                            <div 
                              key={idx} 
                              className="border-b border-dotted border-slate-950 pb-0.5 text-slate-800 font-medium min-h-[16px]"
                            >
                              {line || ""}
                            </div>
                          ));
                        })()}
                      </div>
                    </div>
                  </div>

                  {/* Factur No & Date Info line styled perfectly like in the image */}
                  <div className="flex flex-row justify-between items-center text-[10px] text-slate-950 font-bold border-b border-slate-950 pb-2 mb-4 select-none">
                    <div>
                      <span>Nomor Faktur : </span>
                      <span className="underline font-extrabold text-slate-950 decoration-slate-950 decoration-1 pl-1">
                        {selectedSale.invoiceNo}
                      </span>
                    </div>
                    <div>
                      <span>Tanggal Faktur : </span>
                      <span className="underline font-extrabold text-slate-950 decoration-slate-950 decoration-1 pl-1">
                        {formatIndonesianDate(selectedSale.tanggal)}
                      </span>
                    </div>
                  </div>

                  {/* FACTUR TABLE: Nama Item - Qty - Satuan - Harga Satuan - Sub Total */}
                  <table className="w-full text-left border-collapse mb-4 text-[10px] font-sans border-2 border-slate-950">
                    <thead>
                      <tr className="bg-slate-100 text-slate-950 font-bold uppercase border-b-2 border-slate-950">
                        <th className="py-2.5 px-3 border-r border-slate-950 w-8 text-center select-none">No.</th>
                        <th className="py-2.5 px-3 border-r border-slate-950">Nama Item / Jasa</th>
                        <th className="py-2.5 px-3 border-r border-slate-950 text-center w-12 select-none">Qty</th>
                        <th className="py-2.5 px-3 border-r border-slate-950 text-center w-16 select-none">Satuan</th>
                        <th className="py-2.5 px-3 border-r border-slate-950 text-right w-24">Harga Satuan</th>
                        <th className="py-2.5 px-3 text-right w-28">Sub Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-950 text-slate-850 font-semibold">
                      {selectedSale.itemDetail.map((item, idx) => (
                        <tr key={idx} className="border-b border-slate-950">
                          <td className="py-2 px-3 border-r border-slate-950 text-center font-bold text-slate-950">{idx + 1}</td>
                          <td className="py-2 px-3 border-r border-slate-950">
                            <span className="font-bold block text-slate-950">{item.name}</span>
                            {item.desc && <span className="text-[9px] text-slate-600 block italic leading-tight mt-0.5">Catatan: {item.desc}</span>}
                          </td>
                          <td className="py-2 px-3 border-r border-slate-950 text-center font-extrabold text-slate-950">{item.qty}</td>
                          <td className="py-2 px-3 border-r border-slate-950 text-center text-slate-800">{item.unit || 'Lembar'}</td>
                          <td className="py-2 px-3 border-r border-slate-950 text-right font-bold text-slate-950">{formatIDR(item.price)}</td>
                          <td className="py-2 px-3 text-right font-black text-slate-950">{formatIDR(item.qty * item.price)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  <div className="border-t border-slate-300 pt-3 space-y-1 text-right text-[10px] text-slate-600 ml-auto w-1/2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span className="font-black text-slate-900">{formatIDR(selectedSale.subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Diskon:</span>
                      <span className="font-bold text-slate-900">{selectedSale.diskon}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>PPN (11%):</span>
                      <span className="font-bold text-slate-900">{formatIDR(selectedSale.tax)}</span>
                    </div>
                    <div className="flex justify-between border-t border-dashed border-slate-300 pt-1 text-slate-900 font-black text-xs">
                      <span>TOTAL AKHIR:</span>
                      <span className="text-sm text-sky-600 font-black">{formatIDR(selectedSale.total)}</span>
                    </div>
                  </div>

                  {selectedSale.metodeBayar === 'Transfer' && settings.ownerBankNo && (
                    <div className="mt-4 p-3 bg-slate-50 border border-slate-150 rounded-xl text-[10px] text-slate-700">
                      <p className="font-extrabold uppercase text-[8px] text-slate-400 mb-1 tracking-wider">Metode Transfer Konfirmasi</p>
                      <div className="grid grid-cols-2 gap-1 text-slate-600 font-semibold">
                        <p><strong>Nama Bank:</strong> <span>{settings.ownerBankName}</span></p>
                        <p><strong>No Rekening:</strong> <span>{settings.ownerBankNo}</span></p>
                        <p className="col-span-2"><strong>Atas Nama:</strong> <span>{settings.ownerName}</span></p>
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-end pt-8 text-[10px] mt-8 border-t border-slate-155">
                    <div className="space-y-4">
                      <p className="text-slate-400 font-medium">Tanda Tangan Pelanggan,</p>
                      <div className="h-12"></div>
                      <p className="font-bold border-b border-slate-300 pb-0.5 inline-block w-28 text-center">{selectedSale.pelanggan}</p>
                    </div>
                    
                    <div className="sig-stamp-container">
                      <p className="text-slate-500 font-semibold mb-1">Hormat kami,</p>
                      <div className="sig-stamp-wrapper">
                        {settings.signature && (
                          <img src={settings.signature} className="sig-image-layer pointer-events-none" alt="Tanda Tangan" />
                        )}
                        {settings.stamp && (
                          <img src={settings.stamp} className="stamp-image-layer pointer-events-none" alt="Stempel" />
                        )}
                      </div>
                      <div>
                        <p className="font-bold underline uppercase text-slate-900 tracking-wide text-xs" style={{ textDecoration: 'underline' }}>{settings.ownerName}</p>
                        <p className="text-[9px] text-slate-500 mt-0.5">{settings.companyName}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* layout B: OFFICIAL SPECIAL KWITANSI */}
              {docType === 'kwitansi' && (
                <div className="border-2 border-slate-950 p-6 rounded-lg bg-white text-slate-900 font-medium relative overflow-hidden animate-in zoom-in-95 duration-200 select-none">
                  <div className="grid grid-cols-12 gap-4 items-start pb-4 border-b-2 border-slate-950 mb-4">
                    {/* Left block: Logo & Address */}
                    <div className="col-span-5 flex flex-col justify-between">
                      <div className="flex items-center mb-2">
                        {settings.logo ? (
                          <img src={settings.logo} className="h-16 w-auto max-w-full object-contain object-left" alt="Logo" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="flex flex-col">
                            <h1 className="text-3xl font-black tracking-tight text-slate-950 leading-none font-sans">
                              {settings.companyName ? settings.companyName.split(" ")[0].toUpperCase() : "SIXMA"}
                            </h1>
                            <div className="text-[9px] font-bold tracking-widest text-slate-700 uppercase border-t border-slate-950 mt-1 pt-0.5 max-w-[130px]">
                              {settings.companyName && settings.companyName.split(" ").slice(1).join(" ").toUpperCase() || "FOTOCOPY"}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      {/* Address Lines */}
                      <div className="text-[9px] text-slate-800 leading-tight font-medium">
                        {(() => {
                          const addressParts = settings.companyAddress
                            ? settings.companyAddress.split("\n").map(line => line.trim()).filter(Boolean)
                            : ["Jl. Srengseng Raya No. 1", "Kel. Srengseng, Kec. Kembangan", "Jakarta Barat"];
                          return addressParts.map((part, idx) => (
                            <p key={idx}>{part}</p>
                          ));
                        })()}
                      </div>
                    </div>
                    
                    {/* Middle block: Melayani list with vertical borders */}
                    <div className="col-span-3 border-l border-slate-950 pl-3 flex flex-col justify-start text-[9px] leading-relaxed text-slate-900 font-bold min-h-[90px]">
                      <p className="font-extrabold mb-1">Melayani :</p>
                      <p>- Fotocopy</p>
                      <p>- Cetak Foto</p>
                      <p>- Jilid Standar</p>
                      <p>- Jilid Softcover</p>
                      <p>- Jilid Hardcover</p>
                    </div>
                    
                    {/* Right block: Kwitansi title & No. Kwitansi */}
                    <div className="col-span-4 flex flex-col items-stretch text-left">
                      <div className="bg-black text-white text-center py-2 px-3 font-extrabold tracking-widest text-[15.75px] leading-normal rounded uppercase mb-3 shadow-md font-sans select-none">
                        KWITANSI
                      </div>
                      <div className="text-[10px] font-bold text-slate-950 flex items-baseline">
                        <span className="shrink-0 font-sans">Nomor Kwitansi :</span>
                        <span className="font-sans font-extrabold text-slate-950 border-b border-dotted border-slate-950 pb-0.5 ml-2 flex-1 text-right italic">
                          {selectedSale.kwitansiNo}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Main horizontal fields exactly matching picture style */}
                  <div className="space-y-4 my-6 text-[11px] leading-normal font-semibold text-slate-950 font-sans">
                    
                    {/* Field 1: Sudah Terima dari */}
                    <div className="flex items-center">
                      <span className="w-36 font-extrabold italic text-slate-950 tracking-wide text-[11px] font-sans">Sudah Terima dari</span>
                      <span className="mr-3 font-bold text-[11px] font-sans">:</span>
                      <div className="flex-1 border-b border-dotted border-slate-950 pb-0.5 font-bold text-slate-950 italic text-[11px] min-h-[18px] font-sans">
                        {(() => {
                          const customerDetails = customers.find(c => c.name === selectedSale.pelanggan);
                          const customerLabel = customerDetails ? `${(customerDetails as any).instansi || ""} / ${customerDetails.name}` : selectedSale.pelanggan;
                          const cleanedLabel = customerLabel.replace(/^(\s*\/\s*)+|(\s*\/\s*)+$/g, "").trim().replace(/^-- | --$/g, "");
                          
                          if (settings.sumberDana) {
                            const parts = cleanedLabel.split('/').map(p => p.trim()).filter(Boolean);
                            const finalParts = [settings.sumberDana.trim(), ...parts];
                            const uniqueParts: string[] = [];
                            finalParts.forEach(p => {
                              if (!uniqueParts.includes(p)) {
                                uniqueParts.push(p);
                              }
                            });
                            return uniqueParts.join(" / ");
                          }
                          return cleanedLabel;
                        })()}
                      </div>
                    </div>
                    
                    {/* Field 2: Terbilang (plain dotted line exactly matching Sudah Terima Dari & Untuk Pembayaran) */}
                    <div className="flex items-center font-sans">
                      <span className="w-36 font-extrabold italic text-slate-950 tracking-wide text-[11px] font-sans">Terbilang</span>
                      <span className="mr-3 font-bold text-[11px] font-sans">:</span>
                      <div className="flex-1 border-b border-dotted border-slate-950 pb-0.5 font-extrabold text-slate-950 italic text-[11px] uppercase tracking-wide min-h-[18px] font-sans">
                        {dapatkanTerbilangRupiah(selectedSale.total)}
                      </div>
                    </div>

                    {/* Field 3: Untuk Pembayaran with 3 empty/filled dotted underlines representative */}
                    <div className="flex items-start font-sans">
                      <span className="w-36 font-extrabold italic text-slate-950 tracking-wide text-[11px] pt-1 font-sans">Untuk Pembayaran</span>
                      <span className="mr-3 font-bold text-[11px] pt-1 font-sans">:</span>
                      <div className="flex-1 space-y-2 font-sans">
                        {/* Line 1: Primary Detail */}
                        <div className="border-b border-dotted border-slate-950 pb-0.5 text-slate-900 font-bold italic text-[11px] min-h-[18px] font-sans">
                          {selectedSale.keteranganBelanja || `Pembayaran Pembelian Barang & Jasa (${selectedSale.itemDetail.map(i => i.name).slice(0, 2).join(", ")})`}
                        </div>
                        {/* Line 2: Empty printed security line */}
                        <div className="border-b border-dotted border-slate-950 pb-0.5 min-h-[14px]"></div>
                        {/* Line 3: Empty printed security line */}
                        <div className="border-b border-dotted border-slate-950 pb-0.5 min-h-[14px]"></div>
                      </div>
                    </div>
                  </div>

                  {/* Footer Section: Rp matrix & Date & Signatures, centered vertically using items-center and generously padded */}
                  <div className="grid grid-cols-12 gap-4 items-center pt-8 pb-4 mt-6 border-t border-slate-950 font-sans">
                    
                    {/* Rp. safe value layout line matching other fields */}
                    <div className="col-span-5 flex items-center font-sans">
                      <span className="font-extrabold text-slate-950 italic mr-3 text-[14px] font-sans">Rp.</span>
                      <div className="flex-1 border-b border-dotted border-slate-950 pb-1 font-sans font-extrabold text-[18px] text-slate-950 tracking-wider text-right pr-1">
                        {selectedSale.total.toLocaleString('id-ID')}
                      </div>
                    </div>

                    {/* Right side: Place-Date, Signatures & Info */}
                    <div className="col-span-7 flex flex-col items-end text-right font-sans">
                      {/* Date representation */}
                      <p className="text-slate-950 font-bold text-[10px] mb-3 select-none font-sans">
                        Jakarta, {formatIndonesianDate(selectedSale.tanggal)}
                      </p>
                      
                      {/* Signature block with sign & stamp */}
                      <div className="sig-stamp-container select-none">
                        <div className="sig-stamp-wrapper">
                          {settings.signature && (
                            <img src={settings.signature} className="sig-image-layer pointer-events-none" alt="Tanda Tangan" referrerPolicy="no-referrer" />
                          )}
                          {settings.stamp && (
                            <img src={settings.stamp} className="stamp-image-layer pointer-events-none" alt="Stempel" referrerPolicy="no-referrer" />
                          )}
                        </div>
                        <div className="text-center">
                          <p className="font-bold underline uppercase text-slate-950 tracking-wider text-[11px] leading-tight select-none">
                            {settings.ownerName || "FITRI MAULIDINA"}
                          </p>
                          <p className="text-[9px] text-slate-700 font-bold mt-1 select-none">
                            Sixma Fotocopy
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Absolute Bottom Address row */}
                  <div className="mt-6 pt-2 border-t-2 border-slate-950 text-center text-[8px] font-bold tracking-wide uppercase text-slate-700 select-none">
                    {settings.companyAddress || "Jl. Srengseng Raya No. 1, Kel. Srengseng, Kec. Kembangan, Jakarta Barat"}
                  </div>
                </div>
              )}

              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. MODAL EDIT DETAILS (Koreksi invoice records) */}
      {showEditSaleModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-5xl shadow-2xl border border-slate-250 dark:border-slate-800 flex flex-col overflow-hidden max-h-[95vh]"
          >
            <div className="p-5 border-b border-slate-200 dark:border-slate-850 flex justify-between items-center bg-slate-50 dark:bg-slate-900/40 shrink-0">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center space-x-2">
                <i className="fa-solid fa-pen-to-square text-sky-500 text-base"></i>
                <span>Edit / Koreksi Data Transaksi Penjualan</span>
              </h3>
              <button onClick={() => setShowEditSaleModal(false)} className="text-slate-400 hover:text-slate-600 transition cursor-pointer">
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs overflow-y-auto flex-1 font-semibold text-slate-700 dark:text-slate-300">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 font-bold uppercase mb-1">No. Invoice</label>
                  <input type="text" value={editSaleInvoiceNo} disabled className="w-full bg-slate-100 dark:bg-slate-900 p-2.5 rounded-lg outline-none font-mono font-bold text-slate-500" />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold uppercase mb-1">Tanggal Transaksi</label>
                  <input 
                    type="text" 
                    value={editSaleDate} 
                    onChange={(e) => setEditSaleDate(e.target.value)} 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-400 font-bold uppercase mb-1">Nama Pembeli</label>
                  <input 
                    type="text" 
                    value={editSaleCustomer} 
                    onChange={(e) => setEditSaleCustomer(e.target.value)} 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white font-bold" 
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold uppercase mb-1">Metode Bayar</label>
                  <select 
                    value={editSalePayment} 
                    onChange={(e) => setEditSalePayment(e.target.value)} 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white"
                  >
                    <option value="Tunai">Tunai</option>
                    <option value="Transfer">Transfer</option>
                    <option value="Piutang">Piutang</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-bold uppercase mb-1">Status Sesi</label>
                  <select 
                    value={editSaleStatus} 
                    onChange={(e) => setEditSaleStatus(e.target.value)} 
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white font-bold"
                  >
                    <option value="Lunas (Paid)">Lunas (Paid)</option>
                    <option value="Belum Lunas (Unpaid)">Belum Lunas (Unpaid)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold uppercase mb-1">Keterangan Belanja (Kwitansi / Untuk Pembayaran Ke)</label>
                <input 
                  type="text" 
                  value={editSaleKeteranganBelanja} 
                  onChange={(e) => setEditSaleKeteranganBelanja(e.target.value)} 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-2.5 rounded-lg outline-none text-slate-900 dark:text-white font-bold text-xs" 
                  placeholder="Isikan keterangan pembayaran kwitansi ini..." 
                />
              </div>

              <div>
                <span className="block text-slate-450 font-bold uppercase mb-2 select-none">Rincian Barang & Jasa di Keranjang</span>
                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs min-w-[800px]">
                    <thead>
                      <tr className="bg-slate-50 dark:bg-slate-900 border-b dark:border-slate-850 text-slate-400 font-bold uppercase text-[10px]">
                        <th className="p-3 w-10 text-center">No.</th>
                        <th className="p-3">Nama Item / Kegiatan Jasa</th>
                        <th className="p-3">Keterangan / Catatan</th>
                        <th className="p-3 text-center w-20">Qty</th>
                        <th className="p-3 text-center w-24">Satuan</th>
                        <th className="p-3 text-right w-32">Harga Satuan (Rp)</th>
                        <th className="p-3 text-right w-32">Subtotal</th>
                        <th className="p-3 text-center w-14">Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      {editSaleItems.map((item, itemIdx) => (
                        <tr key={itemIdx} className="border-b border-slate-100 dark:border-slate-850 hover:bg-slate-50/50 dark:hover:bg-slate-900/30">
                          <td className="p-3 text-center font-bold text-slate-400 select-none">
                            {itemIdx + 1}
                          </td>
                          <td className="p-2">
                            <input 
                              type="text"
                              value={item.name}
                              onChange={(e) => handleUpdateEditSaleItemName(itemIdx, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1.5 rounded-lg text-slate-900 dark:text-white font-bold font-sans text-xs focus:ring-1 focus:ring-sky-500"
                              placeholder="Nama Item..."
                            />
                          </td>
                          <td className="p-2">
                            <input 
                              type="text"
                              value={item.desc || ""}
                              onChange={(e) => handleUpdateEditSaleItemDesc(itemIdx, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1.5 rounded-lg text-slate-850 dark:text-slate-200 text-xs italic focus:ring-1 focus:ring-sky-500"
                              placeholder="Catatan tambahan (opsional)..."
                            />
                          </td>
                          <td className="p-2 text-center">
                            <input 
                              type="number" 
                              value={item.qty} 
                              min="1"
                              onChange={(e) => handleUpdateEditSaleItemQty(itemIdx, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1.5 rounded-lg text-center text-slate-900 dark:text-white font-bold font-mono text-xs focus:ring-1 focus:ring-sky-500" 
                            />
                          </td>
                          <td className="p-2 text-center">
                            <input 
                              type="text" 
                              value={item.unit || ""} 
                              onChange={(e) => handleUpdateEditSaleItemUnit(itemIdx, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1.5 rounded-lg text-center text-slate-800 dark:text-slate-200 text-xs focus:ring-1 focus:ring-sky-500" 
                              placeholder="Lembar"
                            />
                          </td>
                          <td className="p-2 text-right">
                            <input 
                              type="number" 
                              value={item.price} 
                              min="0"
                              onChange={(e) => handleUpdateEditSaleItemPrice(itemIdx, e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-1.5 rounded-lg text-right text-slate-900 dark:text-white font-extrabold font-mono text-xs focus:ring-1 focus:ring-sky-500" 
                            />
                          </td>
                          <td className="p-3 text-right font-black text-sky-500 font-mono text-xs">
                            {formatIDR(item.qty * item.price)}
                          </td>
                          <td className="p-2 text-center">
                            <button 
                              type="button"
                              onClick={() => handleDeleteEditSaleItem(itemIdx)}
                              className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 dark:hover:bg-rose-955/20 rounded-lg transition cursor-pointer"
                              title="Hapus Item"
                            >
                              <i className="fa-solid fa-trash text-sm"></i>
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Form Input Item Jasa Baru Ke Daftar Koreksi */}
              <div className="bg-slate-50/50 dark:bg-slate-950/20 p-4 rounded-xl border border-dashed border-slate-250 dark:border-slate-800 mt-4 space-y-3">
                <span className="block text-[10px] font-extrabold text-slate-450 uppercase tracking-wide flex items-center space-x-1.5 select-none">
                  <i className="fa-solid fa-plus text-sky-500 animate-pulse"></i>
                  <span>Tambah Item/Jasa Baru ke Daftar Koreksi</span>
                </span>
                <div className="grid grid-cols-12 gap-2.5 items-end">
                  <div className="col-span-12 sm:col-span-4">
                    <label className="block text-[9px] text-slate-400 font-bold mb-1 uppercase tracking-wider">Nama Barang / Jasa</label>
                    <input 
                      type="text" 
                      value={newEditItemName}
                      onChange={(e) => setNewEditItemName(e.target.value)}
                      placeholder="E.g. Fotocopy Bahan UTS MK Pancasila..."
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2 rounded-lg outline-none text-slate-900 dark:text-white text-xs"
                    />
                  </div>
                  <div className="col-span-12 sm:col-span-3">
                    <label className="block text-[9px] text-slate-400 font-bold mb-1 uppercase tracking-wider">Catatan/Keterangan</label>
                    <input 
                      type="text" 
                      value={newEditItemDesc}
                      onChange={(e) => setNewEditItemDesc(e.target.value)}
                      placeholder="E.g. Pancasila, Mika Biru"
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2 rounded-lg outline-none text-slate-900 dark:text-white text-xs"
                    />
                  </div>
                  <div className="col-span-4 sm:col-span-1 min-w-0">
                    <label className="block text-[9px] text-slate-400 font-bold mb-1 uppercase tracking-wider text-center">Qty</label>
                    <input 
                      type="number" 
                      min="1"
                      value={newEditItemQty}
                      onChange={(e) => setNewEditItemQty(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2 rounded-lg outline-none text-center font-bold font-mono text-xs"
                    />
                  </div>
                  <div className="col-span-4 sm:col-span-1">
                    <label className="block text-[9px] text-slate-400 font-bold mb-1 uppercase tracking-wider text-center">Satuan</label>
                    <input 
                      type="text" 
                      value={newEditItemUnit}
                      onChange={(e) => setNewEditItemUnit(e.target.value)}
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2 rounded-lg outline-none text-center text-xs"
                    />
                  </div>
                  <div className="col-span-4 sm:col-span-2">
                    <label className="block text-[9px] text-slate-400 font-bold mb-1 uppercase tracking-wider text-right">Harga (Rp)</label>
                    <input 
                      type="number" 
                      value={newEditItemPrice}
                      onChange={(e) => setNewEditItemPrice(e.target.value)}
                      placeholder="Harga..."
                      className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 p-2 rounded-lg outline-none text-right font-extrabold text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div className="col-span-12 sm:col-span-1">
                    <button 
                      type="button" 
                      onClick={handleAddCustomItemToEditSale}
                      className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold p-2 rounded-lg transition text-xs flex justify-center items-center h-[36px] select-none cursor-pointer"
                      title="Tambahkan Item"
                    >
                      <i className="fa-solid fa-plus text-sm"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5 border-t border-slate-200 dark:border-slate-850 flex justify-end space-x-2 pt-4 mt-2 select-none shrink-0 bg-slate-50 dark:bg-slate-900/10">
              <button 
                type="button" 
                onClick={() => setShowEditSaleModal(false)}
                className="bg-slate-105 dark:bg-slate-900 hover:bg-slate-200 dark:hover:bg-slate-850 text-slate-600 dark:text-slate-300 font-bold px-4 py-2 rounded-lg transition cursor-pointer animate-once"
              >
                Batal
              </button>
              <button 
                type="button" 
                onClick={handleSaveEditedSale}
                className="bg-sky-500 hover:bg-sky-600 text-white font-bold px-4 py-2 rounded-lg transition shadow-md cursor-pointer"
              >
                Simpan Perubahan
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* 5.5. INTERACTIVE COLD-LAUNCH SETUP CLOUD MODAL */}
      {showCloudSetupModal && (
        <div className="fixed inset-0 bg-slate-900/70 flex items-center justify-center p-4 z-50 overflow-y-auto">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 350, damping: 25 }}
            className="bg-white dark:bg-slate-950 rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-200 dark:border-slate-850 flex flex-col overflow-hidden my-8"
          >
            {/* Header */}
            <div className="p-5 border-b border-slate-150 dark:border-slate-850 flex justify-between items-center bg-gradient-to-r from-sky-500/10 to-indigo-500/10 shrink-0">
              <h3 className="font-extrabold text-slate-900 dark:text-white flex items-center space-x-2.5">
                <div className="p-2 bg-sky-500 text-white rounded-xl shadow-md shadow-sky-500/25">
                  <i className="fa-solid fa-cloud text-base"></i>
                </div>
                <div className="text-left flex flex-col">
                  <span className="text-sm tracking-tight">Integrasi Awan Otomatis</span>
                  <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Google Sheets Database Server</span>
                </div>
              </h3>
              <button 
                onClick={() => setShowCloudSetupModal(false)} 
                className="text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 transition cursor-pointer p-1"
              >
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>

            {/* Body Info */}
            <div className="p-6 overflow-y-auto space-y-5 text-left text-xs text-slate-700 dark:text-slate-300 leading-relaxed max-h-[70vh]">
              <div className="bg-sky-50/50 dark:bg-sky-950/10 border border-sky-100 dark:border-sky-950/30 p-4 rounded-xl flex items-start space-x-3">
                <i className="fa-solid fa-circle-info text-sky-500 text-sm mt-0.5"></i>
                <p className="font-semibold text-slate-600 dark:text-slate-300">
                  Dengan mengaktifkan integrasi awan, seluruh data transaksi penjualan, data master barang, stok, pengeluaran, pelanggan, dan log sistem akan disinkronisasikan secara **real-time dan otomatis** ke lembar kerja **Google Sheets** pribadi Anda.
                </p>
              </div>

              {/* Steps Guide */}
              <div className="space-y-4">
                <h4 className="font-bold text-slate-900 dark:text-white flex items-center space-x-1.5 uppercase tracking-wider text-[10px]">
                  <span>🛠️ Panduan Hubungkan Cloud (Hanya 3 Menit)</span>
                </h4>

                <div className="space-y-3.5 pl-1">
                  {/* Step 1 */}
                  <div className="flex items-start space-x-2.5">
                    <span className="bg-sky-500/10 text-sky-600 dark:text-sky-400 w-5 h-5 rounded-full flex items-center justify-center shrink-0 font-extrabold text-[10px]">1</span>
                    <div>
                      <p className="font-bold text-slate-800 dark:text-slate-205">Buat Google Sheets Baru</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">Buka spreadsheet kosong di Google Sheets akun Anda, berikan nama spreadsheet sesuai selera (misal: "Database Keuangan Sixma").</p>
                    </div>
                  </div>

                  {/* Step 2 */}
                  <div className="flex items-start space-x-2.5 border-t border-slate-100 dark:border-slate-900 pt-3">
                    <span className="bg-sky-500/10 text-sky-600 dark:text-sky-400 w-5 h-5 rounded-full flex items-center justify-center shrink-0 font-extrabold text-[10px]">2</span>
                    <div className="flex-1 space-y-2">
                      <p className="font-bold text-slate-800 dark:text-slate-205">Buka Ekstensi Apps Script & Tempelkan Kode</p>
                      <p className="text-[11px] text-slate-500">Pilih menu **Extensions (Ekstensi) &gt; Apps Script**. Hapus semua berkas kode bawaan kosong, lalu klik tombol di bawah ini untuk menyalin master skrip integrasi database.</p>
                      
                      <button
                        onClick={handleCopyGasCode}
                        className={`font-black text-[10px] py-2 px-3 rounded-lg flex items-center justify-center space-x-2 shadow-sm transition-all duration-200 cursor-pointer ${
                          copyCodeStatus === 'success' 
                            ? 'bg-emerald-500 hover:bg-emerald-600 text-white' 
                            : 'bg-indigo-600 hover:bg-indigo-700 text-indigo-50 dark:text-indigo-200 active:scale-95'
                        }`}
                      >
                        <i className={`fa-solid ${copyCodeStatus === 'success' ? 'fa-circle-check' : 'fa-clipboard-list'}`}></i>
                        <span>
                          {copyCodeStatus === 'success' ? 'Kode Backend Google Sheets Disalin!' : 'Salin Kode Script Database (Code.gs)'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Step 3 */}
                  <div className="flex items-start space-x-2.5 border-t border-slate-100 dark:border-slate-900 pt-3">
                    <span className="bg-sky-500/10 text-sky-600 dark:text-sky-400 w-5 h-5 rounded-full flex items-center justify-center shrink-0 font-extrabold text-[10px]">3</span>
                    <div>
                      <p className="font-bold text-slate-800 dark:text-slate-205">Deploy Skrip Tersebut sebagai Web App</p>
                      <ul className="text-[11px] text-slate-500 list-disc ml-4 space-y-1 mt-0.5">
                        <li>Klik tombol **Deploy (Terapkan) &gt; New Deployment (Terapkan Baru)**.</li>
                        <li>Pilih tipe as **Web app** (Klik ikon gear di kiri atas menu deploy jika belum terpilih).</li>
                        <li>Atur **Execute as**: Pilih **Me / Saya (email anda)**.</li>
                        <li>Atur **Who has access**: Pilih **Anyone / Siapa Saja** *(Sangat penting supaya API web bertukar data).*</li>
                        <li>Klik **Deploy**, setujui hak akses Google, lalu **Salin Web app URL** yang berakhiran `/exec`.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              {/* Connection Input Field */}
              <div className="bg-slate-50 dark:bg-slate-900/60 p-4 rounded-xl border border-slate-200/60 dark:border-slate-800 space-y-3 pt-3 mt-1">
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-wider">
                  <i className="fa-solid fa-link mr-1"></i> Tautan URL Deployment Web App Apps Script (Akhiran /exec)
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input 
                    type="text" 
                    value={cloudUrlInput}
                    onChange={(e) => setCloudUrlInput(e.target.value)}
                    placeholder="https://script.google.com/macros/s/.../exec"
                    className="flex-1 bg-white dark:bg-slate-950 border border-slate-250 dark:border-slate-800 rounded-lg p-2.5 text-xs text-slate-900 dark:text-white outline-none focus:border-sky-500 dark:focus:border-sky-500 font-mono"
                  />
                  <button
                    onClick={handleConnectCloud}
                    className="bg-sky-500 hover:bg-sky-600 text-white font-extrabold text-xs px-5 py-2.5 rounded-lg flex items-center justify-center space-x-1.5 shadow-md shadow-sky-500/20 active:scale-95 duration-100 transition cursor-pointer hover:shadow-sky-500/30 font-sans"
                  >
                    <i className="fa-solid fa-plug text-xs"></i>
                    <span>Hubungkan & Sinkronkan</span>
                  </button>
                </div>
                <p className="text-[9px] text-slate-400 italic font-semibold">Tautan ini aman dan hanya menghubungkan aplikasi frontend Anda ke lembar kerja spreadsheet milik Anda sendiri.</p>
              </div>
            </div>

            {/* Footer buttons */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900/40 border-t border-slate-200 dark:border-slate-850 flex justify-end space-x-3 shrink-0">
              <button
                onClick={() => setShowCloudSetupModal(false)}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-850 px-4 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer"
              >
                Batal / Gunakan Offline
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* 6. TOAST NOTIFICATION STICKER */}
      {showToast && (
        <motion.div 
          initial={{ opacity: 0, y: 50, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.9 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="fixed bottom-6 right-6 bg-slate-900 text-white px-5 py-4 rounded-2xl shadow-2xl flex items-center space-x-3 text-xs z-[10000] border border-slate-800"
        >
          <i className={`fa-solid ${toastType === 'success' ? 'fa-circle-check text-emerald-400' : toastType === 'error' ? 'fa-circle-xmark text-rose-500' : 'fa-circle-info text-sky-400'} text-base`}></i>
          <span className="font-extrabold text-slate-100">{toastMessage}</span>
        </motion.div>
      )}
    </div>
  );
}
