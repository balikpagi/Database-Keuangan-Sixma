import fs from 'fs';
import path from 'path';

const distPath = './dist';
const assetsPath = path.join(distPath, 'assets');

if (!fs.existsSync(distPath) || !fs.existsSync(assetsPath)) {
  console.error("Directories do not exist. Please run npm run build first.");
  process.exit(1);
}

const files = fs.readdirSync(assetsPath);
const jsFile = files.find(f => f.endsWith('.js') && f.startsWith('index-'));
const cssFile = files.find(f => f.endsWith('.css') && f.startsWith('index-'));

if (!jsFile || !cssFile) {
  console.error("Could not find compiled JS or CSS files in dist/assets.");
  process.exit(1);
}

const htmlContent = fs.readFileSync(path.join(distPath, 'index.html'), 'utf-8');
const jsContent = fs.readFileSync(path.join(assetsPath, jsFile), 'utf-8');
const cssContent = fs.readFileSync(path.join(assetsPath, cssFile), 'utf-8');

// Replace stylesheet link with empty string (it will be injected by our loader)
let singleHtml = htmlContent.replace(
  /<link rel="stylesheet"[^>]*href="\/assets\/index-[^"]*\.css"[^>]*>/i,
  ''
);

const jsBase64 = Buffer.from(jsContent, 'utf-8').toString('base64');
const cssBase64 = Buffer.from(cssContent, 'utf-8').toString('base64');

// Helper to chunk strings to prevent Google Apps Script single-line performance issues
const chunkString = (str, len) => {
  const size = Math.ceil(str.length / len);
  const r = new Array(size);
  let offset = 0;
  for (let i = 0; i < size; i++) {
    r[i] = str.substring(offset, offset + len);
    offset += len;
  }
  return r;
};

const jsChunks = chunkString(jsBase64, 4000);
const cssChunks = chunkString(cssBase64, 4000);

const jsChunksFormatted = jsChunks.map(chunk => `      "${chunk}"`).join(',\n');
const cssChunksFormatted = cssChunks.map(chunk => `      "${chunk}"`).join(',\n');

const loaderScript = `<script type="text/javascript">
  (function() {
    var jsBase64Parts = [
${jsChunksFormatted}
    ];
    var cssBase64Parts = [
${cssChunksFormatted}
    ];
    
    var jsBase64 = jsBase64Parts.join("");
    var cssBase64 = cssBase64Parts.join("");
    
    function decodeB64(str) {
      try {
        return decodeURIComponent(escape(atob(str)));
      } catch (e) {
        return atob(str); // Fallback
      }
    }
    
    var styleEl = document.createElement('style');
    styleEl.textContent = decodeB64(cssBase64);
    document.head.appendChild(styleEl);
    
    var scriptEl = document.createElement('script');
    scriptEl.type = 'text/javascript';
    scriptEl.textContent = decodeB64(jsBase64);
    document.body.appendChild(scriptEl);
  })();
</script>`;

// Replace module script with our safe base64 decoding script loader
singleHtml = singleHtml.replace(
  /<script type="module"[^>]*src="\/assets\/index-[^"]*\.js"[^>]*><\/script>/i,
  loaderScript
);

// Write bundled output
const outputPath = path.join(distPath, 'gas-index.html');
fs.writeFileSync(outputPath, singleHtml, 'utf-8');
console.log(`Successfully bundled single HTML into: ${outputPath}`);

// Also save to public/ folder so it can be downloaded/fetched directly from the frontend
const publicDir = './public';
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir);
}
const publicOutputPath = path.join(publicDir, 'gas-index.html');
fs.writeFileSync(publicOutputPath, singleHtml, 'utf-8');
console.log(`Successfully copied bundle to public folder: ${publicOutputPath}`);
