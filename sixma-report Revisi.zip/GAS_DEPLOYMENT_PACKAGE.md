# 📦 PAKET DEPLOYMENT GOOGLE APPS SCRIPT (GAS) LENGKAP - SIXMA REPORT

Dokumen ini berisi panduan dan kode **1 Paket Lengkap** untuk menjalankan sistem backend database dan sinkronisasi awan otomatis menggunakan **Google Sheets** sebagai database permanen.

Aplikasi kita menggunakan **Arsitektur Dual-Layer Storage** yang sangat canggih:
1. **High-Fidelity Master Backup (JSON)**: Seluruh status sistem (termasuk relasi, data base64 tanda tangan/stempel, dan log transaksi) disimpan secara instan sebagai master JSON terkompresi di sel super-sel aman. Ini menjamin data pulih **100% utuh tanpa bug konversi tipe data**.
2. **Human-Readable Spreadsheet Tabs**: Aplikasi secara otomatis mem-parsing dan menjabarkan data terbaru menjadi baris-baris tabel Excel biasa yang rapi di Google Sheets pada tab terpisah (**Users**, **Items**, **Sales**, **Sales_Detail** (sub-barang per invoice!), **Expenses**, **Customers**, **Logs**, dan **Settings**). Anda bisa melihat, memfilter, mencetak, atau membagikan lembar kerja ini kapan saja!

---

## 📑 DAFTAR ISI
1. [Bagian 1: Kode `Code.gs` untuk Backend Google Sheets](#bagian-1)
2. [Bagian 2: Panduan Langkah-Demi-Langkah Pemasangan di Google Sheets](#bagian-2)
3. [Bagian 3: Panduan Deploy Frontend Single-File HTML](#bagian-3)

---

<a name="bagian-1"></a>
## 📂 BAGIAN 1: KODE `Code.gs` (Backend Server)

*Salin seluruh kode di bawah ini, lalu tempelkan (paste) ke jendela Google Apps Script Anda:*

```javascript
/**
 * ===========================================================================
 * SIXMA REPORT SYSTEM - GOOGLE APPS SCRIPT FULL-STACK ENGINE (Code.gs)
 * ===========================================================================
 * Author: DeepMind AI Coding Agent
 * License: Apache-2.0
 * 
 * Manages dual-layer synchronization:
 * 1. Read/Write 100% accurate JSON payload stored permanently inside the sheet.
 * 2. Unpack & structure data into readable row columns for analysis.
 */

// Konfigurasi Nama Tab Google Sheets
var TAB_MASTER_JSON = "_master_db_json";
var TAB_USERS = "Users";
var TAB_ITEMS = "Items";
var TAB_SALES = "Sales";
var TAB_SALES_DETAIL = "Sales_Details";
var TAB_EXPENSES = "Expenses";
var TAB_CUSTOMERS = "Customers";
var TAB_LOGS = "Logs";
var TAB_SETTINGS = "Settings";

// ==========================================
// 1. ENTRY POINT GET (Tarik Data/Pull Sync ATAU Tampilkan HTML UI)
// ==========================================
function doGet(e) {
  // Jika dipanggil sebagai API REST eksternal biasa (membawa ?api=true atau ?action=...)
  if (e && e.parameter && (e.parameter.api === "true" || e.parameter.action || e.parameter.syncStatus)) {
    try {
      var dbState = readMasterData();
      return createJsonResponse({
        status: "success",
        data: dbState
      });
    } catch (err) {
      return createJsonResponse({
        status: "error",
        message: err.toString()
      });
    }
  }

  // DEFAULT: Sajikan USER INTERFACE Frontend utuh langsung di Google Sheets/Apps Script!
  try {
    var htmlOutput = HtmlService.createTemplateFromFile("index").evaluate();
    htmlOutput.setTitle("Sixma Report - Sistem Laporan Terpadu")
              .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
              .addMetaTag("viewport", "width=device-width, initial-scale=1");
    return htmlOutput;
  } catch (err) {
    // Pesan informatif jika user belum memasang file index.html
    return ContentService.createTextOutput("Backend Google Sheets BERHASIL Dibuat!\n\nUntuk membuka Frontend GUI langsung di sini, silakan buat berkas 'index.html' di dalam editor Google Apps Script Anda (klik tombol + > HTML > beri nama 'index') lalu salin & paste seluruh kode frontend dari aplikasi Anda ke dalamnya.\n\nDetail teknis error: " + err.toString());
  }
}

// ==========================================
// 2. ENTRY POINT POST (Simpan Data via HTTP REST API)
// ==========================================
function doPost(e) {
  try {
    var postContent = e.postData.contents;
    var payload = JSON.parse(postContent);
    
    if (payload.action === "sync_write") {
      var dataToSave = payload.data;
      
      // Layer 1: Simpan Master JSON Mentah untuk Keamanan Data 100%
      writeMasterData(dataToSave);
      
      // Layer 2: Sebarkan ke Tab-Tab Terstruktur untuk Analisis Pengguna
      updateSpreadsheetTabs(dataToSave);
      
      return createJsonResponse({
        status: "success",
        message: "Data berhasil diintegrasikan ke Google Sheets!"
      });
    } else {
      return createJsonResponse({
        status: "error",
        message: "Aksi tidak dikenali."
      });
    }
  } catch (err) {
    return createJsonResponse({
      status: "error",
      message: err.toString()
    });
  }
}

// ==========================================
// 2b. API INTERNAL UNTUK NATIVE CLIENT (google.script.run)
// ==========================================
function saveMasterFromClient(data) {
  try {
    // Layer 1: Simpan Master JSON Mentah untuk Keamanan Data 100%
    writeMasterData(data);
    
    // Layer 2: Sebarkan ke Tab-Tab Terstruktur untuk Analisis Pengguna
    updateSpreadsheetTabs(data);
    
    return {
      status: "success",
      message: "Data berhasil disimpan dari client!"
    };
  } catch (err) {
    throw new Error("Gagal menyimpan data: " + err.toString());
  }
}

// Helper untuk CORS-safe JSON Response
function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

// ==========================================
// 3. LAYER 1: READ / WRITE MASTER JSON DATA
// ==========================================
function readMasterData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB_MASTER_JSON);
  
  if (!sheet) {
    // Jika belum ada, gunakan data kosong default
    return {
      users: [],
      items: [],
      sales: [],
      expenses: [],
      customers: [],
      logs: [],
      settings: {}
    };
  }
  
  var rawJson = sheet.getRange(1, 1).getValue();
  if (!rawJson) {
    // Cari backup di Script Properties jika sel spreadsheet tidak sengaja terhapus
    rawJson = PropertiesService.getScriptProperties().getProperty("sixma_master_db");
  }
  
  if (!rawJson) {
    return {
      users: [],
      items: [],
      sales: [],
      expenses: [],
      customers: [],
      logs: [],
      settings: {}
    };
  }
  
  return JSON.parse(rawJson);
}

function writeMasterData(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB_MASTER_JSON);
  
  if (!sheet) {
    sheet = ss.insertSheet(TAB_MASTER_JSON);
    sheet.hideSheet(); // Sembunyikan tab master dari baris bawah agar bersih
  }
  
  var jsonString = JSON.stringify(data);
  sheet.getRange(1, 1).setValue(jsonString);
  
  // Simpan salinan darurat di Script Properties
  PropertiesService.getScriptProperties().setProperty("sixma_master_db", jsonString);
}

// ========================================================
// 4. LAYER 2: UPDATE SPREADSHEET TABS (HUMAN READABLE)
// ========================================================
function updateSpreadsheetTabs(data) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. UPDATE TAB USERS
  updateTabGeneric(ss, TAB_USERS, 
    ["ID Pengguna", "Username", "Role/Akses", "Nama Lengkap"],
    data.users || [],
    function(user) {
      return [user.id, user.username, user.role, user.name];
    }
  );

  // 2. UPDATE TAB ITEMS (MASTER DATA BARANG)
  updateTabGeneric(ss, TAB_ITEMS, 
    ["ID Barang", "Nama Barang", "Kategori", "Harga Modal (Rp)", "Harga Jual (Rp)", "Stok Terkini", "Minimum Stok"],
    data.items || [],
    function(item) {
      return [item.id, item.name, item.category, item.buyPrice, item.sellPrice, item.stock, item.minStock];
    }
  );

  // 3. UPDATE TAB EXPENSES (PENGELUARAN)
  updateTabGeneric(ss, TAB_EXPENSES, 
    ["No Pengeluaran", "Tanggal", "Kategori", "Keterangan", "Jumlah (Rp)"],
    data.expenses || [],
    function(exp) {
      return [exp.expenseNo, exp.tanggal, exp.kategori, exp.keterangan, exp.jumlah];
    }
  );

  // 4. UPDATE TAB CUSTOMERS (REGISTRASI PELANGGAN)
  updateTabGeneric(ss, TAB_CUSTOMERS, 
    ["ID Pelanggan", "Nama Instansi / Pembeli", "Nomor Telepon", "Email", "Alamat Lengkap"],
    data.customers || [],
    function(cust) {
      return [cust.id, cust.name, cust.phone, cust.email, cust.address];
    }
  );

  // 5. UPDATE TAB AUDIT LOGS
  updateTabGeneric(ss, TAB_LOGS, 
    ["Waktu / Tanggal", "Kategori Aksi", "Rincian Kejadian", "User Pelaksana"],
    data.logs || [],
    function(log) {
      return [log.tanggal, log.aksi, log.keterangan, log.user];
    }
  );

  // 6. UPDATE TAB SETTINGS (INFORMASI INSTANSI / PERUSAHAAN)
  var settingsList = [];
  if (data.settings) {
    var s = data.settings;
    settingsList = [
      ["Nama Instansi", s.companyName || ""],
      ["Alamat Instansi", s.companyAddress || ""],
      ["Nama Pemilik/Owner", s.ownerName || ""],
      ["Bank Tujuan", s.ownerBankName || ""],
      ["Nomor Rekening", s.ownerBankNo || ""],
      ["NPWP Perusahaan", s.ownerNpwp || ""],
      ["Google Apps Script URL", s.gasUrl || ""]
    ];
  }
  updateTabSettingsGeneric(ss, TAB_SETTINGS, ["Parameter Pengaturan", "Nilai Konfigurasi"], settingsList);

  // 7. UPDATE TAB SALES & TAB SALES DETAILS
  updateTabSalesAndDetails(ss, data.sales || []);
}

// Helper untuk memperbarui tab standar secara dinamis
function updateTabGeneric(ss, tabName, headers, listData, mapRowFn) {
  var sheet = ss.getSheetByName(tabName);
  if (!sheet) {
    sheet = ss.insertSheet(tabName);
  }
  sheet.clear();
  
  var rows = [headers];
  for (var i = 0; i < listData.length; i++) {
    rows.push(mapRowFn(listData[i]));
  }
  
  sheet.getRange(1, 1, rows.length, headers.length).setValues(rows);
  formatSheetHeader(sheet, headers.length);
}

// Helper untuk memperbarui data Settings secara Key-Value
function updateTabSettingsGeneric(ss, tabName, headers, settingsList) {
  var sheet = ss.getSheetByName(tabName);
  if (!sheet) {
    sheet = ss.insertSheet(tabName);
  }
  sheet.clear();
  
  var rows = [headers];
  for (var i = 0; i < settingsList.length; i++) {
    rows.push(settingsList[i]);
  }
  
  if (rows.length > 1) {
    sheet.getRange(1, 1, rows.length, 2).setValues(rows);
    formatSheetHeader(sheet, 2);
  }
}

// Pemrosesan khusus untuk Sales (Kwitansi & Rincian Barang di dalam Invoice)
function updateTabSalesAndDetails(ss, salesList) {
  // Tab 1: Ringkasan Invoice Penjualan (Master Sales)
  var salesSheet = ss.getSheetByName(TAB_SALES);
  if (!salesSheet) salesSheet = ss.insertSheet(TAB_SALES);
  salesSheet.clear();
  
  var salesHeaders = [
    "No. Invoice", "No. Kwitansi", "Trx ID", "Tanggal Transaksi", 
    "Nama Pelanggan", "Metode Pembayaran", "Subtotal (Rp)", "Diskon (%)", 
    "Pajak Mutlak (Rp)", "Total Pendapatan (Rp)", "Status Pembayaran", "Keterangan Ringkas"
  ];
  
  var salesRows = [salesHeaders];
  
  // Tab 2: Rincian Keranjang Barang per Invoice (Detail Cart Items)
  var detailSheet = ss.getSheetByName(TAB_SALES_DETAIL);
  if (!detailSheet) detailSheet = ss.insertSheet(TAB_SALES_DETAIL);
  detailSheet.clear();
  
  var detailHeaders = [
    "No. Invoice", "Nama Barang", "Volume Multiplier", "Qty / Jumlah Fisik", 
    "Satuan Pelayanan", "Harga Satuan (Rp)", "Pajak (%)", "Catatan Khusus", "Total Tagihan Item (Rp)"
  ];
  
  var detailRows = [detailHeaders];
  
  for (var i = 0; i < salesList.length; i++) {
    var sale = salesList[i];
    salesRows.push([
      sale.invoiceNo, sale.kwitansiNo, sale.trxId, sale.tanggal,
      sale.pelanggan, sale.metodeBayar, sale.subtotal, sale.diskon,
      sale.tax, sale.total, sale.status, sale.keteranganBelanja
    ]);
    
    // Pecah keranjang (CartItem) menjadi baris detail database mandiri
    if (sale.itemDetail && sale.itemDetail.length > 0) {
      for (var j = 0; j < sale.itemDetail.length; j++) {
        var item = sale.itemDetail[j];
        var itemTotalCost = (item.price * item.qty) + (item.price * item.qty * (item.taxRate / 100));
        detailRows.push([
          sale.invoiceNo, item.name, item.volume, item.qty,
          item.unit, item.price, item.taxRate, item.desc || "", itemTotalCost
        ]);
      }
    }
  }
  
  if (salesRows.length > 1) {
    salesSheet.getRange(1, 1, salesRows.length, salesHeaders.length).setValues(salesRows);
    formatSheetHeader(salesSheet, salesHeaders.length);
  }
  
  if (detailRows.length > 1) {
    detailSheet.getRange(1, 1, detailRows.length, detailHeaders.length).setValues(detailRows);
    formatSheetHeader(detailSheet, detailHeaders.length);
  }
}

// Merapikan Tampilan Kolom Header Google Sheets (Gaya Profesional)
function formatSheetHeader(sheet, numColumns) {
  var headerRange = sheet.getRange(1, 1, 1, numColumns);
  headerRange.setBackground("#0284c7") // Sky-600 background color
             .setFontColor("#ffffff")   // White text
             .setFontWeight("bold")
             .setHorizontalAlignment("center");
  sheet.autoResizeColumns(1, numColumns);
}
```

---

<a name="bagian-2"></a>
## 📝 BAGIAN 2: PANDUAN MANUAL SETUP GOOGLE SHEETS

Lakukan langkah-langkah berikut untuk mengaktifkan database awan ini:

1. **Buka Google Sheets Baru**: 
   Akses [Google Sheets](https://sheets.google.com/) lalu buat sebuah berkas spreadsheet kosong baru. Namakan spreadsheet tersebut, misalnya: `Database Keuangan Sixma`.
2. **Buka Editor Aplikasi Script**:
   Pada menu navigasi atas Google Sheets, klik **Extensions** (Ekstensi) > Pilih **Apps Script**.
3. **Tempelkan Kode**:
   - Hapus seluruh kode kosong bawaan (`myFunction`) di editor Apps Script.
   - Salin dan tempelkan (paste) seluruh **Kode `Code.gs`** berisi di **Bagian 1** dokumen ini.
   - Klik ikon **Save** (Simpan/diskette) di bar menu atas Apps Script.
4. **Deploy Sebagai Web App**:
   - Klik tombol **Deploy** (Terapkan) berwarna biru di kanan atas halaman, pilih **New deployment** (Trapan baru).
   - Klik ikon gerigi (Configuration type) lalu pilih **Web app**.
   - Isi konfigurasi sesuai instruksi berikut **(KRUSIAL)**:
     * **Description**: `Sixma Database API Server v1`
     * **Execute as**: Pilih **Me (email.anda@gmail.com)**
     * **Who has access**: Pilih **Anyone** (Semua orang / Siapa saja). *Konfigurasi ini diperlukan agar aplikasi web React Anda dapat mengirim & membaca data secara aman.*
   - Klik tombol **Deploy**.
5. **Verifikasi Keamanan Akses (Authorize Access)**:
   - Google akan meminta verifikasi izin berkas. Klik tombol **Authorize Access** (Izinkan Akses).
   - Pilih akun Google Anda.
   - Jika muncul peringatan *"Google hasn't verified this app"*, jangan khawatir (ini wajar karena ini adalah skrip privat Anda). Klik **Advanced** di bagian kiri bawah, lalu klik **Go to Untitled project (unsafe)** atau nama berkas Apps Script Anda.
   - Klik tombol **Allow** (Izinkan).
6. **Salin URL Web App**:
   - Setelah sukses dideploy, akan muncul pop-up baru yang melampirkan **Web app URL**.
   - Salin URL panjang tersebut (Formatnya berakhiran `/exec`). **Ini adalah GAS URL database Anda!**
7. **Hubungkan Ke Aplikasi**:
   - Buka aplikasi web **Sixma Report**.
   - Masuk ke tab menu **"Backup & Cloud"** (atau ikon database/Backup di menu sebelah kiri).
   - Paste URL yang Anda salin tadi ke input field pencarian *"Status Deployment Google Sheets (GAS)"*.
   - Klik tombol **"Simpan & Hubungkan URL Google Sheets"**.
   - **Selesai!** Indikator di kanan atas header Anda sekarang akan menyala hijau dan bertuliskan **"CLOUD: TERHUBUNG"**.

---

<a name="bagian-3"></a>
## 🎨 BAGIAN 3: PANDUAN DEPLOY FRONTEND SINGLE-FILE HTML

Untuk kemudahan pemasangan, kami telah merancang kompilasi kode frontend bertipe **Single-File HTML** di mana seluruh tampilan dashboard, style Tailwind, visual chart Recharts, ikon, animasi, serta berkas Javascript React di-bundle langsung menjadi satu berkas mandiri.

Berkas bundle siap pakai ini telah dibuat secara otomatis dan terletak di folder workspace server pada direktori:
`/dist/gas-index.html`

### 💡 Alternatif: Meluncurkan Frontend Langsung dari Dalam Google Sheets!

Jika Anda ingin aplikasi ini di-host sepenuhnya dan diluncurkan langsung dari Google Sheet Anda tanpa memerlukan server eksternal, lakukan cara ajaib berikut:

1. Buka kembali dashboard **Google Apps Script** tempat skrip `Code.gs` tadi berada.
2. Di sidebar sebelah kanan tab Files, klik tombol **`+` (Add a file)** > Pilih **HTML**.
3. Beri nama berkas HTML tersebut: **`index`** (Google Apps Script akan mendeteksi ini sebagai `index.html`).
4. Buka berkas `/dist/gas-index.html` di editor workspace AI Studio Anda, salin seluruh isi ribuan baris kodenya, dan paste di dalam berkas `index.html` yang baru dibuat di Google Apps Script. Simpan berkas tersebut.
5. **Selesai!** Berkas `Code.gs` yang Anda salin di Bagian 1 sudah dilengkapi dengan logika peluncur halaman ini secara otomatis. Jadi Anda tidak perlu menambahkan apa-apa lagi! Keseluruhan sistem routing API Sheets beserta GUI Frontend sudah menyatu di satu tempat.
6. **Deploy ulang skrip**: Klik **Deploy** > **Manage deployments** > Klik ikon pensil untuk mengedit > Pilih versi **New Version** > Klik **Deploy**.
7. Sekarang, ketika Anda membuka tautan Web App URL di tab browser, **Aplikasi Kasir & Pembukuan Finansial Sixma Report akan tampil megah langsung berjalan di awan Google Apps Script Anda secara mandiri!** 🎉
